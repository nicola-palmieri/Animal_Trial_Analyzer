# ===============================================================
# 🧪 Table Analyzer — Standalone App
# ===============================================================


library(bslib)
library(dplyr)
library(DT)
library(emmeans)
library(flextable)
library(GGally)
library(ggplot2)
library(lmerTest)
library(officer)
library(patchwork)
library(shiny)
library(shinyjqui)
library(skimr)
library(tidyr)
library(zoo)

options(shiny.autoreload = TRUE)
options(shiny.maxRequestSize = 200 * 1024^2)

for (f in list.files("R", full.names = TRUE, pattern = "\\.R$")) source(f)

# ---------------------------------------------------------------
# UI
# ---------------------------------------------------------------
ui <- navbarPage(
  title = "📊 Table Analyzer",
  id = "main_nav",
  theme = bs_theme(bootswatch = "flatly"),
  
  # ---- Custom CSS (copied from website) ----
  header = tags$head(
    tags$style(HTML("
      .container-fluid { max-width: 100%; margin: auto; }
      .hero {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9f5ff 100%);
        border-radius: 16px; padding: 20px 24px;
      }
      h1, h2, h3 { margin-top: 0.4rem; }
      .section { margin-top: 18px; }
      .card { border-radius: 16px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
      .nav-tabs > li > a { font-weight: 500; }
    "))
  ),
  
  tabPanel(
    "1️⃣ Upload",
    fluidPage(upload_ui("upload"))
  ),
  tabPanel(
    "2️⃣ Filter",
    fluidPage(filter_ui("filter"))
  ),
  tabPanel(
    "3️⃣ Analyze",
    fluidPage(analysis_ui("analysis"))
  ),
  tabPanel(
    "4️⃣ Visualize",
    fluidPage(visualize_ui("visualize"))
  ),
)

# ---------------------------------------------------------------
# SERVER
# ---------------------------------------------------------------
server <- function(input, output, session) {
  uploaded  <- upload_server("upload")
  filtered  <- filter_server("filter", uploaded)
  analyzed  <- analysis_server("analysis", filtered)
  visualize_server("visualize", filtered, analyzed)
}

# ---------------------------------------------------------------
# LAUNCH
# ---------------------------------------------------------------
shinyApp(ui, server)
# ===============================================================
# 🧪 Table Analyzer — One-way ANOVA Module 
# ===============================================================

one_way_anova_ui <- function(id) {
  ns <- NS(id)
  list(
    config = tagList(
      uiOutput(ns("inputs")),
      uiOutput(ns("level_order")),
      tags$details(
        tags$summary(strong("Advanced options")),
        br(),
        stratification_ui("strat", ns)
      ),
      br(),
      fluidRow(
        column(6, actionButton(ns("run"), "Show results", width = "100%")),
        column(6, downloadButton(ns("download_all"), "Download all results", style = "width: 100%;"))
      )
    ),
    results = tagList(
      uiOutput(ns("summary_ui"))
    )
  )
}

one_way_anova_server <- function(id, filtered_data) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    
    # -----------------------------------------------------------
    # Reactive data
    # -----------------------------------------------------------
    df <- filtered_data
    
    # -----------------------------------------------------------
    # Dynamic inputs
    # -----------------------------------------------------------
    responses <- multi_response_server("response", df)

    output$inputs <- renderUI({
      req(df())
      data <- df()
      cat_cols <- names(data)[sapply(data, function(x) is.character(x) || is.factor(x))]

      tagList(
        multi_response_ui(ns("response")),
        selectInput(
          ns("group"),
          "Categorical predictor:",
          choices = cat_cols,
          selected = if (length(cat_cols) > 0) cat_cols[1] else NULL
        )
      )
    })
    
    strat_info <- stratification_server("strat", df)
    
    # -----------------------------------------------------------
    # Level order selection
    # -----------------------------------------------------------
    output$level_order <- renderUI({
      req(df(), input$group)
      levels <- unique(as.character(df()[[input$group]]))
      selectInput(
        ns("order"),
        "Order of levels (first = reference):",
        choices = levels,
        selected = levels,
        multiple = TRUE
      )
    })
    
    # -----------------------------------------------------------
    # Model fitting (via shared helper)
    # -----------------------------------------------------------
    models <- eventReactive(input$run, {
      req(df(), input$group, input$order)
      resp_vals <- responses()
      req(length(resp_vals) > 0)
      prepare_stratified_anova(
        df = df(),
        responses = resp_vals,
        model = "oneway_anova",
        factor1_var = input$group,
        factor1_order = input$order,
        stratification = strat_info()
      )
    })
    
    
    # -----------------------------------------------------------
    # Download all results as one combined DOCX
    # -----------------------------------------------------------
    output$download_all <- downloadHandler(
      filename = function() {
        model_info <- models()
        n_resp <- length(model_info$responses)
        n_strata <- if (is.null(model_info$strata)) 0 else length(model_info$strata$levels)
        strata_label <- ifelse(n_strata == 0, "nostratum", paste0(n_strata, "strata"))
        timestamp <- format(Sys.time(), "%Y%m%d-%H%M")
        sprintf("anova_results_%sresp_%s_%s.docx", n_resp, strata_label, timestamp)
      },
      content = function(file) {
        model_info <- models()
        if (is.null(model_info)) stop("Please run the ANOVA first.")
        download_all_anova_results(model_info, file)
      }
    )
    
    # -----------------------------------------------------------
    # Render results (shared UI generator)
    # -----------------------------------------------------------
    output$summary_ui <- renderUI({
      render_anova_results(ns, models(), "One-way ANOVA")
    })
    
    # -----------------------------------------------------------
    # Render model summaries + download buttons (shared helper)
    # -----------------------------------------------------------
    bind_anova_outputs(ns, output, models)

    df_final <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      mod$data_used
    })

    model_fit <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      mod$models
    })

    compiled_results <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      compile_anova_results(mod)
    })

    summary_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$summary
    })

    posthoc_results <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$posthoc
    })

    effect_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$effects
    })

    error_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$errors
    })

    reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)

      data_used <- df_final()

      list(
        analysis_type = "ANOVA",
        data_used = data_used,
        model = model_fit(),
        summary = summary_table(),
        posthoc = posthoc_results(),
        effects = effect_table(),
        stats = if (!is.null(data_used)) list(n = nrow(data_used), vars = names(data_used)) else NULL,
        metadata = list(
          responses = mod$responses,
          strata = mod$strata,
          factors = mod$factors,
          orders = mod$orders,
          errors = error_table()
        ),
        type = "oneway_anova",
        models = model_fit(),
        responses = mod$responses,
        strata = mod$strata,
        factors = mod$factors,
        orders = mod$orders
      )
    })
  })
}
# ===============================================================
# 🧪 Visualization Module — One-way ANOVA
# ===============================================================

visualize_oneway_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 4 — Visualize one-way ANOVA"),
      p("Select visualization type and adjust subplot layout, axis scaling, and figure size."),
      hr(),
      selectInput(
        ns("plot_type"),
        label = "Select visualization type:",
        choices = c("Mean ± SE" = "mean_se"),
        selected = "mean_se"
      ),
      hr(),
      uiOutput(ns("layout_controls")),
      fluidRow(
        column(6, numericInput(ns("plot_width"), "Subplot width (px)", value = 400, min = 200, max = 1200, step = 50)),
        column(6, numericInput(ns("plot_height"), "Subplot height (px)", value = 300, min = 200, max = 1200, step = 50))
      ),
      hr(),
      add_color_customization_ui(ns, multi_group = FALSE),
      hr(),
      downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
    ),
    mainPanel(
      width = 8,
      h4("Plots"),
      plotOutput(ns("plot"), height = "auto")
    )
  )
}


visualize_oneway_server <- function(id, filtered_data, model_info) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    
    df <- reactive(filtered_data())
    layout_state <- initialize_layout_state(input, session)
    
    # ---- Plug in color customization module (single-color mode) ----
    custom_colors <- add_color_customization_server(
      ns = ns,
      input = input,
      output = output,
      data = df,
      color_var_reactive = reactive(NULL),
      multi_group = FALSE
    )
    
    # ---- Build plot info ----
    plot_info <- reactive({
      info <- model_info()
      if (is.null(info) || info$type != "oneway_anova") return(NULL)
      data <- df()
      build_anova_plot_info(
        data,
        info,
        layout_state$effective_input,
        line_colors = custom_colors()
      )
    })
    
    observe_layout_synchronization(plot_info, layout_state, session)
    
    plot_obj <- reactive({
      info <- plot_info()
      if (is.null(info)) return(NULL)
      info$plot
    })
    
    plot_size <- reactive({
      info <- plot_info()
      if (is.null(info)) return(list(w = input$plot_width, h = input$plot_height))
      s <- plot_info()$layout
      list(
        w = input$plot_width * s$strata$cols * s$responses$ncol,
        h = input$plot_height * s$strata$rows * s$responses$nrow
      )
    })
    
    output$layout_controls <- renderUI({
      info <- model_info()
      if (is.null(info) || info$type != "oneway_anova") return(NULL)
      build_anova_layout_controls(ns, input, info, layout_state$default_ui_value)
    })
    
    # ---- Render plot ----
    output$plot <- renderPlot({
      info <- model_info()
      req(info, input$plot_type)
      if (input$plot_type == "mean_se") {
        req(plot_obj())
        plot_obj()
      }
    },
    width = function() plot_size()$w,
    height = function() plot_size()$h,
    res = 96)
    
    # ---- Download handler ----
    output$download_plot <- downloadHandler(
      filename = function() paste0("anova_plot_", Sys.Date(), ".png"),
      content = function(file) {
        req(plot_obj())
        ggsave(
          filename = file,
          plot = plot_obj(),
          device = "png",
          dpi = 300,
          width = plot_size()$w / 96,
          height = plot_size()$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )
  })
}
# ===============================================================
# 🧠 Table Analyzer — Shared ANOVA Module Helpers
# ===============================================================

build_anova_layout_controls <- function(ns, input, info, default_ui_value) {
  has_strata <- !is.null(info$strata) && !is.null(info$strata$var)
  n_responses <- if (!is.null(info$responses)) length(info$responses) else 0
  
  strata_inputs <- if (has_strata) {
    tagList(
      h5("Across strata:"),
      fluidRow(
        column(
          width = 6,
          numericInput(
            ns("strata_rows"),
            "Grid rows",
            value = isolate(default_ui_value(input$strata_rows)),
            min = 1,
            max = 10,
            step = 1
          )
        ),
        column(
          width = 6,
          numericInput(
            ns("strata_cols"),
            "Grid columns",
            value = isolate(default_ui_value(input$strata_cols)),
            min = 1,
            max = 10,
            step = 1
          )
        )
      )
    )
  } else {
    NULL
  }
  
  response_inputs <- if (!is.null(n_responses) && n_responses > 1) {
    tagList(
      h5("Across responses:"),
      fluidRow(
        column(
          width = 6,
          numericInput(
            ns("resp_rows"),
            "Grid rows",
            value = isolate(default_ui_value(input$resp_rows)),
            min = 1,
            max = 10,
            step = 1
          )
        ),
        column(
          width = 6,
          numericInput(
            ns("resp_cols"),
            "Grid columns",
            value = isolate(default_ui_value(input$resp_cols)),
            min = 1,
            max = 10,
            step = 1
          )
        )
      )
    )
  } else {
    NULL
  }
  
  tagList(
    h4("Layout controls"),
    strata_inputs,
    response_inputs
  )
}


# ===============================================================
# 📊 Prepare stratified models for ANOVA (one-way / two-way)
# ===============================================================

prepare_stratified_anova <- function(
    df,
    responses,
    model,
    factor1_var = NULL,
    factor1_order = NULL,
    factor2_var = NULL,
    factor2_order = NULL,
    stratification = NULL,
    stratify_var = NULL,
    strata_order = NULL
) {
  req(df, responses, model)

  if (!is.null(stratification)) {
    if (!is.null(stratification$var)) {
      stratify_var <- stratification$var
    }
    if (!is.null(stratification$levels)) {
      strata_order <- stratification$levels
    }
  }
  
  if (!is.null(factor1_var) && !is.null(factor1_order)) {
    df[[factor1_var]] <- factor(as.character(df[[factor1_var]]), levels = factor1_order)
  }
  
  if (!is.null(factor2_var) && !is.null(factor2_order)) {
    df[[factor2_var]] <- factor(as.character(df[[factor2_var]]), levels = factor2_order)
  }
  
  if (!is.null(stratify_var) && stratify_var %in% names(df)) {
    if (!is.null(strata_order) && length(strata_order) > 0) {
      df[[stratify_var]] <- factor(as.character(df[[stratify_var]]), levels = strata_order)
    } else {
      df[[stratify_var]] <- as.factor(as.character(df[[stratify_var]]))
    }
  }
  
  strata <- if (!is.null(stratify_var) && stratify_var %in% names(df)) {
    levels(df[[stratify_var]])
  } else {
    NULL
  }
  
  build_rhs <- function() {
    if (model == "oneway_anova") {
      factor1_var
    } else if (model == "twoway_anova") {
      if (!is.null(factor1_var) && !is.null(factor2_var)) {
        paste(factor1_var, factor2_var, sep = " *")
      } else {
        factor1_var
      }
    } else {
      factor1_var
    }
  }
  
  build_formula <- function(resp) {
    rhs <- build_rhs()
    if (is.null(rhs) || rhs == "") rhs <- "1"
    as.formula(paste(resp, "~", rhs))
  }
  
  fit_fn <- function(fml, data) {
    stats::aov(fml, data = data)
  }
  safe_fit <- purrr::safely(fit_fn)
  
  if (is.null(strata)) {
    out <- list()
    for (resp in responses) {
      fit_result <- safe_fit(build_formula(resp), df)
      out[[resp]] <- list(
        model = fit_result$result,
        error = if (!is.null(fit_result$error)) conditionMessage(fit_result$error) else NULL
      )
    }
    return(list(
      type = model,
      models = out,
      responses = responses,
      strata = NULL,
      factors = list(factor1 = factor1_var, factor2 = factor2_var),
      orders = list(order1 = factor1_order, order2 = factor2_order),
      data_used = df
    ))
  }
  
  out <- list()
  for (s in strata) {
    sub <- df[df[[stratify_var]] == s, , drop = FALSE]
    sub_models <- list()
    for (resp in responses) {
      fit_result <- safe_fit(build_formula(resp), sub)
      sub_models[[resp]] <- list(
        model = fit_result$result,
        error = if (!is.null(fit_result$error)) conditionMessage(fit_result$error) else NULL
      )
    }
    out[[s]] <- sub_models
  }
  
  list(
    type = model,
    models = out,
    responses = responses,
    strata = list(var = stratify_var, levels = strata),
    factors = list(factor1 = factor1_var, factor2 = factor2_var),
    orders = list(order1 = factor1_order, order2 = factor2_order),
    data_used = df
  )
}


prepare_anova_outputs <- function(model_obj, factor_names) {
  old_contrasts <- options("contrasts")
  on.exit(options(old_contrasts), add = TRUE)
  options(contrasts = c("contr.sum", "contr.poly"))
  
  anova_obj <- car::Anova(model_obj, type = 3)
  anova_df <- as.data.frame(anova_obj)
  anova_df$Effect <- rownames(anova_df)
  rownames(anova_df) <- NULL
  anova_df <- anova_df[, c("Effect", setdiff(names(anova_df), "Effect"))]
  
  # --- format p-values and round numeric columns ---
  p_col <- grep("^Pr", names(anova_df), value = TRUE)
  p_col <- if (length(p_col) > 0) p_col[1] else NULL
  raw_p <- if (!is.null(p_col)) anova_df[[p_col]] else rep(NA_real_, nrow(anova_df))
  
  for (col in names(anova_df)) {
    if (is.numeric(anova_df[[col]])) {
      anova_df[[col]] <- round(anova_df[[col]], 2)
    }
  }
  
  anova_significant <- !is.na(raw_p) & raw_p < 0.05
  if (!is.null(p_col)) {
    formatted_p <- format_p_value(raw_p)
    anova_df[[p_col]] <- add_significance_marker(formatted_p, raw_p)
    names(anova_df)[names(anova_df) == p_col] <- "p.value"
  } else {
    anova_df$p.value <- NA_character_
  }
  
  # --- Post-hoc Tukey for each factor ---
  factor_names <- unique(factor_names[!is.na(factor_names) & nzchar(factor_names)])
  posthoc_details <- list()
  posthoc_combined <- NULL
  posthoc_significant <- numeric(0)
  
  for (factor_nm in factor_names) {
    if (!factor_nm %in% names(model_obj$model)) next
    
    res <- tryCatch({
      emm <- emmeans::emmeans(model_obj, specs = factor_nm)
      contrasts <- emmeans::contrast(emm, method = "revpairwise", adjust = "tukey")
      as.data.frame(summary(contrasts))
    }, error = function(e) list(error = e$message))
    
    if (is.data.frame(res)) {
      res$Factor <- factor_nm
      posthoc_details[[factor_nm]] <- list(table = res, error = NULL)
      posthoc_combined <- rbind(posthoc_combined, res)
    } else {
      posthoc_details[[factor_nm]] <- list(table = NULL, error = res$error)
    }
  }
  
  if (!is.null(posthoc_combined)) {
    posthoc_combined <- posthoc_combined[, c("Factor", setdiff(names(posthoc_combined), "Factor"))]
    numeric_cols <- names(posthoc_combined)[sapply(posthoc_combined, is.numeric)]
    if (length(numeric_cols) > 0) {
      for (col in numeric_cols) {
        posthoc_combined[[col]] <- round(posthoc_combined[[col]], 2)
      }
    }
    
    if ("p.value" %in% names(posthoc_combined)) {
      raw_posthoc_p <- posthoc_combined$p.value
      posthoc_significant <- !is.na(raw_posthoc_p) & raw_posthoc_p < 0.05
      formatted_posthoc_p <- format_p_value(raw_posthoc_p)
      posthoc_combined$p.value <- add_significance_marker(formatted_posthoc_p, raw_posthoc_p)
    } else {
      posthoc_significant <- rep(FALSE, nrow(posthoc_combined))
    }
  }
  
  list(
    anova_object = anova_obj,
    anova_table = anova_df,
    anova_significant = anova_significant,
    posthoc_details = posthoc_details,
    posthoc_table = posthoc_combined,
    posthoc_significant = posthoc_significant
  )
}

# ---------------------------------------------------------------
# Collate tidy summaries from ANOVA models
# ---------------------------------------------------------------

compile_anova_results <- function(model_info) {
  if (is.null(model_info) || is.null(model_info$models)) return(NULL)

  factor_names <- unlist(model_info$factors)
  factor_names <- factor_names[!is.na(factor_names) & nzchar(factor_names)]

  build_effects <- function(outputs) {
    if (is.null(outputs) || is.null(outputs$anova_table)) return(NULL)
    effects <- data.frame(
      Effect = outputs$anova_table$Effect,
      significant = outputs$anova_significant,
      stringsAsFactors = FALSE
    )
    if ("p.value" %in% names(outputs$anova_table)) {
      effects$p.value <- outputs$anova_table$p.value
    }
    effects
  }

  if (is.null(model_info$strata)) {
    summary_list <- list()
    posthoc_list <- list()
    effects_list <- list()
    errors_list <- list()

    for (resp in names(model_info$models)) {
      entry <- model_info$models[[resp]]
      if (!is.null(entry$model)) {
        outputs <- prepare_anova_outputs(entry$model, factor_names)
        summary_list[[resp]] <- outputs$anova_table
        posthoc_list[[resp]] <- outputs$posthoc_table
        effects_list[[resp]] <- build_effects(outputs)
      } else {
        summary_list[[resp]] <- NULL
        posthoc_list[[resp]] <- NULL
        effects_list[[resp]] <- NULL
      }
      if (!is.null(entry$error)) {
        errors_list[[resp]] <- entry$error
      }
    }

    return(list(
      summary = summary_list,
      posthoc = posthoc_list,
      effects = effects_list,
      errors = errors_list
    ))
  }

  summary_list <- list()
  posthoc_list <- list()
  effects_list <- list()
  errors_list <- list()

  for (stratum_name in names(model_info$models)) {
    stratum_models <- model_info$models[[stratum_name]]
    if (is.null(stratum_models)) next

    for (resp in names(stratum_models)) {
      entry <- stratum_models[[resp]]
      outputs <- NULL
      if (!is.null(entry$model)) {
        outputs <- prepare_anova_outputs(entry$model, factor_names)
      }

      if (is.null(summary_list[[resp]])) summary_list[[resp]] <- list()
      if (is.null(posthoc_list[[resp]])) posthoc_list[[resp]] <- list()
      if (is.null(effects_list[[resp]])) effects_list[[resp]] <- list()
      if (is.null(errors_list[[resp]])) errors_list[[resp]] <- list()

      summary_list[[resp]][[stratum_name]] <- if (!is.null(outputs)) outputs$anova_table else NULL
      posthoc_list[[resp]][[stratum_name]] <- if (!is.null(outputs)) outputs$posthoc_table else NULL
      effects_list[[resp]][[stratum_name]] <- if (!is.null(outputs)) build_effects(outputs) else NULL

      if (!is.null(entry$error)) {
        errors_list[[resp]][[stratum_name]] <- entry$error
      }
    }
  }

  list(
    summary = summary_list,
    posthoc = posthoc_list,
    effects = effects_list,
    errors = errors_list
  )
}

# ---------------------------------------------------------------
# Output composition
# ---------------------------------------------------------------
print_anova_summary_and_posthoc <- function(model_entry, factors) {
  if (is.null(model_entry) || (is.list(model_entry) && is.null(model_entry$model))) {
    cat("Model is not available.\n")
    return(invisible(NULL))
  }

  if (!is.null(model_entry$error)) {
    cat("Model fitting failed:\n", model_entry$error, "\n", sep = "")
    return(invisible(NULL))
  }

  model_obj <- model_entry$model
  results <- prepare_anova_outputs(model_obj, factors)
  print(results$anova_object)

  if (length(results$posthoc_details) == 0) {
    cat("\nNo post-hoc Tukey comparisons were generated.\n")
  } else {
    for (factor_nm in names(results$posthoc_details)) {
      details <- results$posthoc_details[[factor_nm]]
      if (!is.null(details$error)) {
        cat("\nPost-hoc Tukey comparisons for", factor_nm, "failed:", details$error, "\n")
      } else if (!is.null(details$table)) {
        cat("\nPost-hoc Tukey comparisons for", factor_nm, ":\n")
        print(details$table)
      }
    }
  }
  invisible(results)
}

bind_single_model_outputs <- function(output, summary_id, download_id,
                                      model_entry, response_name, factors,
                                      stratum_label = NULL) {
  output[[summary_id]] <- renderPrint({
    print_anova_summary_and_posthoc(model_entry, factors)
  })

  output[[download_id]] <- downloadHandler(
    filename = function() {
      base <- paste0("anova_results_", sanitize_name(response_name))
      if (!is.null(stratum_label)) {
        base <- paste0(base, "_stratum_", sanitize_name(stratum_label))
      }
      paste0(base, "_", Sys.Date(), ".docx")
    },
    content = function(file) {
      if (is.null(model_entry) || !is.null(model_entry$error) || is.null(model_entry$model)) {
        stop("Model not available for download due to fitting error.")
      }
      results <- prepare_anova_outputs(model_entry$model, factors)
      write_anova_docx(file, results, model_entry$model, response_name, stratum_label)
    }
  )
}

render_anova_results <- function(ns, model_info, module_label = "ANOVA") {
  if (is.null(model_info)) return(NULL)
  
  responses <- model_info$responses
  strata_info <- model_info$strata
  
  # No stratification
  if (is.null(strata_info)) {
    tabs <- lapply(seq_along(responses), function(i) {
      tabPanel(
        title = responses[i],
        tags$div(
          verbatimTextOutput(ns(paste0("summary_", i)))
        )
      )
    })
    return(do.call(tabsetPanel, c(list(id = ns("results_tabs")), tabs)))
  }
  
  # Stratified
  strata_levels <- strata_info$levels
  tabs <- lapply(seq_along(responses), function(i) {
    response_name <- responses[i]
    stratum_tabs <- lapply(seq_along(strata_levels), function(j) {
      stratum_name <- strata_levels[j]
      tabPanel(
        title = stratum_name,
        tags$div(
          verbatimTextOutput(ns(paste0("summary_", i, "_", j)))
        )
      )
    })
    tabPanel(
      title = response_name,
      do.call(tabsetPanel, c(list(id = ns(paste0("strata_tabs_", i))), stratum_tabs))
    )
  })
  do.call(tabsetPanel, c(list(id = ns("results_tabs")), tabs))
}

bind_anova_outputs <- function(ns, output, models_reactive) {
  observeEvent(models_reactive(), {
    model_info <- models_reactive()
    if (is.null(model_info)) return()
    
    responses <- model_info$responses
    model_list <- model_info$models
    strata_info <- model_info$strata
    factors <- unlist(model_info$factors, use.names = FALSE)
    
    # --- Non-stratified case ---
    if (is.null(strata_info)) {
      for (i in seq_along(responses)) {
        local({
          idx <- i
          response_name <- responses[i]
          model_entry <- model_list[[response_name]]
          bind_single_model_outputs(
            output,
            summary_id = paste0("summary_", idx),
            download_id = paste0("download_", idx),
            model_entry = model_entry,
            response_name = response_name,
            factors = factors
          )
        })
      }
      return()
    }
    
    # --- Stratified case ---
    strata_levels <- strata_info$levels
    for (i in seq_along(responses)) {
      for (j in seq_along(strata_levels)) {
        local({
          idx <- i
          stratum_idx <- j
          response_name <- responses[i]
          stratum_label <- strata_levels[j]
          model_entry <- model_list[[stratum_label]][[response_name]]
          bind_single_model_outputs(
            output,
            summary_id = paste0("summary_", idx, "_", stratum_idx),
            download_id = paste0("download_", idx, "_", stratum_idx),
            model_entry = model_entry,
            response_name = response_name,
            factors = factors,
            stratum_label = stratum_label
          )
        })
      }
    }
  })
}

# ---------------------------------------------------------------
# Results export
# ---------------------------------------------------------------

download_all_anova_results <- function(models_info, file) {
  if (is.null(models_info) || is.null(models_info$models)) {
    stop("No models found to export.")
  }
  
  combined_results <- list()

  # --- Case 1: no stratification
  if (is.null(models_info$strata)) {
    for (resp in models_info$responses) {
      model_entry <- models_info$models[[resp]]
      if (is.null(model_entry) || !is.null(model_entry$error) || is.null(model_entry$model)) {
        next
      }
      model_obj <- model_entry$model
      anova_obj <- car::Anova(model_obj, type = 3)
      tbl <- as.data.frame(anova_obj)
      tbl$Response <- resp
      tbl$Stratum <- "None"
      tbl$Term <- rownames(tbl)
      rownames(tbl) <- NULL
      names(tbl) <- sub(" ", "", names(tbl))
      tbl$PrF <- tbl[, grep("^Pr", names(tbl))[1]]
      combined_results[[length(combined_results) + 1]] <- tbl
    }
  } else {
    # --- Case 2: stratified
    for (stratum in models_info$strata$levels) {
      for (resp in models_info$responses) {
        model_entry <- models_info$models[[stratum]][[resp]]
        if (is.null(model_entry) || !is.null(model_entry$error) || is.null(model_entry$model)) {
          next
        }
        model_obj <- model_entry$model
        anova_obj <- car::Anova(model_obj, type = 3)
        tbl <- as.data.frame(anova_obj)
        tbl$Response <- resp
        tbl$Stratum <- stratum
        tbl$Term <- rownames(tbl)
        rownames(tbl) <- NULL
        names(tbl) <- sub(" ", "", names(tbl))
        tbl$PrF <- tbl[, grep("^Pr", names(tbl))[1]]
        combined_results[[length(combined_results) + 1]] <- tbl
      }
    }
  }

  if (length(combined_results) == 0) {
    stop("No ANOVA models available to export.")
  }

  write_anova_docx(combined_results, file)
}

write_anova_docx <- function(results, file) {

  if (is.null(results) || length(results) == 0) stop("No ANOVA results available to export.")
  combined <- bind_rows(results)
  
  required_cols <- c("Response", "Stratum", "Term", "SumSq", "Df", "Fvalue", "PrF")
  if (!all(required_cols %in% names(combined))) stop("Missing required columns in ANOVA results.")
  
  # Format and sort
  combined <- combined %>%
    mutate(
      SumSq = round(SumSq, 3),
      Fvalue = round(Fvalue, 3),
      PrF_label = ifelse(PrF < 0.001, "<0.001", sprintf("%.3f", PrF)),
      sig = PrF < 0.05
    ) %>%
    arrange(Response, Stratum, Term)
  
  # Hide Stratum column if it's all "None"
  if (length(unique(combined$Stratum)) == 1 && unique(combined$Stratum) == "None") {
    combined$Stratum <- NULL
    visible_cols <- c("Response", "Term", "SumSq", "Df", "Fvalue", "PrF_label")
    merge_cols <- c("Response")
  } else {
    visible_cols <- c("Response", "Stratum", "Term", "SumSq", "Df", "Fvalue", "PrF_label")
    merge_cols <- c("Response", "Stratum")
  }
  
  # Build flextable
  ft <- flextable(combined[, visible_cols])
  
  # Clean header names
  ft <- set_header_labels(
    ft,
    Response = "Response",
    Stratum = if ("Stratum" %in% visible_cols) "Stratum" else NULL,
    Term = "Term",
    SumSq = "Sum Sq",
    Df = "Df",
    Fvalue = "F value",
    PrF_label = "Pr(>F)"
  )
  
  # Merge identical group labels
  ft <- merge_v(ft, j = intersect(merge_cols, ft$col_keys))
  
  # Styling
  ft <- fontsize(ft, part = "all", size = 10)
  ft <- bold(ft, part = "header", bold = TRUE)
  ft <- color(ft, part = "header", color = "black")
  ft <- align(ft, align = "center", part = "all")
  
  # Bold significant p-values (< 0.05)
  if ("sig" %in% names(combined)) {
    sig_rows <- which(combined$sig)
    if (length(sig_rows) > 0 && "PrF_label" %in% ft$col_keys) {
      ft <- bold(ft, i = sig_rows, j = "PrF_label", bold = TRUE)
    }
  }
  
  # ===== Journal-style borders =====
  ft <- border_remove(ft)
  black <- fp_border(color = "black", width = 1)
  thin <- fp_border(color = "black", width = 0.5)
  
  # 1) Top line above header
  ft <- border(ft, part = "header", border.top = black)
  # 2) Line below header
  ft <- border(ft, part = "header", border.bottom = black)
  
  # 3) Thin horizontal lines between different responses
  if ("Response" %in% names(combined)) {
    resp_index <- which(diff(as.numeric(factor(combined$Response))) != 0)
    if (length(resp_index) > 0) {
      ft <- border(ft, i = resp_index, part = "body", border.bottom = thin)
    }
  }
  
  # 4) Final bottom border (last line)
  if (nrow(combined) > 0) {
    ft <- border(ft, i = nrow(combined), part = "body", border.bottom = black)
  }
  
  
  # No side or inner borders
  ft <- set_table_properties(ft, layout = "autofit", width = 0.9)
  ft <- padding(ft, padding.top = 2, padding.bottom = 2, padding.left = 2, padding.right = 2)
  
  # Write to DOCX
  doc <- read_docx()
  doc <- body_add_flextable(doc, ft)
  doc <- body_add_par(doc, "")
  doc <- body_add_par(doc, sprintf("Generated by Table Analyzer on %s", Sys.Date()))
  doc <- body_add_par(doc, "Significant p-values (< 0.05) in bold.", style = "Normal")
  print(doc, target = file)
}


# ---------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------

build_anova_plot_info <- function(data, info, effective_input, line_colors = NULL) {
  factor1 <- info$factors$factor1
  factor2 <- info$factors$factor2
  order1 <- info$orders$order1
  order2 <- info$orders$order2
  
  if (!is.null(factor1) && !is.null(order1)) {
    data[[factor1]] <- factor(data[[factor1]], levels = order1)
  }
  if (!is.null(factor2) && !is.null(order2)) {
    data[[factor2]] <- factor(data[[factor2]], levels = order2)
  }
  
  responses <- info$responses
  has_strata <- !is.null(info$strata) && !is.null(info$strata$var)
  strat_var <- if (has_strata) info$strata$var else NULL
  strata_levels <- if (has_strata) info$strata$levels else character(0)
  if (has_strata && (is.null(strata_levels) || length(strata_levels) == 0)) {
    strata_levels <- unique(as.character(stats::na.omit(data[[strat_var]])))
  }
  
  response_plots <- list()
  max_strata_rows <- 1
  max_strata_cols <- 1
  
  compute_stats <- function(df_subset, resp_name) {
    if (is.null(factor2)) {
      df_subset |>
        dplyr::group_by(.data[[factor1]]) |>
        dplyr::summarise(
          mean = mean(.data[[resp_name]], na.rm = TRUE),
          se = sd(.data[[resp_name]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[resp_name]]))),
          .groups = "drop"
        )
    } else {
      df_subset |>
        dplyr::group_by(.data[[factor1]], .data[[factor2]]) |>
        dplyr::summarise(
          mean = mean(.data[[resp_name]], na.rm = TRUE),
          se = sd(.data[[resp_name]], na.rm = TRUE) / sqrt(sum(!is.na(.data[[resp_name]]))),
          .groups = "drop"
        )
    }
  }
  
  build_plot <- function(stats_df, title_text, y_limits) {
    if (is.null(factor2)) {
      color_value <- if (!is.null(line_colors) && length(line_colors) > 0) {
        unname(line_colors)[1]
      } else {
        resolve_single_color()
      }
      p <- ggplot(stats_df, aes(x = !!sym(factor1), y = mean)) +
        geom_line(aes(group = 1), color = color_value, linewidth = 1) +
        geom_point(size = 3, color = color_value) +
        geom_errorbar(aes(ymin = mean - se, ymax = mean + se),
                      width = 0.15, color = color_value) +
        theme_minimal(base_size = 14) +
        labs(x = factor1, y = "Mean ± SE") +
        theme(
          panel.grid.minor = element_blank(),
          panel.grid.major.x = element_blank()
        )
    } else {
      group_levels <- if (is.factor(stats_df[[factor2]])) {
        levels(stats_df[[factor2]])
      } else {
        unique(as.character(stats_df[[factor2]]))
      }
      group_levels <- group_levels[!is.na(group_levels)]
      palette <- resolve_palette_for_levels(group_levels, custom = line_colors)
      stats_df[[factor2]] <- factor(as.character(stats_df[[factor2]]), levels = group_levels)
      p <- ggplot(stats_df, aes(
        x = !!sym(factor1),
        y = mean,
        color = !!sym(factor2),
        group = !!sym(factor2)
      )) +
        geom_line(linewidth = 1) +
        geom_point(size = 3) +
        geom_errorbar(aes(ymin = mean - se, ymax = mean + se),
                      width = 0.15) +
        theme_minimal(base_size = 14) +
        labs(
          x = factor1,
          y = "Mean ± SE",
          color = factor2
        ) +
        theme(
          panel.grid.minor = element_blank(),
          panel.grid.major.x = element_blank()
        ) +
        scale_color_manual(values = palette)
    }
    
    if (!is.null(y_limits) && all(is.finite(y_limits))) {
      p <- p + scale_y_continuous(limits = y_limits)
    }
    
    p + ggtitle(title_text) +
      theme(plot.title = element_text(size = 12, face = "bold"))
  }
  
  for (resp in responses) {
    if (has_strata) {
      stratum_plots <- list()
      y_values <- c()
      
      for (stratum in strata_levels) {
        subset_data <- data[!is.na(data[[strat_var]]) & data[[strat_var]] == stratum, , drop = FALSE]
        if (nrow(subset_data) == 0) next
        
        stats_df <- compute_stats(subset_data, resp)
        if (nrow(stats_df) == 0) next
        
        y_values <- c(y_values, stats_df$mean - stats_df$se, stats_df$mean + stats_df$se)
        stratum_plots[[stratum]] <- stats_df
      }
      
      if (length(stratum_plots) == 0) next
      
      y_limits <- range(y_values, na.rm = TRUE)
      if (!all(is.finite(y_limits))) y_limits <- NULL
      
      strata_plot_list <- lapply(names(stratum_plots), function(stratum_name) {
        build_plot(stratum_plots[[stratum_name]], stratum_name, y_limits)
      })
      
      layout <- resolve_grid_layout(
        n_items = length(strata_plot_list),
        rows_input = effective_input("strata_rows"),
        cols_input = effective_input("strata_cols")
      )
      
      max_strata_rows <- max(max_strata_rows, layout$nrow)
      max_strata_cols <- max(max_strata_cols, layout$ncol)
      
      combined <- patchwork::wrap_plots(
        plotlist = strata_plot_list,
        nrow = layout$nrow,
        ncol = layout$ncol
      )
      
      title_plot <- ggplot() +
        theme_void() +
        ggtitle(resp) +
        theme(
          plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
          plot.margin = margin(t = 0, r = 0, b = 6, l = 0)
        )
      
      response_plots[[resp]] <- title_plot / combined + plot_layout(heights = c(0.08, 1))
      
    } else {
      stats_df <- compute_stats(data, resp)
      if (nrow(stats_df) == 0) {
        next
      }
      
      y_values <- c(stats_df$mean - stats_df$se, stats_df$mean + stats_df$se)
      y_limits <- range(y_values, na.rm = TRUE)
      if (!all(is.finite(y_limits))) {
        y_limits <- NULL
      }
      
      response_plots[[resp]] <- build_plot(stats_df, resp, y_limits)
      max_strata_rows <- max(max_strata_rows, 1)
      max_strata_cols <- max(max_strata_cols, 1)
    }
  }
  
  if (length(response_plots) == 0) {
    return(NULL)
  }
  
  resp_layout <- resolve_grid_layout(
    n_items = length(response_plots),
    rows_input = effective_input("resp_rows"),
    cols_input = effective_input("resp_cols")
  )
  
  final_plot <- if (length(response_plots) == 1) {
    response_plots[[1]]
  } else {
    patchwork::wrap_plots(
      plotlist = response_plots,
      nrow = resp_layout$nrow,
      ncol = resp_layout$ncol
    ) &
      patchwork::plot_layout(guides = "collect")
  }
  
  list(
    plot = final_plot,
    layout = list(
      strata = list(rows = max_strata_rows, cols = max_strata_cols),
      responses = resp_layout
    ),
    has_strata = has_strata,
    n_responses = length(response_plots)
  )
}

# ---------------------------------------------------------------
# Low-level utilities
# ---------------------------------------------------------------
sanitize_name <- function(name) {
  safe <- gsub("[^A-Za-z0-9]+", "_", name)
  safe <- gsub("_+", "_", safe)
  safe <- gsub("^_|_$", "", safe)
  if (!nzchar(safe)) safe <- "unnamed"
  safe
}

format_p_value <- function(p_values) {
  vapply(
    p_values,
    function(p) {
      if (is.na(p)) {
        return(NA_character_)
      }
      if (p < 0.001) {
        "<0.001"
      } else {
        sprintf("%.2f", round(p, 2))
      }
    },
    character(1)
  )
}

add_significance_marker <- function(formatted_p, raw_p) {
  mapply(
    function(fp, rp) {
      if (is.na(rp)) {
        return(fp)
      }
      if (rp < 0.05) {
        paste0(fp, "*")
      } else {
        fp
      }
    },
    formatted_p,
    raw_p,
    USE.NAMES = FALSE
  )
}


# ===============================================================
# 🧪 Table Analyzer — Two-way ANOVA Module
# ===============================================================

two_way_anova_ui <- function(id) {
  ns <- NS(id)
  list(
    config = tagList(
      uiOutput(ns("inputs")),
      uiOutput(ns("level_order_1")),
      uiOutput(ns("level_order_2")),
      tags$details(
        tags$summary(strong("Advanced options")),
        br(),
        stratification_ui("strat", ns)
      ),
      br(),
      fluidRow(
        column(6, actionButton(ns("run"), "Show results", width = "100%")),
        column(6, downloadButton(ns("download_all"), "Download all results", style = "width: 100%;"))
      )
    ),
    results = tagList(
      uiOutput(ns("summary_ui"))
    )
  )
}

two_way_anova_server <- function(id, filtered_data) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    
    # -----------------------------------------------------------
    # Reactive data
    # -----------------------------------------------------------
    df <- filtered_data
    
    # -----------------------------------------------------------
    # Dynamic inputs
    # -----------------------------------------------------------
    responses <- multi_response_server("response", df)

    output$inputs <- renderUI({
      req(df())
      data <- df()
      cat_cols <- names(data)[sapply(data, function(x) is.character(x) || is.factor(x))]

      tagList(
        multi_response_ui(ns("response")),
        selectInput(
          ns("factor1"),
          "Categorical predictor 1 (x-axis):",
          choices = cat_cols,
          selected = if (length(cat_cols) > 0) cat_cols[1] else NULL
        ),
        selectInput(
          ns("factor2"),
          "Categorical predictor 2 (lines):",
          choices = cat_cols,
          selected = if (length(cat_cols) > 1) cat_cols[2] else NULL
        )
      )
    })
    
    strat_info <- stratification_server("strat", df)
    
    # -----------------------------------------------------------
    # Level order selections
    # -----------------------------------------------------------
    output$level_order_1 <- renderUI({
      req(df(), input$factor1)
      levels1 <- unique(as.character(df()[[input$factor1]]))
      selectInput(
        ns("order1"),
        paste("Order of levels (first = reference):", input$factor1, "(x-axis)"),
        choices = levels1,
        selected = levels1,
        multiple = TRUE
      )
    })
    
    output$level_order_2 <- renderUI({
      req(df(), input$factor2)
      levels2 <- unique(as.character(df()[[input$factor2]]))
      selectInput(
        ns("order2"),
        paste("Order of levels (first = reference):", input$factor2, "(lines)"),
        choices = levels2,
        selected = levels2,
        multiple = TRUE
      )
    })
    
    # -----------------------------------------------------------
    # Model fitting (via shared helper)
    # -----------------------------------------------------------
    models <- eventReactive(input$run, {
      req(df(), input$factor1, input$order1, input$factor2, input$order2)
      resp_vals <- responses()
      req(length(resp_vals) > 0)
      prepare_stratified_anova(
        df = df(),
        responses = resp_vals,
        model = "twoway_anova",
        factor1_var = input$factor1,
        factor1_order = input$order1,
        factor2_var = input$factor2,
        factor2_order = input$order2,
        stratification = strat_info()
      )
    })
    
    

    # -----------------------------------------------------------
    # Download all results as one combined DOCX
    # -----------------------------------------------------------
    output$download_all <- downloadHandler(
      filename = function() {
        model_info <- models()
        if (is.null(model_info)) return("anova_results.docx")
        
        n_resp <- length(model_info$responses)
        n_strata <- if (is.null(model_info$strata)) 0 else length(model_info$strata$levels)
        strata_label <- ifelse(n_strata == 0, "nostratum", paste0(n_strata, "strata"))
        timestamp <- format(Sys.time(), "%Y%m%d-%H%M")
        sprintf("anova_results_%sresp_%s_%s.docx", n_resp, strata_label, timestamp)
      },
      content = function(file) {
        model_info <- models()
        if (is.null(model_info)) stop("Please run the ANOVA first.")
        download_all_anova_results(model_info, file)
      }
    )
    
    # -----------------------------------------------------------
    # Render results
    # -----------------------------------------------------------
    output$summary_ui <- renderUI({
      render_anova_results(ns, models(), "Two-way ANOVA")
    })
    
    # -----------------------------------------------------------
    # Render model summaries + downloads (shared helper)
    # -----------------------------------------------------------
    bind_anova_outputs(ns, output, models)

    df_final <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      mod$data_used
    })

    model_fit <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      mod$models
    })

    compiled_results <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      compile_anova_results(mod)
    })

    summary_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$summary
    })

    posthoc_results <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$posthoc
    })

    effect_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$effects
    })

    error_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$errors
    })

    reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)

      data_used <- df_final()

      list(
        analysis_type = "ANOVA",
        data_used = data_used,
        model = model_fit(),
        summary = summary_table(),
        posthoc = posthoc_results(),
        effects = effect_table(),
        stats = if (!is.null(data_used)) list(n = nrow(data_used), vars = names(data_used)) else NULL,
        metadata = list(
          responses = mod$responses,
          strata = mod$strata,
          factors = mod$factors,
          orders = mod$orders,
          errors = error_table()
        ),
        type = "twoway_anova",
        models = model_fit(),
        responses = mod$responses,
        strata = mod$strata,
        factors = mod$factors,
        orders = mod$orders
      )
    })
  })
}
# ===============================================================
# 🧪 Visualization Module — Two-way ANOVA (Simplified & Consistent)
# ===============================================================

visualize_twoway_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 4 — Visualize two-way ANOVA"),
      p("Select visualization type and adjust subplot layout, axis scaling, and figure size."),
      hr(),
      selectInput(
        ns("plot_type"),
        label = "Select visualization type:",
        choices = c("Mean ± SE" = "mean_se"),
        selected = "mean_se"
      ),
      hr(),
      uiOutput(ns("layout_controls")),
      fluidRow(
        column(6, numericInput(ns("plot_width"), "Subplot width (px)",  value = 400, min = 200, max = 1200, step = 50)),
        column(6, numericInput(ns("plot_height"), "Subplot height (px)", value = 300, min = 200, max = 1200, step = 50))
      ),
      hr(),
      add_color_customization_ui(ns, multi_group = TRUE),
      hr(),
      downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
    ),
    mainPanel(
      width = 8,
      h4("Plots"),
      plotOutput(ns("plot"), height = "auto")   # ✅ same as one-way
    )
  )
}


visualize_twoway_server <- function(id, filtered_data, model_fit) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    df <- reactive(filtered_data())
    
    model_info <- reactive(model_fit())
    
    layout_state <- initialize_layout_state(input, session)

    # ---- color customization ----
    color_var_reactive <- reactive({
      info <- model_info()
      if (is.null(info)) return(NULL)
      info$factors$factor2   # color lines by factor2
    })

    custom_colors <- add_color_customization_server(
      ns = ns,
      input = input,
      output = output,
      data = df,
      color_var_reactive = color_var_reactive,
      multi_group = TRUE
    )

    plot_info <- reactive({
      info <- model_info()
      if (is.null(info) || info$type != "twoway_anova") return(NULL)
      data <- df()
      line_colors <- custom_colors()
      if (is.null(line_colors) || length(line_colors) == 0) {
        line_colors <- NULL
      }
      build_anova_plot_info(
        data,
        info,
        layout_state$effective_input,
        line_colors = line_colors
      )
    })

    observe_layout_synchronization(plot_info, layout_state, session)
    
    plot_obj <- reactive({
      info <- plot_info()
      if (is.null(info)) return(NULL)
      info$plot
    })
    
    plot_size <- reactive({
      info <- plot_info()
      if (is.null(info)) return(list(w = input$plot_width, h = input$plot_height))
      s <- info$layout
      list(
        w = input$plot_width  * s$strata$cols   * s$responses$ncol,
        h = input$plot_height * s$strata$rows   * s$responses$nrow
      )
    })
    
    output$layout_controls <- renderUI({
      info <- model_info()
      if (is.null(info) || info$type != "twoway_anova") return(NULL)
      build_anova_layout_controls(ns, input, info, layout_state$default_ui_value)
    })
    
    # ✅ simpler, consistent naming and structure
    output$plot <- renderPlot({
      info <- model_info()
      req(info, input$plot_type)

      if (input$plot_type == "mean_se") {
        req(plot_obj())
        plot_obj()
      }
    },
    width = function() plot_size()$w,
    height = function() plot_size()$h,
    res = 96)
    
    output$download_plot <- downloadHandler(
      filename = function() paste0(input$plot_type, "_twoway_anova_plot_", Sys.Date(), ".png"),
      content = function(file) {
        req(plot_obj())
        s <- plot_size()
        ggsave(
          filename = file,
          plot = plot_obj(),
          device = "png",
          dpi = 300,
          width  = s$w / 96,
          height = s$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )
  })
}
# ===============================================================
# 🎨 Compact dropdown-style color picker (4x4 grid)
# ===============================================================

# ---- Palette ----
basic_color_palette <- c(
  "steelblue", "red", "green", "blue",
  "orange", "purple", "brown", "gold",
  "pink", "cyan", "magenta", "yellow",
  "black", "gray", "darkgreen", "darkred"
)

# ---- UI Helper ----
color_dropdown_input <- function(ns, id = "color_choice", palette = basic_color_palette,
                                 ncol = 4, selected = NULL) {
  selected_color <- if (is.null(selected)) palette[1] else selected

  tagList(
    tags$style(HTML(sprintf("
      .color-dropdown {
        position: relative;
        display: inline-block;
        width: 150px;
        user-select: none;
      }
      .color-dropdown-button {
        width: 100%%;
        height: 32px;
        border: 1px solid #ccc;
        border-radius: 4px;
        cursor: pointer;
      }
      .color-dropdown-grid {
        display: none;
        position: absolute;
        top: 36px;
        left: 0;
        z-index: 999;
        background: white;
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 4px;
        display: grid;
        grid-template-columns: repeat(%d, 28px);
        gap: 2px;
      }
      .color-cell {
        width: 26px; height: 26px;
        border-radius: 4px;
        cursor: pointer;
        border: 1px solid #ccc;
      }
      .color-cell:hover {
        transform: scale(1.1);
      }
    ", ncol))),
    tags$div(
      class = "color-dropdown",
      tags$div(
        id = ns(paste0(id, "_button")),
        class = "color-dropdown-button",
        style = sprintf("background-color:%s;", selected_color)
      ),
      tags$div(
        id = ns(paste0(id, "_grid")),
        class = "color-dropdown-grid",
        lapply(palette, function(col) {
          tags$div(
            class = "color-cell",
            title = col,
            style = sprintf("background-color:%s;", col),
            onclick = sprintf("
              $('#%s_button').css('background-color','%s');
              $('#%s_grid').hide();
              Shiny.setInputValue('%s','%s',{priority:'event'});
            ", ns(id), col, ns(id), ns(id), col)
          )
        })
      )
    ),
    tags$script(HTML(sprintf("
      $('#%s_button').on('click', function(e){
        e.stopPropagation();
        var grid = $('#%s_grid');
        $('.color-dropdown-grid').not(grid).hide();
        grid.toggle();
      });
      $(document).on('click', function(){
        $('.color-dropdown-grid').hide();
      });
      Shiny.setInputValue('%s','%s',{priority:'event'});
    ", ns(id), ns(id), ns(id), selected_color)))
  )
}
# ===============================================================
# 🧾 Table Analyzer — Descriptive Statistics Modules
# ===============================================================

descriptive_ui <- function(id) {
  ns <- NS(id)
  list(
    config = tagList(
      uiOutput(ns("inputs")),
      tags$details(
        tags$summary(strong("Advanced options")),
        br(),
        stratification_ui("strat", ns)
      ),
      br(),
      fluidRow(
        column(6, actionButton(ns("run"), "Show summary", width = "100%")),
        column(6, downloadButton(ns("download_summary"), "Download summary", style = "width: 100%;"))
      ),
      hr()
    ),
    results = tagList(
      verbatimTextOutput(ns("summary_text"))
    )
  )
}

descriptive_server <- function(id, filtered_data) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    df <- filtered_data

    # ------------------------------------------------------------
    # Dynamic inputs
    # ------------------------------------------------------------
    output$inputs <- renderUI({
      req(df())
      data <- df()
      cat_cols <- names(data)[vapply(data, function(x) is.character(x) || is.factor(x) || is.logical(x), logical(1))]
      num_cols <- names(data)[vapply(data, is.numeric, logical(1))]
      
      tagList(
        selectInput(ns("cat_vars"), label = "Categorical variables:", choices = cat_cols, selected = cat_cols, multiple = TRUE),
        br(),
        selectInput(ns("num_vars"), label = "Numeric variables:", choices = num_cols, selected = num_cols, multiple = TRUE)
      )
    })
    
    strat_info <- stratification_server("strat", df)
    
    # ------------------------------------------------------------
    # Summary computation
    # ------------------------------------------------------------
    summary_data <- eventReactive(input$run, {
      req(df())
      raw_data <- df()
      local_data <- raw_data  # create a copy to avoid modifying shared reactive
      selected_vars <- unique(c(input$cat_vars, input$num_vars))
      validate(need(length(selected_vars) > 0, "Please select at least one variable."))

      strat_details <- strat_info()
      group_var <- strat_details$var
      data_columns <- selected_vars

      if (!is.null(group_var)) {
        # keep ONLY selected levels, in the exact order; drop NA and unused levels
        sel <- strat_details$levels
        if (!is.null(sel) && length(sel) > 0) {
          local_data <- dplyr::filter(local_data, .data[[group_var]] %in% sel)
          local_data[[group_var]] <- factor(as.character(local_data[[group_var]]), levels = sel)
        } else {
          local_data[[group_var]] <- factor(as.character(local_data[[group_var]]))
        }
        local_data <- droplevels(local_data)

        data_columns <- unique(c(data_columns, group_var))
      }

      data_columns <- data_columns[!is.na(data_columns) & nzchar(data_columns)]
      data_columns <- intersect(data_columns, names(local_data))
      local_data <- local_data[, data_columns, drop = FALSE]

      strata_levels <- if (!is.null(group_var) && group_var %in% names(local_data)) {
        levels(local_data[[group_var]])
      } else {
        NULL
      }

      list(
        summary = compute_descriptive_summary(local_data, group_var),
        selected_vars = selected_vars,
        group_var = group_var,
        processed_data = local_data,
        strata_levels = strata_levels
      )
    })
    
    
    
    # ------------------------------------------------------------
    # Print summary
    # ------------------------------------------------------------
    output$summary_text <- renderPrint({
      req(summary_data())
      print_summary_sections(summary_data()$summary)
    })
    
    # ------------------------------------------------------------
    # Download
    # ------------------------------------------------------------
    output$download_summary <- downloadHandler(
      filename = function() paste0("Descriptive_Statistics_", Sys.Date(), ".txt"),
      content = function(file) {
        results <- summary_data()
        req(results)
        sink(file)
        on.exit(sink(), add = TRUE)
        print_summary_sections(results$summary)
      }
    )
    
    # ------------------------------------------------------------
    # Return full model info
    # ------------------------------------------------------------
    df_final <- reactive({
      details <- summary_data()
      if (is.null(details)) return(NULL)
      details$processed_data
    })

    model_fit <- reactive(NULL)

    summary_table <- reactive({
      details <- summary_data()
      if (is.null(details)) return(NULL)
      details$summary
    })

    posthoc_results <- reactive(NULL)

    effect_table <- reactive(NULL)

    selected_vars_reactive <- reactive({
      details <- summary_data()
      if (is.null(details)) return(NULL)
      details$selected_vars
    })

    group_var_reactive <- reactive({
      details <- summary_data()
      if (is.null(details)) return(NULL)
      details$group_var
    })

    strata_levels_reactive <- reactive({
      details <- summary_data()
      if (is.null(details)) return(NULL)
      details$strata_levels
    })

    reactive({
      details <- summary_data()
      if (is.null(details)) return(NULL)

      data_used <- df_final()

      list(
        analysis_type = "DESCRIPTIVE",
        data_used = data_used,
        model = model_fit(),
        summary = summary_table(),
        posthoc = posthoc_results(),
        effects = effect_table(),
        stats = if (!is.null(data_used)) list(n = nrow(data_used), vars = names(data_used)) else NULL,
        metadata = list(
          selected_vars = details$selected_vars,
          group_var = details$group_var,
          strata_levels = details$strata_levels
        ),
        type = "descriptive",
        data = df,
        processed_data = df_final,
        selected_vars = selected_vars_reactive,
        group_var = group_var_reactive,
        strata_levels = strata_levels_reactive
      )
    })

  })
}

compute_descriptive_summary <- function(data, group_var = NULL) {
  numeric_vars <- names(data)[sapply(data, is.numeric)]
  
  group_data <- if (!is.null(group_var)) group_by(data, .data[[group_var]], .drop = TRUE) else data
  
  skim_out <- if (!is.null(group_var)) {
    group_data %>% skim()
  } else {
    skim(data)
  }
  
  cv_out <- group_data %>%
    summarise(across(
      where(is.numeric),
      ~ 100 * sd(.x, na.rm = TRUE) / mean(.x, na.rm = TRUE),
      .names = "cv_{.col}"
    ), .groups = "drop")
  
  outlier_out <- group_data %>%
    summarise(across(
      all_of(numeric_vars),
      ~ {
        q <- quantile(.x, probs = c(0.25, 0.75), na.rm = TRUE)
        iqr <- q[2] - q[1]
        sum(.x < q[1] - 1.5 * iqr | .x > q[2] + 1.5 * iqr, na.rm = TRUE)
      },
      .names = "outliers_{.col}"
    ), .groups = "drop")
  
  missing_out <- group_data %>%
    summarise(across(
      all_of(numeric_vars),
      ~ 100 * mean(is.na(.x)),
      .names = "missing_{.col}"
    ), .groups = "drop")
  
  shapiro_out <- group_data %>%
    summarise(across(
      all_of(numeric_vars),
      ~ tryCatch(shapiro.test(.x)$p.value, error = function(e) NA_real_),
      .names = "shapiro_{.col}"
    ), .groups = "drop")
  
  list(
    skim = skim_out,
    cv = cv_out,
    outliers = outlier_out,
    missing = missing_out,
    shapiro = shapiro_out
  )
}

# ---- Shared printing ----
print_summary_sections <- function(results) {
  # 1) Print skim AS-IS (unchanged)
  cat(paste(capture.output(print(results$skim)), collapse = "\n"), "\n\n", sep = "")
  
  # 2) Helper to detect if a grouping column exists and what it's called
  metric_prefix <- "^(cv_|outliers_|missing_|shapiro_)"
  first_col <- if (!is.null(results$cv) && ncol(results$cv) > 0) names(results$cv)[1] else NULL
  group_col <- if (!is.null(first_col) && !grepl(metric_prefix, first_col)) first_col else NULL
  
  # 3) Robust long conversion that preserves the real group column name (if any)
  to_long <- function(df, value_name, group_col) {
    if (is.null(df) || ncol(df) == 0) {
      if (is.null(group_col)) {
        return(tibble::tibble(variable = character(), !!value_name := numeric()))
      } else {
        return(tibble::tibble(!!group_col := character(), variable = character(), !!value_name := numeric()))
      }
    }
    if (is.null(group_col)) {
      out <- tidyr::pivot_longer(df, tidyselect::everything(),
                                 names_to = "variable", values_to = value_name)
    } else {
      out <- tidyr::pivot_longer(df, -dplyr::all_of(group_col),
                                 names_to = "variable", values_to = value_name)
    }
    out$variable <- sub("^(cv_|outliers_|missing_|shapiro_)", "", out$variable)
    out
  }
  
  # 4) Build pieces (no "missing" here)
  cv_long   <- to_long(results$cv,       "cv",        group_col)
  out_long  <- to_long(results$outliers, "outliers",  group_col)
  shap_long <- to_long(results$shapiro,  "shapiro_p", group_col)
  
  # 5) Join by the right keys
  if (is.null(group_col)) {
    merged <- dplyr::full_join(cv_long,  out_long,  by = "variable") |>
      dplyr::full_join(shap_long, by = "variable")
  } else {
    merged <- dplyr::full_join(cv_long,  out_long,  by = c(group_col, "variable")) |>
      dplyr::full_join(shap_long, by = c(group_col, "variable"))
  }
  
  # 6) Round / order by numeric skim order
  merged <- merged |>
    dplyr::mutate(
      cv = round(cv, 2),
      shapiro_p = signif(shapiro_p, 3)
    )
  
  numeric_order <- NULL
  if (is.data.frame(results$skim) &&
      all(c("skim_type", "skim_variable") %in% names(results$skim))) {
    numeric_order <- results$skim |>
      dplyr::filter(.data$skim_type == "numeric") |>
      dplyr::pull(.data$skim_variable) |>
      unique()
  }
  if (!is.null(numeric_order) && length(numeric_order) > 0) {
    merged$variable <- factor(merged$variable, levels = numeric_order)
    if (is.null(group_col)) {
      merged <- dplyr::arrange(merged, .data$variable)
    } else {
      merged <- dplyr::arrange(merged, .data[[group_col]], .data$variable)
    }
    merged$variable <- as.character(merged$variable)
  } else {
    if (is.null(group_col)) {
      merged <- dplyr::arrange(merged, .data$variable)
    } else {
      merged <- dplyr::arrange(merged, .data[[group_col]], .data$variable)
    }
  }
  
  # 7) Print with/without group column
  cat("── Numeric variables summary ──\n")
  if (is.null(group_col)) {
    final_df <- merged[, c("variable","cv","outliers","shapiro_p"), drop = FALSE]
  } else {
    final_df <- merged[, c("variable", group_col, "cv","outliers","shapiro_p"), drop = FALSE]
  }
  print(as.data.frame(final_df), row.names = FALSE)
  
  cat("\nInterpretation:\n")
  cat("  • outliers = # beyond 1.5×IQR\n")
  cat("  • shapiro_p < 0.05 → non-normal distribution\n")
  
  invisible(NULL)
}
# ===============================================================
# Visualization Module — Descriptive Statistics (Dispatcher)
# ===============================================================

visualize_descriptive_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 5 — Visualize descriptive statistics"),
      p("Explore distributions, variability, and normality across variables."),
      hr(),
      selectInput(
        ns("plot_type"),
        label = "Select visualization type:",
        choices = c(
          "Categorical distributions" = "categorical",
          "Numeric boxplots"          = "boxplots",
          "Numeric histograms"        = "histograms",
          "CV (%)"                    = "cv",
          "Outlier counts"            = "outliers",
          "Missingness (%)"           = "missing"
        ),
        selected = "categorical"
      ),
      hr(),
      uiOutput(ns("sub_controls"))  # controls from active submodule
    ),
    mainPanel(
      width = 8,
      h4("Plots"),
      uiOutput(ns("plot_ui"))  # plot output provided by the active submodule
    )
  )
}


visualize_descriptive_server <- function(id, filtered_data, descriptive_summary) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    active_type <- reactive({
      type <- input$plot_type
      if (is.null(type) || !length(type) || !nzchar(type[[1]])) {
        "categorical"
      } else {
        type[[1]]
      }
    })

    # ==========================================================
    # 🔹 Inject the correct UI for each submodule
    # ==========================================================
    output$sub_controls <- renderUI({
      type <- active_type()
      switch(type,
             "categorical" = visualize_categorical_barplots_ui(ns("categorical")),
             "boxplots"    = visualize_numeric_boxplots_ui(ns("boxplots")),
             "histograms"  = visualize_numeric_histograms_ui(ns("histograms")),
             "cv"          = visualize_cv_ui(ns("cv")),
             "outliers"    = visualize_outliers_ui(ns("outliers")),
             "missing"     = visualize_missing_ui(ns("missing")),
             div("No controls available for this plot type.")
      )
    })

    output$plot_ui <- renderUI({
      type <- active_type()
      switch(type,
             "categorical" = visualize_categorical_barplots_plot_ui(ns("categorical")),
             "boxplots"    = visualize_numeric_boxplots_plot_ui(ns("boxplots")),
             "histograms"  = visualize_numeric_histograms_plot_ui(ns("histograms")),
             "cv"          = visualize_cv_plot_ui(ns("cv")),
             "outliers"    = visualize_outliers_plot_ui(ns("outliers")),
             "missing"     = visualize_missing_plot_ui(ns("missing")),
             div("Plot not available for this selection.")
      )
    })

    categorical_active <- reactive(active_type() == "categorical")
    boxplots_active    <- reactive(active_type() == "boxplots")
    histograms_active  <- reactive(active_type() == "histograms")
    cv_active          <- reactive(active_type() == "cv")
    outliers_active    <- reactive(active_type() == "outliers")
    missing_active     <- reactive(active_type() == "missing")

    visualize_categorical_barplots_server(
      "categorical",
      filtered_data,
      descriptive_summary,
      is_active = categorical_active
    )
    visualize_numeric_boxplots_server(
      "boxplots",
      filtered_data,
      descriptive_summary,
      is_active = boxplots_active
    )
    visualize_numeric_histograms_server(
      "histograms",
      filtered_data,
      descriptive_summary,
      is_active = histograms_active
    )
    visualize_cv_server(
      "cv",
      filtered_data,
      descriptive_summary,
      is_active = cv_active
    )
    visualize_outliers_server(
      "outliers",
      filtered_data,
      descriptive_summary,
      is_active = outliers_active
    )
    visualize_missing_server(
      "missing",
      filtered_data,
      descriptive_summary,
      is_active = missing_active
    )
  })
}
# ===============================================================
# 🟦 Descriptive Visualization — Categorical Barplots
# ===============================================================

visualize_categorical_barplots_ui <- function(id) {
  ns <- NS(id)
  tagList(
    checkboxInput(ns("show_proportions"), "Show proportions instead of counts", FALSE),
    fluidRow(
      column(6, numericInput(ns("plot_width"),  "Subplot width (px)",  400, 200, 2000, 50)),
      column(6, numericInput(ns("plot_height"), "Subplot height (px)", 300, 200, 2000, 50))
    ),
    hr(),
    fluidRow(
      column(
        6,
        numericInput(
          ns("n_rows"),
          "Grid rows",
          value = 3,
          min = 1,
          max = 10,
          step = 1
        )
      ),
      column(
        6,
        numericInput(
          ns("n_cols"),
          "Grid columns",
          value = 2,
          min = 1,
          max = 10,
          step = 1
        )
      )
    ),
    hr(),
    add_color_customization_ui(ns, multi_group = TRUE),
    hr(),
    downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
  )
}

visualize_categorical_barplots_plot_ui <- function(id) {
  ns <- NS(id)
  div(
    class = "ta-plot-container",
    plotOutput(ns("plot"), width = "100%", height = "auto")
  )
}

visualize_categorical_barplots_server <- function(id, filtered_data, summary_info, is_active = NULL) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    resolve_input_value <- function(x) {
      if (is.null(x)) return(NULL)
      if (is.reactive(x)) x() else x
    }

    module_active <- reactive({
      if (is.null(is_active)) {
        TRUE
      } else {
        isTRUE(is_active())
      }
    })

    plot_width <- reactive({
      w <- input$plot_width
      if (is.null(w) || !is.numeric(w) || is.na(w)) 400 else w
    })

    plot_height <- reactive({
      h <- input$plot_height
      if (is.null(h) || !is.numeric(h) || is.na(h)) 300 else h
    })
    
    color_var_reactive <- reactive({
      info <- summary_info()
      if (is.null(info)) return(NULL)

      group_var <- resolve_input_value(info$group_var)
      if (is.null(group_var) || identical(group_var, "") || identical(group_var, "None")) {
        return(NULL)
      }

      dat <- filtered_data()
      if (is.null(dat) || !is.data.frame(dat) || !group_var %in% names(dat)) {
        return(NULL)
      }

      group_var
    })

    custom_colors <- add_color_customization_server(
      ns = ns,
      input = input,
      output = output,
      data = filtered_data,
      color_var_reactive = color_var_reactive,
      multi_group = TRUE
    )

    plot_info <- reactive({
      req(module_active())

      info <- summary_info()

      validate(need(!is.null(info), "Summary not available."))

      processed <- resolve_input_value(info$processed_data)
      dat <- if (!is.null(processed)) processed else filtered_data()

      validate(need(!is.null(dat) && is.data.frame(dat) && nrow(dat) > 0, "No data available."))

      selected_vars <- resolve_input_value(info$selected_vars)
      group_var     <- resolve_input_value(info$group_var)
      strata_levels <- resolve_input_value(info$strata_levels)

      out <- build_descriptive_categorical_plot(
        df = dat,
        selected_vars = selected_vars,
        group_var = group_var,
        strata_levels = strata_levels,
        show_proportions = isTRUE(input$show_proportions),
        nrow_input = input$n_rows,
        ncol_input = input$n_cols,
        fill_colors = custom_colors()
      )
      validate(need(!is.null(out), "No categorical variables available for plotting."))
      out
    })

    plot_size <- reactive({
      req(module_active())

      info <- plot_info()
      if (is.null(info$layout)) {
        list(w = plot_width(), h = plot_height())
      } else {
        list(
          w = plot_width()  * info$layout$ncol,
          h = plot_height() * info$layout$nrow
        )
      }
    })
    
    output$download_plot <- downloadHandler(
      filename = function() paste0("categorical_barplots_", Sys.Date(), ".png"),
      content  = function(file) {
        req(module_active())
        info <- plot_info()
        req(info$plot)
        s <- plot_size()
        ggplot2::ggsave(
          filename = file,
          plot = info$plot,
          device = "png",
          dpi = 300,
          width  = s$w / 96,
          height = s$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )

    output$plot <- renderPlot({
      req(module_active())
      info <- plot_info()
      validate(need(!is.null(info$plot), "No plot available."))
      print(info$plot)
    },
    width = function() {
      req(module_active())
      plot_size()$w
    },
    height = function() {
      req(module_active())
      plot_size()$h
    },
    res = 96)
  })
}


build_descriptive_categorical_plot <- function(df,
                                               selected_vars = NULL,
                                               group_var = NULL,
                                               strata_levels = NULL,
                                               show_proportions = FALSE,
                                               nrow_input = NULL,
                                               ncol_input = NULL,
                                               fill_colors = NULL) {
  if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(NULL)
  
  factor_vars <- names(df)[vapply(df, function(x) {
    is.character(x) || is.factor(x) || is.logical(x)
  }, logical(1))]
  
  if (!is.null(selected_vars) && length(selected_vars) > 0) {
    factor_vars <- intersect(factor_vars, selected_vars)
  }
  if (length(factor_vars) == 0) return(NULL)
  
  if (!is.null(group_var) && group_var %in% names(df)) {
    df[[group_var]] <- as.character(df[[group_var]])
    df[[group_var]][is.na(df[[group_var]]) | trimws(df[[group_var]]) == ""] <- "Missing"
    
    if (!is.null(strata_levels) && length(strata_levels) > 0) {
      keep_levels <- unique(strata_levels)
      df <- df[df[[group_var]] %in% keep_levels, , drop = FALSE]
      if (nrow(df) == 0) return(NULL)
      df[[group_var]] <- factor(df[[group_var]], levels = keep_levels)
    } else {
      df[[group_var]] <- factor(df[[group_var]], levels = unique(df[[group_var]]))
    }
  } else {
    group_var <- NULL
  }
  
  plots <- lapply(factor_vars, function(var) {
    group_col <- if (!is.null(group_var) && !identical(group_var, var)) group_var else NULL
    cols_to_use <- c(var, group_col)
    cols_to_use <- cols_to_use[cols_to_use %in% names(df)]
    var_data <- df[, cols_to_use, drop = FALSE]
    
    var_data[[var]] <- as.character(var_data[[var]])
    keep <- !is.na(var_data[[var]]) & trimws(var_data[[var]]) != ""
    if (!any(keep)) return(NULL)
    var_data <- var_data[keep, , drop = FALSE]
    
    level_order <- if (is.factor(df[[var]])) {
      as.character(levels(df[[var]]))
    } else {
      unique(var_data[[var]])
    }
    var_data[[var]] <- factor(var_data[[var]], levels = level_order)
    
    y_label <- if (isTRUE(show_proportions)) "Proportion" else "Count"
    
    if (!is.null(group_col)) {
      var_data[[group_col]] <- droplevels(var_data[[group_col]])
      count_df <- dplyr::count(var_data, .data[[var]], .data[[group_col]], name = "count")
      if (nrow(count_df) == 0) return(NULL)
      
      if (isTRUE(show_proportions)) {
        count_df <- count_df |>
          dplyr::group_by(.data[[group_col]]) |>
          dplyr::mutate(total = sum(.data$count, na.rm = TRUE)) |>
          dplyr::mutate(value = ifelse(.data$total > 0, .data$count / .data$total, 0)) |>
          dplyr::ungroup()
        count_df$total <- NULL
      } else {
        count_df <- dplyr::mutate(count_df, value = .data$count)
      }
      
      count_df[[var]] <- factor(as.character(count_df[[var]]), levels = level_order)
      group_levels <- levels(droplevels(var_data[[group_col]]))
      count_df[[group_col]] <- factor(as.character(count_df[[group_col]]), levels = group_levels)
      
      palette <- resolve_palette_for_levels(group_levels, custom = fill_colors)
      
      p <- ggplot(count_df, aes(x = .data[[var]], y = .data$value, fill = .data[[group_col]])) +
        geom_col(position = position_dodge(width = 0.75), width = 0.65) +
        scale_fill_manual(values = palette) +
        theme_minimal(base_size = 13) +
        labs(title = var, x = NULL, y = y_label, fill = group_col) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
      
      if (isTRUE(show_proportions)) {
        p <- p + scale_y_continuous(labels = scales::percent_format(accuracy = 1), limits = c(0, 1))
      }
      
      p
    } else {
      count_df <- dplyr::count(var_data, .data[[var]], name = "count")
      if (nrow(count_df) == 0) return(NULL)
      
      total <- sum(count_df$count, na.rm = TRUE)
      if (isTRUE(show_proportions) && total > 0) {
        count_df$value <- count_df$count / total
      } else {
        count_df$value <- count_df$count
      }
      
      count_df[[var]] <- factor(as.character(count_df[[var]]), levels = level_order)
      
      single_fill <- if (!is.null(fill_colors) && length(fill_colors) > 0) {
        fill_colors[1]
      } else {
        resolve_single_color()
      }
      
      p <- ggplot(count_df, aes(x = .data[[var]], y = .data$value)) +
        geom_col(fill = single_fill, width = 0.65) +
        theme_minimal(base_size = 13) +
        labs(title = var, x = NULL, y = y_label) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
      
      
      if (isTRUE(show_proportions)) {
        p <- p + scale_y_continuous(labels = scales::percent_format(accuracy = 1), limits = c(0, 1))
      }
      
      p
    }
  })
  
  plots <- Filter(Negate(is.null), plots)
  if (length(plots) == 0) return(NULL)
  
  # ✅ Use the common layout helper to arrange plots using the requested grid
  layout <- resolve_grid_layout(
    n_items   = length(plots),
    rows_input = suppressWarnings(as.numeric(nrow_input)),
    cols_input = suppressWarnings(as.numeric(ncol_input))
  )
  
  combined <- patchwork::wrap_plots(plots, nrow = layout$nrow, ncol = layout$ncol) +
    patchwork::plot_annotation(
      theme = theme(plot.title = element_text(size = 16, face = "bold"))
    )
  
  list(
    plot = combined,
    layout = list(nrow = layout$nrow, ncol = layout$ncol),
    panels = length(plots)
  )
}

# ===============================================================
# 🟦 Descriptive Visualization — Summary Metrics
# ===============================================================

# ---- UI helpers ----
metric_panel_ui <- function(id, default_width = 400, default_height = 300,
                            default_rows = 2, default_cols = 3) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(6, numericInput(ns("plot_width"),  "Subplot width (px)",  default_width, 200, 2000, 50)),
      column(6, numericInput(ns("plot_height"), "Subplot height (px)", default_height, 200, 2000, 50))
    ),
    hr(),
    fluidRow(
      column(6, numericInput(ns("n_rows"), "Grid rows",    value = default_rows, min = 1, max = 10, step = 1)),
      column(6, numericInput(ns("n_cols"), "Grid columns", value = default_cols, min = 1, max = 10, step = 1))
    ),
    hr(),
    downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
  )
}


visualize_cv_ui <- function(id) {
  metric_panel_ui(id, default_width = 400, default_height = 320, default_rows = 2, default_cols = 3)
}

visualize_outliers_ui <- function(id) {
  metric_panel_ui(id, default_width = 400, default_height = 320, default_rows = 2, default_cols = 3)
}

visualize_missing_ui <- function(id) {
  metric_panel_ui(id, default_width = 400, default_height = 320, default_rows = 2, default_cols = 3)
}

metric_plot_ui <- function(id) {
  ns <- NS(id)
  div(
    class = "ta-plot-container",
    plotOutput(ns("plot"), width = "100%", height = "auto")
  )
}

visualize_cv_plot_ui <- function(id) {
  metric_plot_ui(id)
}

visualize_outliers_plot_ui <- function(id) {
  metric_plot_ui(id)
}

visualize_missing_plot_ui <- function(id) {
  metric_plot_ui(id)
}


# ---- Shared computation helpers ----
resolve_metric_input <- function(x) {
  if (is.null(x)) return(NULL)
  if (is.reactive(x)) x() else x
}

safe_numeric_input <- function(value, default = 1L) {
  val <- suppressWarnings(as.integer(value))
  if (length(val) == 0 || is.na(val) || val <= 0) {
    return(default)
  }
  max(1L, min(10L, val))
}

safe_cv <- function(x) {
  m <- mean(x, na.rm = TRUE)
  s <- stats::sd(x, na.rm = TRUE)
  if (!is.finite(m) || abs(m) < .Machine$double.eps) {
    return(NA_real_)
  }
  100 * s / m
}

count_outliers <- function(x) {
  q <- stats::quantile(x, probs = c(0.25, 0.75), na.rm = TRUE)
  iqr <- q[2] - q[1]
  sum(x < q[1] - 1.5 * iqr | x > q[2] + 1.5 * iqr, na.rm = TRUE)
}

missing_pct <- function(x) {
  100 * mean(is.na(x))
}

prepare_metric_data <- function(data, numeric_vars, group_var, strata_levels, metric) {
  if (length(numeric_vars) == 0) {
    return(NULL)
  }

  if (is.null(group_var) || !group_var %in% names(data)) {
    group_var <- NULL
  }

  data_tbl <- tibble::as_tibble(data)

  if (!is.null(group_var)) {
    if (!is.null(strata_levels) && length(strata_levels) > 0) {
      data_tbl[[group_var]] <- factor(as.character(data_tbl[[group_var]]), levels = strata_levels)
      data_tbl <- droplevels(data_tbl)
    }
    data_tbl <- dplyr::group_by(data_tbl, .data[[group_var]], .drop = TRUE)
  }

  summarised <- switch(
    metric,
    cv = dplyr::summarise(
      data_tbl,
      dplyr::across(
        dplyr::all_of(numeric_vars),
        ~ safe_cv(.x),
        .names = "cv_{.col}"
      ),
      .groups = "drop"
    ),
    outliers = dplyr::summarise(
      data_tbl,
      dplyr::across(
        dplyr::all_of(numeric_vars),
        ~ count_outliers(.x),
        .names = "outliers_{.col}"
      ),
      .groups = "drop"
    ),
    missing = dplyr::summarise(
      data_tbl,
      dplyr::across(
        dplyr::all_of(numeric_vars),
        ~ missing_pct(.x),
        .names = "missing_{.col}"
      ),
      .groups = "drop"
    ),
    stop("Unsupported metric type.")
  )

  tidy <- tidy_descriptive_metric(summarised, metric)
  if (is.null(tidy)) {
    return(NULL)
  }

  tidy$data <- tidy$data[tidy$data$variable %in% numeric_vars, , drop = FALSE]
  if (nrow(tidy$data) == 0) {
    return(NULL)
  }

  if (!is.null(group_var) && !is.null(strata_levels) && length(strata_levels) > 0) {
    tidy$data$.group <- factor(as.character(tidy$data$.group), levels = strata_levels)
  }

  tidy
}

tidy_descriptive_metric <- function(df, prefix) {
  if (is.null(df) || nrow(df) == 0) return(NULL)
  metric_cols <- grep(paste0("^", prefix, "_"), names(df), value = TRUE)
  if (length(metric_cols) == 0) return(NULL)
  group_cols <- setdiff(names(df), metric_cols)
  has_group <- length(group_cols) > 0
  group_label <- if (has_group) paste(group_cols, collapse = " / ") else NULL
  if (!has_group) {
    df <- df |> dplyr::mutate(.group = "Overall")
    group_cols <- ".group"
  }
  tidy <- df |>
    tidyr::unite(".group", dplyr::all_of(group_cols), sep = " / ", remove = FALSE) |>
    tidyr::pivot_longer(
      cols = dplyr::all_of(metric_cols),
      names_to = "variable",
      values_to = "value"
    ) |>
    dplyr::mutate(
      variable = gsub(paste0("^", prefix, "_"), "", .data$variable),
      value = ifelse(is.finite(.data$value), .data$value, NA_real_),
      .group = factor(.data$.group, levels = unique(.data$.group))
    ) |>
    tidyr::drop_na("value")
  if (nrow(tidy) == 0) return(NULL)
  list(data = tidy, has_group = has_group, group_label = group_label)
}


build_metric_plot <- function(metric_info, y_label, title, n_rows, n_cols) {
  df <- metric_info$data
  has_group <- isTRUE(metric_info$has_group)
  
  if (has_group) {
    legend_title <- if (!is.null(metric_info$group_label)) metric_info$group_label else "Group"
    palette <- resolve_palette_for_levels(levels(df$.group))
    p <- ggplot(df, aes(x = variable, y = value, fill = .group)) +
      geom_col(position = position_dodge(width = 0.7), width = 0.65) +
      scale_fill_manual(values = palette) +
      labs(fill = legend_title)
  } else {
    p <- ggplot(df, aes(x = variable, y = value)) +
      geom_col(width = 0.65, fill = resolve_single_color()) +
      guides(fill = "none")
  }
  
  p +
    theme_minimal(base_size = 13) +
    labs(x = NULL, y = y_label, title = title) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      panel.grid.minor = element_blank()
    )
}


metric_module_server <- function(id, filtered_data, summary_info, metric_key,
                                 y_label, title, filename_prefix, is_active = NULL) {
  moduleServer(id, function(input, output, session) {

    plot_width <- reactive({
      w <- input$plot_width
      if (is.null(w) || !is.numeric(w) || is.na(w)) 400 else w
    })

    plot_height <- reactive({
      h <- input$plot_height
      if (is.null(h) || !is.numeric(h) || is.na(h)) 300 else h
    })

    module_active <- reactive({
      if (is.null(is_active)) {
        TRUE
      } else {
        isTRUE(is_active())
      }
    })

    plot_details <- reactive({
      req(module_active())

      info <- summary_info()
      validate(need(!is.null(info), "Summary not available."))

      processed <- resolve_metric_input(info$processed_data)
      dat <- if (!is.null(processed)) processed else filtered_data()

      validate(need(!is.null(dat) && is.data.frame(dat) && nrow(dat) > 0, "No data available."))

      selected_vars <- resolve_metric_input(info$selected_vars)
      group_var <- resolve_metric_input(info$group_var)
      strata_levels <- resolve_metric_input(info$strata_levels)
      group_label <- resolve_metric_input(info$group_label)

      numeric_vars <- names(dat)[vapply(dat, is.numeric, logical(1))]
      if (!is.null(selected_vars) && length(selected_vars) > 0) {
        numeric_vars <- intersect(numeric_vars, selected_vars)
      }
      validate(need(length(numeric_vars) > 0, "No numeric variables available for plotting."))

      metric_info <- prepare_metric_data(
        data = dat,
        numeric_vars = numeric_vars,
        group_var = group_var,
        strata_levels = strata_levels,
        metric = metric_key
      )

      validate(need(!is.null(metric_info), "Unable to compute metric for the selected variables."))

      if (!is.null(group_label)) {
        metric_info$group_label <- group_label
      }

      n_rows <- safe_numeric_input(input$n_rows, default = 1L)
      n_cols <- safe_numeric_input(input$n_cols, default = 1L)

      plot <- build_metric_plot(metric_info, y_label, title, n_rows, n_cols)

      list(
        plot = plot,
        layout = list(nrow = n_rows, ncol = n_cols)
      )
    })

    plot_size <- reactive({
      req(module_active())
      details <- plot_details()
      if (is.null(details$layout)) {
        list(w = plot_width(), h = plot_height())
      } else {
        list(
          w = plot_width()  * details$layout$ncol,
          h = plot_height() * details$layout$nrow
        )
      }
    })

    output$download_plot <- downloadHandler(
      filename = function() paste0(filename_prefix, "_", Sys.Date(), ".png"),
      content = function(file) {
        req(module_active())
        details <- plot_details()
        req(details$plot)
        size <- plot_size()
        ggplot2::ggsave(
          filename = file,
          plot = details$plot,
          device = "png",
          dpi = 300,
          width = size$w / 96,
          height = size$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )

    output$plot <- renderPlot({
      req(module_active())
      details <- plot_details()
      validate(need(!is.null(details$plot), "No plot available."))
      print(details$plot)
    },
    width = function() {
      req(module_active())
      plot_size()$w
    },
    height = function() {
      req(module_active())
      plot_size()$h
    },
    res = 96)
  })
}


visualize_cv_server <- function(id, filtered_data, summary_info, is_active = NULL) {
  metric_module_server(
    id = id,
    filtered_data = filtered_data,
    summary_info = summary_info,
    metric_key = "cv",
    y_label = "CV (%)",
    title = "",
    filename_prefix = "cv_summary",
    is_active = is_active
  )
}

visualize_outliers_server <- function(id, filtered_data, summary_info, is_active = NULL) {
  metric_module_server(
    id = id,
    filtered_data = filtered_data,
    summary_info = summary_info,
    metric_key = "outliers",
    y_label = "Outlier Count",
    title = "",
    filename_prefix = "outlier_summary",
    is_active = is_active
  )
}

visualize_missing_server <- function(id, filtered_data, summary_info, is_active = NULL) {
  metric_module_server(
    id = id,
    filtered_data = filtered_data,
    summary_info = summary_info,
    metric_key = "missing",
    y_label = "Missing (%)",
    title = "",
    filename_prefix = "missing_summary",
    is_active = is_active
  )
}
# ===============================================================
# 🟦 Descriptive Visualization — Numeric Boxplots
# ===============================================================

visualize_numeric_boxplots_ui <- function(id) {
  ns <- NS(id)
  tagList(
    checkboxInput(ns("show_points"), "Show individual data points", TRUE),
    fluidRow(
      column(6, numericInput(ns("plot_width"),  "Subplot width (px)",  200, 200, 2000, 50)),
      column(6, numericInput(ns("plot_height"), "Subplot height (px)", 800, 200, 2000, 50))
    ),
    hr(),
    fluidRow(
      column(
        6,
        numericInput(
          ns("n_rows"),
          "Grid rows",
          value = 1,
          min = 1,
          max = 10,
          step = 1
        )
      ),
      column(
        6,
        numericInput(
          ns("n_cols"),
          "Grid columns",
          value = 6,
          min = 1,
          max = 10,
          step = 1
        )
      )
    ),
    hr(),
    downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
  )
}


visualize_numeric_boxplots_plot_ui <- function(id) {
  ns <- NS(id)
  div(
    class = "ta-plot-container",
    plotOutput(ns("plot"), width = "100%", height = "auto")
  )
}


visualize_numeric_boxplots_server <- function(id, filtered_data, summary_info, is_active = NULL) {
  moduleServer(id, function(input, output, session) {

    resolve_input_value <- function(x) {
      if (is.null(x)) return(NULL)
      if (is.reactive(x)) x() else x
    }

    module_active <- reactive({
      if (is.null(is_active)) {
        TRUE
      } else {
        isTRUE(is_active())
      }
    })

    plot_width <- reactive({
      w <- input$plot_width
      if (is.null(w) || !is.numeric(w) || is.na(w)) 400 else w
    })

    plot_height <- reactive({
      h <- input$plot_height
      if (is.null(h) || !is.numeric(h) || is.na(h)) 300 else h
    })

    plot_info <- reactive({
      req(module_active())

      info <- summary_info()

      validate(need(!is.null(info), "Summary not available."))

      processed <- resolve_input_value(info$processed_data)
      dat <- if (!is.null(processed)) processed else filtered_data()

      validate(need(!is.null(dat) && is.data.frame(dat) && nrow(dat) > 0, "No data available."))

      selected_vars <- resolve_input_value(info$selected_vars)
      group_var     <- resolve_input_value(info$group_var)
      
      out <- build_descriptive_numeric_boxplot(
        df = dat,
        selected_vars = selected_vars,
        group_var = group_var,
        show_points = isTRUE(input$show_points),
        nrow_input = input$n_rows,
        ncol_input = input$n_cols
      )

      validate(need(!is.null(out), "No numeric variables available for plotting."))
      out
    })

    plot_size <- reactive({
      req(module_active())
      info <- plot_info()
      if (is.null(info$layout)) {
        list(w = plot_width(), h = plot_height())
      } else {
        list(
          w = plot_width()  * info$layout$ncol,
          h = plot_height() * info$layout$nrow
        )
      }
    })
    
    output$download_plot <- downloadHandler(
      filename = function() paste0("numeric_boxplots_", Sys.Date(), ".png"),
      content  = function(file) {
        req(module_active())
        info <- plot_info()
        req(info$plot)
        s <- plot_size()
        ggplot2::ggsave(
          filename = file,
          plot = info$plot,
          device = "png",
          dpi = 300,
          width  = s$w / 96,
          height = s$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )

    output$plot <- renderPlot({
      req(module_active())
      info <- plot_info()
      validate(need(!is.null(info$plot), "No plot available."))
      print(info$plot)
    },
    width = function() {
      req(module_active())
      plot_size()$w
    },
    height = function() {
      req(module_active())
      plot_size()$h
    },
    res = 96)
  })
}


build_descriptive_numeric_boxplot <- function(df,
                                              selected_vars = NULL,
                                              group_var = NULL,
                                              show_points = TRUE,
                                              nrow_input = NULL,
                                              ncol_input = NULL) {
  if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(NULL)
  
  num_vars <- names(df)[vapply(df, is.numeric, logical(1))]
  if (!is.null(selected_vars) && length(selected_vars) > 0) {
    num_vars <- intersect(num_vars, selected_vars)
  }
  if (length(num_vars) == 0) return(NULL)
  
  # ensure discrete x if grouped
  if (!is.null(group_var) && group_var %in% names(df)) {
    df[[group_var]] <- as.factor(df[[group_var]])
  } else {
    group_var <- NULL
  }
  
  plots <- lapply(num_vars, function(var) {
    # skip all-NA vars early
    vec <- df[[var]]
    if (all(is.na(vec))) return(NULL)
    
    if (!is.null(group_var)) {
      group_levels <- levels(df[[group_var]])
      palette <- resolve_palette_for_levels(group_levels)
      p <- ggplot(df, aes(x = .data[[group_var]], y = .data[[var]], fill = .data[[group_var]])) +
        geom_boxplot(outlier.shape = NA, width = 0.6) +
        scale_fill_manual(values = palette) +
        theme_minimal(base_size = 13) +
        labs(title = var, x = NULL, y = var) +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
      if (isTRUE(show_points)) {
        p <- p +
          geom_jitter(aes(color = .data[[group_var]]), width = 0.2, alpha = 0.5, size = 1) +
          scale_color_manual(values = palette, guide = "none")
      }
    } else {
      # ✅ always provide an x aesthetic
      p <- ggplot(df, aes(x = factor(1), y = .data[[var]])) +
        geom_boxplot(fill = resolve_single_color(), width = 0.3) +
        theme_minimal(base_size = 13) +
        labs(title = var, x = NULL, y = var) +
        theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())
      if (isTRUE(show_points)) {
        p <- p + geom_jitter(color = resolve_single_color(), width = 0.05, alpha = 0.5, size = 1)
      }
    }
    
    if (inherits(p, "gg")) p else NULL
  })
  
  # keep only valid ggplots
  plots <- Filter(Negate(is.null), plots)
  if (length(plots) == 0) return(NULL)
  
  layout <- resolve_grid_layout(
    n_items = length(plots),
    rows_input = suppressWarnings(as.numeric(nrow_input)),
    cols_input = suppressWarnings(as.numeric(ncol_input))
  )
  
  combined <- patchwork::wrap_plots(plots, nrow = layout$nrow, ncol = layout$ncol) +
    patchwork::plot_annotation(
      theme = theme(plot.title = element_text(size = 16, face = "bold"))
    )
  
  list(
    plot = combined,
    layout = list(nrow = layout$nrow, ncol = layout$ncol),
    panels = length(plots)
  )
}# ===============================================================
# 🟦 Descriptive Visualization — Numeric Histograms
# ===============================================================

visualize_numeric_histograms_ui <- function(id) {
  ns <- NS(id)
  tagList(
    checkboxInput(ns("use_density"), "Show density instead of count", FALSE),
    fluidRow(
      column(6, numericInput(ns("plot_width"),  "Subplot width (px)",  400, 200, 2000, 50)),
      column(6, numericInput(ns("plot_height"), "Subplot height (px)", 300, 200, 2000, 50))
    ),
    hr(),
    fluidRow(
      column(6, numericInput(ns("n_rows"), "Grid rows",    value = 2, min = 1, max = 10, step = 1)),
      column(6, numericInput(ns("n_cols"), "Grid columns", value = 3, min = 1, max = 10, step = 1))
    ),
    hr(),
    downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
  )
}


visualize_numeric_histograms_plot_ui <- function(id) {
  ns <- NS(id)
  div(
    class = "ta-plot-container",
    plotOutput(ns("plot"), width = "100%", height = "auto")
  )
}


visualize_numeric_histograms_server <- function(id, filtered_data, summary_info, is_active = NULL) {
  moduleServer(id, function(input, output, session) {

    resolve_input_value <- function(x) {
      if (is.null(x)) return(NULL)
      if (is.reactive(x)) x() else x
    }

    module_active <- reactive({
      if (is.null(is_active)) {
        TRUE
      } else {
        isTRUE(is_active())
      }
    })

    plot_width <- reactive({
      w <- input$plot_width
      if (is.null(w) || !is.numeric(w) || is.na(w)) 400 else w
    })

    plot_height <- reactive({
      h <- input$plot_height
      if (is.null(h) || !is.numeric(h) || is.na(h)) 300 else h
    })

    plot_info <- reactive({
      req(module_active())

      info <- summary_info()

      validate(need(!is.null(info), "Summary not available."))

      processed <- resolve_input_value(info$processed_data)
      dat <- if (!is.null(processed)) processed else filtered_data()

      validate(need(!is.null(dat) && is.data.frame(dat) && nrow(dat) > 0, "No data available."))

      selected_vars <- resolve_input_value(info$selected_vars)
      group_var     <- resolve_input_value(info$group_var)
      strata_levels <- resolve_input_value(info$strata_levels)

      out <- build_descriptive_numeric_histogram(
        df = dat,
        selected_vars = selected_vars,
        group_var = group_var,
        strata_levels = strata_levels,
        use_density = isTRUE(input$use_density),
        nrow_input = input$n_rows,
        ncol_input = input$n_cols
      )

      validate(need(!is.null(out), "No numeric variables available for plotting."))

      n_panels <- out$panels
      max_val  <- 10L

      layout_info <- out$layout
      if (is.null(layout_info) || !is.list(layout_info)) {
        layout_info <- list()
      }

      safe_rows <- layout_info$nrow
      safe_cols <- layout_info$ncol

      if (is.null(safe_rows) || !is.finite(safe_rows)) {
        safe_rows <- min(10L, max(1L, as.integer(n_panels)))
      }
      if (is.null(safe_cols) || !is.finite(safe_cols)) {
        safe_cols <- min(10L, max(1L, ceiling(as.integer(n_panels) / max(1L, safe_rows))))
      }

      safe_rows <- min(max(1L, as.integer(safe_rows)), max_val)
      safe_cols <- min(max(1L, as.integer(safe_cols)), max_val)

      current_rows <- suppressWarnings(as.integer(input$n_rows))
      current_cols <- suppressWarnings(as.integer(input$n_cols))

      if (length(current_rows) == 0 || is.na(current_rows)) current_rows <- NULL
      if (length(current_cols) == 0 || is.na(current_cols)) current_cols <- NULL

      isolate({
        if (!identical(current_rows, safe_rows)) {
          updateNumericInput(session, "n_rows", value = safe_rows, min = 1, max = max_val)
        } else {
          updateNumericInput(session, "n_rows", min = 1, max = max_val)
        }

        if (!identical(current_cols, safe_cols)) {
          updateNumericInput(session, "n_cols", value = safe_cols, min = 1, max = max_val)
        } else {
          updateNumericInput(session, "n_cols", min = 1, max = max_val)
        }
      })

      out
    })

    plot_size <- reactive({
      req(module_active())
      info <- plot_info()
      if (is.null(info$layout)) {
        list(w = plot_width(), h = plot_height())
      } else {
        list(
          w = plot_width()  * info$layout$ncol,
          h = plot_height() * info$layout$nrow
        )
      }
    })

    output$download_plot <- downloadHandler(
      filename = function() paste0("numeric_histograms_", Sys.Date(), ".png"),
      content  = function(file) {
        req(module_active())
        info <- plot_info()
        req(info$plot)
        s <- plot_size()
        ggplot2::ggsave(
          filename = file,
          plot = info$plot,
          device = "png",
          dpi = 300,
          width  = s$w / 96,
          height = s$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )

    output$plot <- renderPlot({
      req(module_active())
      info <- plot_info()
      validate(need(!is.null(info$plot), "No plot available."))
      print(info$plot)
    },
    width = function() {
      req(module_active())
      plot_size()$w
    },
    height = function() {
      req(module_active())
      plot_size()$h
    },
    res = 96)
  })
}


build_descriptive_numeric_histogram <- function(df,
                                                selected_vars = NULL,
                                                group_var = NULL,
                                                strata_levels = NULL,
                                                use_density = FALSE,
                                                nrow_input = NULL,
                                                ncol_input = NULL) {
  if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(NULL)
  
  num_vars <- names(df)[vapply(df, is.numeric, logical(1))]
  if (!is.null(selected_vars) && length(selected_vars) > 0) {
    num_vars <- intersect(num_vars, selected_vars)
  }
  if (length(num_vars) == 0) return(NULL)
  
  if (!is.null(group_var) && group_var %in% names(df)) {
    df[[group_var]] <- as.character(df[[group_var]])
    df[[group_var]][is.na(df[[group_var]]) | trimws(df[[group_var]]) == ""] <- "Missing"
    
    if (!is.null(strata_levels) && length(strata_levels) > 0) {
      keep_levels <- unique(strata_levels)
      df <- df[df[[group_var]] %in% keep_levels, , drop = FALSE]
      if (nrow(df) == 0) return(NULL)
      df[[group_var]] <- factor(df[[group_var]], levels = keep_levels)
    } else {
      df[[group_var]] <- factor(df[[group_var]], levels = unique(df[[group_var]]))
    }
  } else {
    group_var <- NULL
  }
  
  plots <- lapply(num_vars, function(var) {
    cols <- c(var, group_var)
    cols <- cols[cols %in% names(df)]
    plot_data <- df[, cols, drop = FALSE]
    
    keep <- is.finite(plot_data[[var]])
    keep[is.na(keep)] <- FALSE
    plot_data <- plot_data[keep, , drop = FALSE]
    if (nrow(plot_data) == 0) return(NULL)
    
    if (!is.null(group_var)) {
      plot_data[[group_var]] <- droplevels(plot_data[[group_var]])
    }
    
    density_mode <- isTRUE(use_density) && length(unique(plot_data[[var]])) > 1
    
    base <- ggplot(plot_data, aes(x = .data[[var]]))
    y_label <- if (density_mode) "Density" else "Count"
    
    if (!is.null(group_var)) {
      group_levels <- levels(plot_data[[group_var]])
      palette <- resolve_palette_for_levels(group_levels)
      if (density_mode) {
        p <- base +
          geom_density(aes(color = .data[[group_var]], fill = .data[[group_var]]), alpha = 0.3) +
          scale_color_manual(values = palette) +
          scale_fill_manual(values = palette) +
          labs(color = group_var, fill = group_var)
      } else {
        p <- base +
          geom_histogram(
            aes(fill = .data[[group_var]]),
            position = "identity",
            alpha = 0.5,
            bins = 30
          ) +
          scale_fill_manual(values = palette) +
          labs(fill = group_var)
      }
    } else {
      single_color <- resolve_single_color()
      if (density_mode) {
        p <- base + geom_density(fill = single_color, color = single_color, alpha = 0.35)
      } else {
        p <- base + geom_histogram(fill = single_color, color = single_color, bins = 30)
      }
    }
    
    p +
      theme_minimal(base_size = 13) +
      labs(title = var, x = var, y = y_label)
  })
  
  plots <- Filter(Negate(is.null), plots)
  if (length(plots) == 0) return(NULL)
  
  layout <- resolve_grid_layout(
    n_items = length(plots),
    rows_input = suppressWarnings(as.numeric(nrow_input)),
    cols_input = suppressWarnings(as.numeric(ncol_input))
  )
  
  combined <- patchwork::wrap_plots(plots, nrow = layout$nrow, ncol = layout$ncol) +
    patchwork::plot_annotation(
      theme = theme(plot.title = element_text(size = 16, face = "bold"))
    )
  
  list(
    plot = combined,
    layout = list(nrow = layout$nrow, ncol = layout$ncol),
    panels = length(plots)
  )
}
# ===============================================================
# 🧮 Linear Model (LM) — fixed effects only
# ===============================================================

lm_ui <- function(id) regression_ui(id, "lm", allow_multi_response = TRUE)

lm_server <- function(id, data) regression_server(id, data, "lm", allow_multi_response = TRUE)
# ===============================================================
# 🧬 Linear Mixed Model (LMM) — single random intercept
# ===============================================================

lmm_ui <- function(id) regression_ui(id, "lmm", allow_multi_response = TRUE)

lmm_server <- function(id, data) regression_server(id, data, "lmm", allow_multi_response = TRUE)
# ===============================================================
# 🧩 Helpers for LMM
# ===============================================================

compute_icc <- function(model) {
  if (!inherits(model, "merMod")) return(NA_real_)
  
  vc <- as.data.frame(VarCorr(model))
  if (nrow(vc) < 2) return(NA_real_)
  
  # residual variance is always the last row
  var_residual <- vc$vcov[nrow(vc)]
  
  # compute ICC for each random effect
  icc_list <- lapply(seq_len(nrow(vc) - 1), function(i) {
    var_random <- vc$vcov[i]
    icc_value <- var_random / (var_random + var_residual)
    data.frame(
      Group = vc$grp[i],
      ICC   = round(icc_value, 3),
      stringsAsFactors = FALSE
    )
  })
  
  icc_df <- do.call(rbind, icc_list)
  rownames(icc_df) <- NULL
  icc_df
}
# ===============================================================
# 🧪 Table Analyzer — Analysis Coordinator
# ===============================================================

analysis_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 3 — Analyze results"),
      p("Select the statistical approach that fits your trial design, then inspect the summaries on the right."),
      hr(),
      
      # --- CSS: expand dropdown height for better visibility ---
      tags$style(HTML(sprintf("
        #%s + .selectize-control .selectize-dropdown,
        #%s + .selectize-control .selectize-dropdown .selectize-dropdown-content {
          max-height: none !important;
        }
      ", ns("analysis_type"), ns("analysis_type")))),
      
      # --- Analysis type selector ---
      selectInput(
        ns("analysis_type"),
        "Select analysis type:",
        choices = list(
          " " = "",
          "Descriptive" = c("Descriptive Statistics" = "Descriptive Statistics"),
          "Univariate" = c(
            "One-way ANOVA" = "One-way ANOVA",
            "Two-way ANOVA" = "Two-way ANOVA",
            "Linear Model (LM)" = "Linear Model (LM)",
            "Linear Mixed Model (LMM)" = "Linear Mixed Model (LMM)"
          ),
          "Multivariate" = c(
            "Pairwise Correlation" = "Pairwise Correlation",
            "Principal Component Analysis (PCA)" = "PCA"
          )
        ),
        selected = ""
      ),
      
      hr(),
      uiOutput(ns("config_panel"))
    ),
    
    mainPanel(
      width = 8,
      h4("Analysis results"),
      uiOutput(ns("results_panel"))
    )
  )
}


analysis_server <- function(id, filtered_data) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    df <- reactive(filtered_data())
    
    # ---- Mapping of available modules ----
    modules <- list(
      "Descriptive Statistics" = list(id = "desc",  ui = descriptive_ui, server = descriptive_server, type = "desc"),
      "One-way ANOVA"          = list(id = "anova1", ui = one_way_anova_ui, server = one_way_anova_server, type = "anova1"),
      "Two-way ANOVA"          = list(id = "anova2", ui = two_way_anova_ui, server = two_way_anova_server, type = "anova2"),
      "Linear Model (LM)"      = list(id = "lm",     ui = lm_ui, server = lm_server, type = "lm"),
      "Linear Mixed Model (LMM)" = list(id = "lmm",  ui = lmm_ui, server = lmm_server, type = "lmm"),
      "Pairwise Correlation"   = list(id = "pairs",  ui = ggpairs_ui, server = ggpairs_server, type = "pairs"),
      "PCA"                    = list(id = "pca",    ui = pca_ui, server = pca_server, type = "pca")
    )
    
    # ---- Cache for lazily created servers ----
    server_cache <- reactiveValues()
    
    # ---- Current module getter ----
    current_mod <- reactive({
      type <- input$analysis_type
      if (is.null(type) || !nzchar(type)) return(NULL)
      modules[[type]]
    })
    
    current_ui <- reactive({
      mod <- current_mod()
      if (is.null(mod)) return(NULL)
      mod$ui(ns(mod$id))
    })
    
    # ---- Lazy server initialization ----
    normalize_analysis_type <- function(mod_type) {
      lookup <- list(
        desc = "DESCRIPTIVE",
        anova1 = "ANOVA",
        anova2 = "ANOVA",
        lm = "LM",
        lmm = "LMM",
        pairs = "CORR",
        pca = "PCA"
      )
      if (is.null(mod_type)) return(NULL)
      if (mod_type %in% names(lookup)) lookup[[mod_type]] else toupper(mod_type)
    }

    ensure_module_server <- function(mod) {
      key <- mod$id
      if (!is.null(server_cache[[key]])) return(server_cache[[key]])

      result <- tryCatch(mod$server(mod$id, df), error = function(e) {
        warning(sprintf("Module '%s' failed to initialize: %s", key, conditionMessage(e)))
        NULL
      })

      default_analysis_type <- normalize_analysis_type(mod$type)

      if (is.null(result)) {
        server_cache[[key]] <- reactive(NULL)
      } else if (is.reactive(result)) {
        server_cache[[key]] <- reactive({
          val <- result()
          if (is.null(val)) return(NULL)
          if (!is.list(val)) {
            return(list(
              analysis_type = default_analysis_type,
              data_used = NULL,
              model = val,
              summary = NULL,
              posthoc = NULL,
              effects = NULL,
              stats = NULL,
              metadata = list(),
              type = mod$type
            ))
          }
          if (is.null(val$type)) val$type <- mod$type
          if (is.null(val$analysis_type)) val$analysis_type <- default_analysis_type
          val
        })
      } else {
        server_cache[[key]] <- reactive(list(
          analysis_type = default_analysis_type,
          data_used = NULL,
          model = result,
          summary = NULL,
          posthoc = NULL,
          effects = NULL,
          stats = NULL,
          metadata = list(),
          type = mod$type
        ))
      }

      server_cache[[key]]
    }
    
    # ---- Render active submodule UI ----
    output$config_panel <- renderUI({
      ui <- current_ui()
      if (is.null(ui)) return(NULL)
      ui$config
    })
    
    output$results_panel <- renderUI({
      ui <- current_ui()
      if (is.null(ui)) return(NULL)
      ui$results
    })
    
    # ---- Connect the current selected module's server ----
    current_server <- reactive({
      mod <- current_mod()
      if (is.null(mod)) return(NULL)
      ensure_module_server(mod)
    })
    
    # ---- Unified model output ----
    model_out <- reactive({
      srv <- current_server()
      if (is.null(srv)) return(NULL)
      srv()
    })
    
    # Return the active model output as a reactive
    model_out
  })
}
# ===============================================================
# 🎨 Module for colors customization
# ===============================================================

add_color_customization_ui <- function(ns, multi_group = TRUE) {
  tags$details(
    tags$summary(strong("Advanced options")),
    br(),
    uiOutput(ns("color_custom_ui"))
  )
}

# ---- SERVER ----
add_color_customization_server <- function(ns, input, output, data, color_var_reactive, multi_group = TRUE) {
  output$color_custom_ui <- renderUI({
    req(data())
    color_var <- color_var_reactive()

    single_color_ui <- tagList(
      br(),
      h5("Line color"),
      color_dropdown_input(ns, "single_color", basic_color_palette, ncol = 4)
    )

    if (isTRUE(multi_group)) {
      if (is.null(color_var) || identical(color_var, "") || identical(color_var, "None")) {
        single_color_ui
      } else {
        render_color_inputs(ns, data, color_var)
      }
    } else {
      single_color_ui
    }
  })

  reactive({
    if (isTRUE(multi_group)) {
      color_var <- color_var_reactive()
      if (is.null(color_var) || identical(color_var, "") || identical(color_var, "None")) {
        selected_color <- input$single_color
        if (is.null(selected_color) || identical(selected_color, "")) selected_color <- "steelblue"
        return(selected_color)
      }

      dataset <- data()
      if (is.null(dataset) || !color_var %in% names(dataset)) {
        selected_color <- input$single_color
        if (is.null(selected_color) || identical(selected_color, "")) selected_color <- "steelblue"
        return(selected_color)
      }

      lvls <- levels(as.factor(dataset[[color_var]]))
      base_palette <- rep(basic_color_palette, length.out = length(lvls))
      cols <- vapply(seq_along(lvls), function(i) {
        input_val <- input[[paste0("col_", color_var, "_", i)]]
        if (is.null(input_val) || identical(input_val, "")) {
          base_palette[i]
        } else {
          input_val
        }
      }, character(1))
      names(cols) <- lvls
      cols
    } else {
      selected_color <- input$single_color
      if (is.null(selected_color)) selected_color <- "steelblue"
      selected_color
    }
  })
}

# ===============================================================
# 🎨 UI helper to assign colors per level of a factor
# ===============================================================

render_color_inputs <- function(ns, data, color_var) {
  if (is.null(color_var) || color_var == "None") return(NULL)
  if (!color_var %in% names(data())) return(NULL)

  values <- data()[[color_var]]
  lvls <- if (is.factor(values)) levels(values) else unique(as.character(values))
  lvls <- lvls[!is.na(lvls)]
  default_palette <- rep(basic_color_palette, length.out = length(lvls))

  tagList(
    br(),
    h5(paste("Line colors for", color_var)),
    lapply(seq_along(lvls), function(i) {
      selected <- default_palette[i]
      tags$div(
        style = "margin-bottom: 8px;",
        tags$label(lvls[i], style = "display:block; margin-bottom: 4px;"),
        color_dropdown_input(
          ns,
          id = paste0("col_", color_var, "_", i),
          palette = basic_color_palette,
          ncol = 4,
          selected = selected
        )
      )
    })
  )
}

resolve_single_color <- function() {
  basic_color_palette[1]
}

resolve_palette_for_levels <- function(levels, custom = NULL) {
  if (is.null(levels) || length(levels) == 0) {
    return(resolve_single_color())
  }

  unique_levels <- unique(as.character(levels))
  palette_size <- length(basic_color_palette)
  n_levels <- length(unique_levels)

  if (n_levels > palette_size) {
    stop(
      sprintf(
        "Palette can assign at most %d groups but received %d levels.",
        palette_size,
        n_levels
      ),
      call. = FALSE
    )
  }

  if (!is.null(custom) && length(custom) > 0) {
    if (!is.null(names(custom))) {
      ordered <- custom[unique_levels]
      if (all(!is.na(ordered))) {
        return(ordered)
      }
    } else if (length(custom) >= n_levels) {
      return(stats::setNames(custom[seq_len(n_levels)], unique_levels))
    }
  }

  stats::setNames(basic_color_palette[seq_len(n_levels)], unique_levels)
}
# ===============================================================
# 🧪 Table Analyzer — Filter Module
# ===============================================================

filter_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 2 — Filter records"),
      p("Select the columns to focus on and adjust the filters to refine the dataset for analysis."),
      hr(),
      uiOutput(ns("column_selector")),
      hr(),
      uiOutput(ns("filter_widgets"))
    ),
    mainPanel(
      width = 8,
      h4("Filtered data preview"),
      DTOutput(ns("filtered_preview"))
    )
  )
}

filter_server <- function(id, uploaded_data) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    
    df <- reactive(uploaded_data())
    
    # --- 1. Column selector ---
    output$column_selector <- renderUI({
      req(df())
      selectInput(
        ns("columns"),
        "Select columns to filter:",
        choices = names(df()),
        multiple = TRUE
      )
    })
    
    # --- 2. Dynamic filter widgets ---
    output$filter_widgets <- renderUI({
      req(df())
      cols <- input$columns
      if (is.null(cols) || length(cols) == 0) return(NULL)
      
      make_numeric_widget <- function(col, x) {
        rng <- suppressWarnings(range(x, na.rm = TRUE))
        if (any(!is.finite(rng))) rng <- c(0, 0)
        step_val <- ifelse(diff(rng) == 0, 1, diff(rng) / 100)
        fluidRow(
          column(
            6,
            numericInput(
              ns(paste0("min_", col)),
              label = paste(col, "(min)"),
              value = rng[1],
              min = rng[1],
              max = rng[2],
              step = step_val
            )
          ),
          column(
            6,
            numericInput(
              ns(paste0("max_", col)),
              label = paste(col, "(max)"),
              value = rng[2],
              min = rng[1],
              max = rng[2],
              step = step_val
            )
          )
        )
      }
      
      make_logical_widget <- function(col) {
        checkboxGroupInput(
          ns(paste0("filter_", col)),
          label = col,
          choices = c(TRUE, FALSE),
          selected = c(TRUE, FALSE),
          inline = TRUE
        )
      }
      
      make_factor_widget <- function(col, x) {
        choices <- sort(unique(as.character(x)))
        selectInput(
          ns(paste0("filter_", col)),
          label = col,
          choices = choices,
          multiple = TRUE,
          selected = choices
        )
      }
      
      widgets <- lapply(cols, function(col) {
        col_data <- df()[[col]]
        if (is.numeric(col_data)) make_numeric_widget(col, col_data)
        else if (is.logical(col_data)) make_logical_widget(col)
        else make_factor_widget(col, col_data)
      })
      
      tagList(widgets)
    })
    
    # --- 3. Reactive filtering ---
    filtered_df <- reactive({
      req(df())
      data <- df()
      cols <- input$columns
      if (is.null(cols) || length(cols) == 0) return(data)
      
      for (col in cols) {
        col_data <- data[[col]]
        
        if (is.numeric(col_data)) {
          min_val <- input[[paste0("min_", col)]]
          max_val <- input[[paste0("max_", col)]]
          if (is.null(min_val) || is.null(max_val)) {
            data <- data[0, , drop = FALSE]
            break
          }
          data <- data[data[[col]] >= min_val & data[[col]] <= max_val, , drop = FALSE]
        } else {
          sel <- input[[paste0("filter_", col)]]
          if (is.null(sel) || length(sel) == 0) {
            data <- data[0, , drop = FALSE]
            break
          }
          data <- data[data[[col]] %in% sel, , drop = FALSE]
        }
      }
      
      data
    })
    
    # --- 4. Preview table ---
    output$filtered_preview <- renderDT({
      datatable(
        filtered_df(),
        options = list(scrollX = TRUE, pageLength = 5)
      )
    })
    
    # --- 5. Return filtered data for downstream modules ---
    return(filtered_df)
  })
}
# ===============================================================
# 🧪 Table Analyzer — Upload Module (simple editable column types)
# ===============================================================

upload_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 1 — Upload data"),
      p("Choose whether to load the example dataset or upload your own Excel file."),
      hr(),
      radioButtons(
        ns("data_source"),
        label = "Data source:",
        choices = c(
          "Example dataset" = "example",
          "Upload (long format)" = "long",
          "Upload (wide format)" = "wide"
        ),
        selected = "example"
      ),
      uiOutput(ns("layout_example")),
      hr(),
      fileInput(
        ns("file"),
        "Upload Excel file (.xlsx / .xls / .xlsm)",
        accept = c(".xlsx", ".xls", ".xlsm)")
      ),
      uiOutput(ns("sheet_selector")),
      hr(),
      uiOutput(ns("type_selectors"))
    ),
    mainPanel(
      width = 8,
      h4("Data preview"),
      verbatimTextOutput(ns("validation_msg")),
      DTOutput(ns("preview"))
    )
  )
}


upload_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    df <- reactiveVal(NULL)
    editable_cols <- reactiveVal(NULL)
    
    # ---- Reset ----
    observeEvent(input$data_source, {
      df(NULL)
      output$preview <- renderDT(data.frame())
      output$validation_msg <- renderText("")
      output$sheet_selector <- renderUI(NULL)
      output$type_selectors <- renderUI(NULL)
      
      if (input$data_source == "example") {
        path <- "data/toy_animal_trial_data_long.xlsx"
        validate(need(file.exists(path), "⚠️ Example dataset not found in data folder."))
        data <- readxl::read_excel(path)
        data <- preprocess_uploaded_table(data)
        df(data)
        output$validation_msg <- renderText("📂 Loaded built-in example dataset (long format).")
        output$preview <- renderDT(data, options = list(scrollX = TRUE, pageLength = 5))
        create_type_selectors(data)
      }
    }, ignoreInit = FALSE)
    
    
    # ---- Example layout ----
    output$layout_example <- renderUI({
      req(input$data_source %in% c("long", "wide"))
      long_path <- "data/toy_animal_trial_data_long.xlsx"
      wide_path <- "data/toy_animal_trial_data_wide.xlsx"
      validate(need(file.exists(long_path) && file.exists(wide_path),
                    "❌ Example layout files not found in /data folder."))
      
      if (input$data_source == "long") {
        toy <- readxl::read_excel(long_path, n_max = 5)
        caption <- "Long format — one row per measurement."
      } else {
        toy <- readxl::read_excel(wide_path, n_max = 5)
        bad <- grepl("^\\.\\.\\.[0-9]+$", names(toy))
        names(toy)[bad] <- ""
        caption <- "Wide format — two header rows (top: response, bottom: replicate)."
      }
      
      DT::datatable(
        toy,
        caption = htmltools::tags$caption(htmltools::tags$b(caption)),
        options = list(dom = "t", scrollX = TRUE),
        rownames = FALSE,
        class = "compact stripe"
      )
    })
    
    
    # ---- File upload ----
    observeEvent(input$file, {
      req(input$data_source != "example", input$file)
      ext <- tolower(tools::file_ext(input$file$name))
      validate(need(ext %in% c("xlsx", "xls", "xlsm"),
                    "❌ Invalid file type. Please upload .xlsx/.xls/.xlsm."))
      
      sheets <- tryCatch(readxl::excel_sheets(input$file$datapath),
                         error = function(e) NULL)
      validate(need(!is.null(sheets), "❌ No readable sheets found in the workbook."))
      output$validation_msg <- renderText(paste("✅ File loaded:", input$file$name))
      output$sheet_selector <- renderUI(selectInput(ns("sheet"), "Select sheet:", choices = sheets))
    }, ignoreInit = TRUE)
    
    
    # ---- Load selected sheet ----
    observeEvent(list(input$sheet, input$file$datapath, input$data_source), {
      req(input$data_source != "example", input$file, input$sheet)
      data <- NULL
      
      if (input$data_source == "wide") {
        data <- tryCatch(
          convert_wide_to_long(input$file$datapath, sheet = input$sheet, replicate_col = "Replicate"),
          error = function(e) {
            output$validation_msg <- renderText(paste("❌ Error converting wide format:", conditionMessage(e)))
            NULL
          }
        )
        req(!is.null(data))
        output$validation_msg <- renderText("✅ Wide format reshaped successfully.")
      } else {
        data <- tryCatch(
          readxl::read_excel(input$file$datapath, sheet = input$sheet),
          error = function(e) {
            output$validation_msg <- renderText(paste("❌ Error loading sheet:", conditionMessage(e)))
            NULL
          }
        )
        req(!is.null(data))
        output$validation_msg <- renderText("✅ Long format loaded successfully.")
      }
      
      data <- preprocess_uploaded_table(data)
      df(data)
      output$preview <- renderDT(data, options = list(scrollX = TRUE, pageLength = 5))
      create_type_selectors(data)
    })
    
    
    # ---- Create type selectors ----
    create_type_selectors <- function(data) {
      num_vars <- names(data)[sapply(data, is.numeric)]
      few_level_nums <- num_vars[sapply(data[num_vars], function(x) length(unique(na.omit(x))) <= 10)]
      editable_cols(few_level_nums)
      
      if (length(few_level_nums) == 0) {
        output$type_selectors <- renderUI(NULL)
        return()
      }
      
      output$type_selectors <- renderUI({
        tagList(
          h5("Ambiguous type columns"),
          lapply(few_level_nums, function(col) {
            selectInput(
              ns(paste0("type_", col)),
              label = col,
              choices = c("Numeric", "Categorical"),
              selected = "Numeric",
              width = "100%"
            )
          })
        )
      })
    }
    
    
    # ---- Update df when user changes type ----
    observe({
      req(df(), editable_cols())
      data <- df()
      for (col in editable_cols()) {
        input_id <- paste0("type_", col)
        sel <- input[[input_id]]
        if (!is.null(sel) && sel == "Categorical") {
          data[[col]] <- factor(as.character(data[[col]]))
        } else if (!is.null(sel) && sel == "Numeric") {
          data[[col]] <- suppressWarnings(as.numeric(as.character(data[[col]])))
        }
      }
      df(data)
    })
    
    
    return(df)
  })
}
# Clean names + convert characters to ordered factors
preprocess_uploaded_table <- function(df) {
  df <- janitor::clean_names(df)
  df <- df |> mutate(across(where(is.character), auto_factor_order))
  df
}

# Convert character to factor with numeric-aware order
auto_factor_order <- function(x) {
  if (!is.character(x)) return(x)
  nums <- suppressWarnings(as.numeric(gsub("\\D", "", x)))
  if (all(is.na(nums))) {
    factor(x, levels = sort(unique(x)))
  } else {
    x <- factor(x, levels = unique(x[order(nums, na.last = TRUE)]))
    x
  }
}


convert_wide_to_long <- function(path, sheet = 1, replicate_col = "Replicate") {
  
  # ---- Read first two rows together to preserve blanks ----
  headers <- read_excel(path, sheet = sheet, n_max = 2, col_names = FALSE)
  
  header1 <- as.character(unlist(headers[1, , drop = TRUE]))
  header2 <- as.character(unlist(headers[2, , drop = TRUE]))
  
  # ---- Fill blanks forward in header1 ----
  header1[header1 == ""] <- NA
  header1 <- zoo::na.locf(header1, na.rm = FALSE)
  header2[is.na(header2) | header2 == ""] <- ""
  
  # ---- Combine safely ----
  clean_names <- ifelse(header2 == "", header1, paste0(header1, "_", header2))
  clean_names <- make.unique(clean_names, sep = "_")
  
  # ---- Read data using combined names ----
  data <- read_excel(path, sheet = sheet, skip = 2, col_names = clean_names)
  
  # ---- Identify ID vs measurement columns ----
  fixed_cols <- clean_names[1:3]
  measure_cols <- setdiff(clean_names, fixed_cols)
  
  # ---- Reshape ----
  data_long <- data |>
    pivot_longer(
      cols = all_of(measure_cols),
      names_to = c("Variable", replicate_col),
      names_pattern = "^(.*)_([^_]*)$",
      values_to = "Value"
    ) |>
    pivot_wider(names_from = "Variable", values_from = "Value")
  
  as_tibble(data_long)
}
# ===============================================================
# 🧩 Visualization Coordinator
# ===============================================================

visualize_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("dynamic_ui"))
  )
}

visualize_server <- function(id, filtered_data, model_fit) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    
    # reactive model info
    model_info <- reactive(model_fit())
    
    # detect analysis type
    analysis_type <- reactive({
      info <- model_info()
      if (is.null(info$type)) return("oneway_anova")  # default
      info$type
    })
    
    # dynamic UI placeholder
    output$dynamic_ui <- renderUI({
      type <- analysis_type()
      if (type == "oneway_anova") {
        visualize_oneway_ui(ns("oneway"))
      } else if (type == "twoway_anova") {
        visualize_twoway_ui(ns("twoway"))
      } else if (type == "pairwise_correlation") {
        visualize_ggpairs_ui(ns("ggpairs"))
      } else if (type == "pca") {
        visualize_pca_ui(ns("pca"), filtered_data())
      } else if (type == "descriptive") {
        visualize_descriptive_ui(ns("descriptive"))
      } else {
        div("Visualization not yet implemented for this analysis type.")
      }
    })
    
    observe({
      type <- analysis_type()
      if (type == "oneway_anova") {
        visualize_oneway_server("oneway", filtered_data, model_info)
      } else if (type == "twoway_anova") {
        visualize_twoway_server("twoway", filtered_data, model_info)
      } else if (type == "pairwise_correlation") {
        visualize_ggpairs_server("ggpairs", filtered_data, model_info)
      } else if (type == "pca") {
        visualize_pca_server("pca", filtered_data, model_info)
      } else if (type == "descriptive") {
        visualize_descriptive_server("descriptive", filtered_data, model_info)
      }
    })
    
  })
}
# ===============================================================
# 🧱 Visualization Layout Management
# ===============================================================

initialize_layout_state <- function(input, session) {
  layout_overrides <- reactiveValues(
    strata_rows = 0,
    strata_cols = 0,
    resp_rows = 0,
    resp_cols = 0
  )

  layout_manual <- reactiveValues(
    strata_rows = FALSE,
    strata_cols = FALSE,
    resp_rows = FALSE,
    resp_cols = FALSE
  )

  suppress_updates <- reactiveValues(
    strata_rows = TRUE,
    strata_cols = TRUE,
    resp_rows = TRUE,
    resp_cols = TRUE
  )

  observe_numeric_input <- function(name) {
    observeEvent(input[[name]], {
      if (isTRUE(suppress_updates[[name]])) {
        suppress_updates[[name]] <- FALSE
        return()
      }

      val <- suppressWarnings(as.numeric(input[[name]]))
      if (is.na(val) || val < 1) {
        layout_overrides[[name]] <- 0L
        layout_manual[[name]] <- FALSE
      } else {
        clamped <- as.integer(max(1, min(10, val)))
        layout_overrides[[name]] <- clamped
        layout_manual[[name]] <- TRUE
      }
    })
  }
  lapply(c("strata_rows", "strata_cols", "resp_rows", "resp_cols"), observe_numeric_input)

  effective_input <- function(name) {
    if (isTRUE(layout_manual[[name]])) layout_overrides[[name]] else 0
  }

  default_ui_value <- function(cur_val) {
    val <- if (is.null(cur_val)) 1 else cur_val
    ifelse(is.na(val) || val <= 0, 1, min(10, val))
  }

  list(
    overrides = layout_overrides,
    manual = layout_manual,
    suppress = suppress_updates,
    effective_input = effective_input,
    default_ui_value = default_ui_value
  )
}

observe_layout_synchronization <- function(plot_info_reactive, layout_state, session) {
  observeEvent(plot_info_reactive(), {
    plot_info_reactive()
    layout_state
    session
    invisible(NULL)
  })
  invisible(NULL)
}

resolve_grid_layout <- function(n_items, rows_input = NULL, cols_input = NULL) {
  n_items <- suppressWarnings(as.integer(n_items[1]))
  if (is.na(n_items) || n_items <= 0) {
    n_items <- 1L
  }
  
  rows_raw <- resolve_grid_value(rows_input)
  cols_raw <- resolve_grid_value(cols_input)
  
  rows <- rows_raw
  cols <- cols_raw
  
  if (is.na(rows) && is.na(cols)) {
    rows <- ceiling(sqrt(n_items))
    cols <- ceiling(n_items / rows)
  } else if (is.na(rows)) {
    cols <- cols_raw
    if (is.na(cols) || cols <= 0) {
      rows <- ceiling(sqrt(n_items))
      cols <- ceiling(n_items / rows)
    } else {
      rows <- ceiling(n_items / cols)
    }
  } else if (is.na(cols)) {
    rows <- rows_raw
    if (is.na(rows) || rows <= 0) {
      rows <- ceiling(sqrt(n_items))
      cols <- ceiling(n_items / rows)
    } else {
      cols <- ceiling(n_items / rows)
    }
  }
  
  if ((is.na(rows_raw) || is.na(cols_raw)) && !is.na(rows) && !is.na(cols)) {
    while (rows * cols < n_items) {
      if (cols <= rows) {
        cols <- cols + 1L
      } else {
        rows <- rows + 1L
      }
    }
  }
  
  list(nrow = rows, ncol = cols)
}

resolve_grid_value <- function(value) {
  if (is.null(value) || length(value) == 0) return(NA_integer_)
  val <- suppressWarnings(as.integer(value[1]))
  if (is.na(val) || val < 1) return(NA_integer_)
  val
}


# ===============================================================
# 🧪 Table  Analyzer — Pairwise Correlation Module
# ===============================================================

ggpairs_ui <- function(id) {
  ns <- NS(id)
  list(
    config = tagList(
      selectInput(ns("vars"), "Numeric variables:", choices = NULL, multiple = TRUE),
      br(),
      tags$details(
        tags$summary(strong("Advanced options")),
        br(),
        stratification_ui("strat", ns)
      ),
      br(),
      fluidRow(
        column(6, actionButton(ns("run"), "Show correlation matrix", width = "100%")),
        column(6, downloadButton(ns("download_model"), "Download all results", style = "width: 100%;"))
      )
    ),
    results = tagList(
      h5("Correlation matrix"),
      verbatimTextOutput(ns("summary"))
    )
  )
}

ggpairs_server <- function(id, data_reactive) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    df <- reactive(data_reactive())

    strat_info <- stratification_server("strat", df)

    # ---- Update variable selector ----
    observe({
      req(df())
      num_vars <- names(df())[sapply(df(), is.numeric)]
      updateSelectInput(session, "vars", choices = num_vars, selected = num_vars)
    })

    build_ggpairs_object <- function(data) {
      GGally::ggpairs(
        data,
        progress = FALSE,
        upper = list(
          continuous = GGally::wrap("cor", size = 4, color = basic_color_palette[1])
        ),
        lower = list(
          continuous = GGally::wrap("points", alpha = 0.6, color = basic_color_palette[1], size = 1.5)
        ),
        diag = list(
          continuous = GGally::wrap("densityDiag", fill = basic_color_palette[1], alpha = 0.4)
        )
      ) +
        ggplot2::theme_minimal(base_size = 11) +
        ggplot2::theme(
          strip.text = ggplot2::element_text(face = "bold", size = 9),
          panel.grid.minor = ggplot2::element_blank(),
          panel.grid.major.x = ggplot2::element_blank(),
          panel.grid.major.y = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(size = 12, face = "bold")
        )
    }

    correlation_store <- reactiveVal(NULL)

    # ---- Compute correlation matrix ----
    observeEvent(input$run, {
      req(df())
      data <- df()
      numeric_vars <- names(data)[sapply(data, is.numeric)]
      selected_vars <- if (length(input$vars)) input$vars else numeric_vars
      selected_vars <- intersect(selected_vars, numeric_vars)

      if (length(selected_vars) < 2) {
        correlation_store(list(
          message = "Need at least two numeric columns.",
          matrices = list(),
          plots = list(),
          group_var = NULL,
          selected_vars = selected_vars,
          data_used = NULL,
          strata_levels = NULL
        ))
        return()
      }

      strat_details <- strat_info()
      group_var <- strat_details$var

      strata_levels <- "Overall"
      if (!is.null(group_var) && group_var %in% names(data)) {
        levels <- strat_details$levels
        if (is.null(levels) || length(levels) == 0) {
          values <- data[[group_var]]
          values <- values[!is.na(values)]
          strata_levels <- unique(as.character(values))
        } else {
          strata_levels <- levels
        }
      } else {
        group_var <- NULL
      }

      matrices <- list()
      plots <- list()
      processed_data <- data[, unique(c(selected_vars, group_var)), drop = FALSE]

      if (!is.null(group_var)) {
        keep_rows <- !is.na(processed_data[[group_var]]) &
          as.character(processed_data[[group_var]]) %in% strata_levels
        processed_data <- processed_data[keep_rows, , drop = FALSE]
        processed_data[[group_var]] <- factor(
          as.character(processed_data[[group_var]]),
          levels = strata_levels
        )
      }

      if (is.null(group_var)) {
        dat <- data[, selected_vars, drop = FALSE]
        cor_matrix <- cor(dat, use = "pairwise.complete.obs")
        matrices[["Overall"]] <- cor_matrix
        plots[["Overall"]] <- build_ggpairs_object(dat)
      } else {
        for (level in strata_levels) {
          subset_rows <- !is.na(data[[group_var]]) & as.character(data[[group_var]]) == level
          subset_data <- data[subset_rows, , drop = FALSE]
          if (nrow(subset_data) == 0) {
            matrices[[level]] <- NULL
            plots[[level]] <- NULL
            next
          }
          dat <- subset_data[, selected_vars, drop = FALSE]
          cor_matrix <- suppressWarnings(cor(dat, use = "pairwise.complete.obs"))
          matrices[[level]] <- cor_matrix
          plots[[level]] <- build_ggpairs_object(dat)
        }
      }

      correlation_store(list(
        matrices = matrices,
        plots = plots,
        group_var = group_var,
        selected_vars = selected_vars,
        data_used = processed_data,
        strata_levels = if (!is.null(group_var)) strata_levels else NULL
      ))
    })

    output$summary <- renderPrint({
      results <- correlation_store()
      if (is.null(results)) {
        return(invisible(NULL))
      }

      if (!is.null(results$message)) {
        cat(results$message)
        return(invisible(NULL))
      }

      matrices <- results$matrices
      if (is.null(matrices) || length(matrices) == 0) {
        return(invisible(NULL))
      }

      multiple <- length(matrices) > 1
      for (name in names(matrices)) {
        mat <- matrices[[name]]
        if (multiple) {
          cat(sprintf("=== Stratum: %s ===\n", name))
        }
        if (is.null(mat)) {
          cat("  No data available for this stratum.\n\n")
        } else {
          print(round(mat, 2))
          cat("\n")
        }
      }
    })
    
    # ---- Download results ----
    output$download_model <- downloadHandler(
      filename = function() paste0("Correlation_results_", Sys.Date(), ".txt"),
      content = function(file) {
        res <- correlation_store()
        if (is.null(res)) return()
        sink(file)
        on.exit(sink(), add = TRUE)
        
        if (!is.null(res$message)) {
          cat(res$message, "\n")
          return()
        }
        
        matrices <- res$matrices
        if (is.null(matrices) || length(matrices) == 0) {
          cat("No correlation matrices available.\n")
          return()
        }
        
        multiple <- length(matrices) > 1
        for (nm in names(matrices)) {
          mat <- matrices[[nm]]
          if (multiple) cat(sprintf("=== Stratum: %s ===\n", nm))
          if (is.null(mat)) {
            cat("No data available for this stratum.\n\n")
          } else {
            print(round(mat, 3))
            cat("\n")
          }
        }

      }
    )

    # ---- Return structured output for visualization ----
    df_final <- reactive({
      res <- correlation_store()
      if (is.null(res)) return(NULL)
      res$data_used
    })

    model_fit <- reactive({
      res <- correlation_store()
      if (is.null(res)) return(NULL)
      res$matrices
    })

    summary_table <- reactive({
      res <- correlation_store()
      if (is.null(res)) return(NULL)
      res$matrices
    })

    posthoc_results <- reactive(NULL)

    effect_table <- reactive(NULL)

    reactive({
      res <- correlation_store()
      if (is.null(res)) return(NULL)

      data_used <- df_final()

      list(
        analysis_type = "CORR",
        data_used = data_used,
        model = model_fit(),
        summary = summary_table(),
        posthoc = posthoc_results(),
        effects = effect_table(),
        stats = if (!is.null(data_used)) list(n = nrow(data_used), vars = names(data_used)) else NULL,
        metadata = list(
          selected_vars = res$selected_vars,
          group_var = res$group_var,
          strata_levels = res$strata_levels,
          plots = res$plots,
          message = res$message
        ),
        type = "pairwise_correlation",
        data = df,
        group_var = reactive({
          det <- correlation_store()
          if (is.null(det)) return(NULL)
          det$group_var
        }),
        strata_order = reactive({
          det <- correlation_store()
          if (is.null(det)) return(NULL)
          det$strata_levels
        }),
        results = reactive(correlation_store())
      )
    })
  })
}
# ===============================================================
# 🧪 Visualization Module — Pairwise Correlation (Dispatcher)
# ===============================================================

visualize_ggpairs_ui <- function(id) {
  ns <- NS(id)
  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 4 — Visualize pairwise correlation"),
      p("Visualize pairwise relationships and correlation coefficients among numeric variables."),
      hr(),
      selectInput(
        ns("plot_type"),
        label = "Select visualization type:",
        choices = c("Pairwise scatterplot matrix" = "GGPairs"),
        selected = "GGPairs"
      ),
      hr(),
      uiOutput(ns("sub_controls"))
    ),
    mainPanel(
      width = 8,
      h4("Plots"),
      plotOutput(ns("plot"), height = "auto")
    )
  )
}


visualize_ggpairs_server <- function(id, filtered_data, model_fit) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    correlation_info <- reactive({
      info <- model_fit()
      if (is.null(info) || is.null(info$type) || info$type != "pairwise_correlation") {
        return(NULL)
      }
      info
    })

    active <- reactiveVal(NULL)

    output$sub_controls <- renderUI({
      info <- correlation_info()
      if (is.null(info)) {
        helpText("Run the pairwise correlation analysis to configure plots.")
      } else if (identical(input$plot_type, "GGPairs")) {
        pairwise_correlation_visualize_ggpairs_ui(ns("ggpairs"))
      } else {
        NULL
      }
    })

    observeEvent(list(input$plot_type, correlation_info()), {
      info <- correlation_info()
      type <- input$plot_type

      if (is.null(info) || is.null(type)) {
        active(NULL)
        return()
      }

      handle <- switch(type,
                       "GGPairs" = pairwise_correlation_visualize_ggpairs_server("ggpairs", filtered_data, correlation_info),
                       NULL)
      active(handle)
    }, ignoreNULL = FALSE)

    output$plot <- renderPlot({
      h <- active()
      req(h)
      plot_obj <- h$plot()
      validate(need(!is.null(plot_obj), "No plot available."))
      print(plot_obj)
    },
    width = function() {
      h <- active()
      if (is.null(h)) 800 else h$width()
    },
    height = function() {
      h <- active()
      if (is.null(h)) 600 else h$height()
    },
    res = 96)
  })
}
# ===============================================================
# 🧪 Pairwise Correlation — GGPairs Visualization Module
# ===============================================================

pairwise_correlation_visualize_ggpairs_ui <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(6, numericInput(ns("plot_width"),  "Subplot width (px)",  800, 200, 2000, 50)),
      column(6, numericInput(ns("plot_height"), "Subplot height (px)", 600, 200, 2000, 50))
    ),
    fluidRow(
      column(6, numericInput(ns("grid_rows"),    "Grid rows",    1, 1, 10, 1)),
      column(6, numericInput(ns("grid_cols"),    "Grid columns", 1, 1, 10, 1))
    ),
    hr(),
    downloadButton(ns("download_plot"), "Download Plot", style = "width: 100%;")
  )
}


pairwise_correlation_visualize_ggpairs_server <- function(id, filtered_data, correlation_info) {
  moduleServer(id, function(input, output, session) {

    resolve_input_value <- function(x) {
      if (is.null(x)) return(NULL)
      if (is.reactive(x)) x() else x
    }

    sanitize_numeric <- function(value, default, min_val, max_val) {
      v <- suppressWarnings(as.numeric(value))
      if (length(v) == 0 || is.na(v)) return(default)
      v <- max(min_val, min(max_val, v))
      v
    }

    plot_width <- reactive({
      sanitize_numeric(input$plot_width, 800, 200, 2000)
    })

    plot_height <- reactive({
      sanitize_numeric(input$plot_height, 600, 200, 2000)
    })

    grid_rows <- reactive({
      as.integer(sanitize_numeric(input$grid_rows, 1, 1, 10))
    })

    grid_cols <- reactive({
      as.integer(sanitize_numeric(input$grid_cols, 1, 1, 10))
    })

    build_ggpairs_plot <- function(data, color_value, title = NULL) {
      validate(need(is.data.frame(data) && nrow(data) > 0, "No data available for plotting."))

      numeric_cols <- data[, vapply(data, is.numeric, logical(1)), drop = FALSE]
      numeric_cols <- numeric_cols[, colSums(!is.na(numeric_cols)) > 0, drop = FALSE]

      validate(need(ncol(numeric_cols) >= 2, "Need at least two numeric columns for GGPairs plot."))

      plot_obj <- GGally::ggpairs(
        numeric_cols,
        progress = FALSE,
        upper = list(
          continuous = GGally::wrap("cor", size = 4, colour = color_value)
        ),
        lower = list(
          continuous = GGally::wrap("points", alpha = 0.6, colour = color_value, size = 1.5)
        ),
        diag = list(
          continuous = GGally::wrap("densityDiag", fill = color_value, alpha = 0.4)
        )
      ) +
        ggplot2::theme_minimal(base_size = 11) +
        ggplot2::theme(
          strip.text = ggplot2::element_text(face = "bold", size = 9),
          panel.grid.minor = ggplot2::element_blank(),
          panel.grid.major = ggplot2::element_blank()
        )

      if (!is.null(title)) {
        plot_obj <- plot_obj + ggplot2::labs(title = title)
      }

      plot_obj
    }

    convert_ggmatrix_to_plot <- function(plot_obj) {
      if (!inherits(plot_obj, "ggmatrix")) {
        return(plot_obj)
      }

      gtable <- GGally::ggmatrix_gtable(plot_obj)

      ggplot2::ggplot() +
        ggplot2::theme_void() +
        ggplot2::annotation_custom(
          grob = gtable,
          xmin = -Inf, xmax = Inf,
          ymin = -Inf, ymax = Inf
        )
    }

    plot_info <- reactive({
      info <- correlation_info()
      validate(need(!is.null(info), "Correlation results are not available."))

      results_accessor <- info$results
      results <- resolve_input_value(results_accessor)

      validate(need(!is.null(results), "Run the correlation analysis to generate plots."))

      if (!is.null(results$message)) {
        validate(need(FALSE, results$message))
      }

      data <- filtered_data()
      validate(need(!is.null(data) && nrow(data) > 0, "No data available."))

      selected_vars <- resolve_input_value(results$selected_vars)
      if (is.null(selected_vars) || length(selected_vars) < 2) {
        numeric_vars <- names(data)[vapply(data, is.numeric, logical(1))]
        selected_vars <- numeric_vars
      }

      validate(need(length(selected_vars) >= 2, "Need at least two numeric columns for GGPairs plot."))

      group_var <- resolve_input_value(info$group_var)
      if (is.null(group_var) || identical(group_var, "None") || identical(group_var, "")) {
        group_var <- NULL
      }

      strata_order <- resolve_input_value(info$strata_order)

      if (is.null(group_var)) {
        plot_data <- data[, selected_vars, drop = FALSE]
        plot_obj <- build_ggpairs_plot(plot_data, basic_color_palette[1])
        layout <- list(nrow = 1L, ncol = 1L)
        list(plot = plot_obj, layout = layout)
      } else {
        available_levels <- NULL
        if (!is.null(results$matrices)) {
          available_levels <- names(results$matrices)
        }
        if (is.null(available_levels) || length(available_levels) == 0) {
          available_levels <- unique(as.character(data[[group_var]]))
        }
        if (!is.null(strata_order) && length(strata_order) > 0) {
          available_levels <- strata_order[strata_order %in% available_levels]
        }
        available_levels <- available_levels[nzchar(available_levels)]
        validate(need(length(available_levels) > 0, "No strata available for plotting."))

        colors <- basic_color_palette[seq_len(min(length(basic_color_palette), length(available_levels)))]
        if (length(colors) < length(available_levels)) {
          extra <- rep("#7F7F7F", length(available_levels) - length(colors))
          colors <- c(colors, extra)
        }
        names(colors) <- available_levels

        plots <- list()
        for (level in available_levels) {
          subset_rows <- !is.na(data[[group_var]]) & as.character(data[[group_var]]) == level
          subset_data <- data[subset_rows, selected_vars, drop = FALSE]
          if (nrow(subset_data) == 0) {
            next
          }
          plots[[level]] <- convert_ggmatrix_to_plot(
            build_ggpairs_plot(subset_data, colors[[level]], title = level)
          )
        }

        validate(need(length(plots) > 0, "No data available for the selected strata."))

        combined <- patchwork::wrap_plots(plotlist = plots, nrow = grid_rows(), ncol = grid_cols())
        layout <- list(nrow = grid_rows(), ncol = grid_cols())
        list(plot = combined, layout = layout)
      }
    })

    plot_width_total <- reactive({
      info <- plot_info()
      layout <- info$layout
      w <- plot_width()
      if (!is.null(layout$ncol)) {
        w <- w * max(1L, as.integer(layout$ncol))
      }
      w
    })

    plot_height_total <- reactive({
      info <- plot_info()
      layout <- info$layout
      h <- plot_height()
      if (!is.null(layout$nrow)) {
        h <- h * max(1L, as.integer(layout$nrow))
      }
      h
    })

    output$download_plot <- downloadHandler(
      filename = function() paste0("pairwise_correlation_ggpairs_", Sys.Date(), ".png"),
      content = function(file) {
        info <- plot_info()
        plot_obj <- info$plot
        req(plot_obj)
        ggplot2::ggsave(
          filename = file,
          plot = plot_obj,
          device = "png",
          dpi = 300,
          width = plot_width_total() / 96,
          height = plot_height_total() / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )

    list(
      plot = reactive({ plot_info()$plot }),
      width = reactive(plot_width_total()),
      height = reactive(plot_height_total())
    )
  })
}
# ===============================================================
# 🧪 Table Analyzer — PCA Module
# ===============================================================

pca_ui <- function(id) {
  ns <- NS(id)
  list(
    config = tagList(
      selectInput(ns("vars"), "Numeric variables:", choices = NULL, multiple = TRUE),
      br(),
      tags$details(
        tags$summary(strong("Advanced options")),
        br(),
        stratification_ui("strat", ns)
      ),
      br(),
      fluidRow(
        column(6, actionButton(ns("run_pca"), "Show PCA summary", width = "100%")),
        column(6, downloadButton(ns("download_all"), "Download all results", style = "width: 100%;"))
      )
    ),
    results = tagList(
      h5("PCA summary and loadings"),
      verbatimTextOutput(ns("summary"))
    )
  )
}

pca_server <- function(id, filtered_data) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    df <- reactive(filtered_data())

    # Dynamically populate numeric variable list
    observe({
      num_vars <- names(df())[sapply(df(), is.numeric)]
      updateSelectInput(session, "vars", choices = num_vars, selected = num_vars)
    })

    strat_info <- stratification_server("strat", df)

    run_pca_on_subset <- function(subset_data, selected_vars) {
      if (is.null(subset_data) || nrow(subset_data) == 0) {
        return(list(model = NULL, data = subset_data, message = "No data available for PCA."))
      }

      numeric_subset <- subset_data[, selected_vars, drop = FALSE]
      complete_idx <- stats::complete.cases(numeric_subset)
      numeric_subset <- numeric_subset[complete_idx, , drop = FALSE]
      plot_data <- subset_data[complete_idx, , drop = FALSE]

      if (nrow(numeric_subset) < 2) {
        return(list(
          model = NULL,
          data = plot_data,
          message = "Not enough complete observations to compute PCA."
        ))
      }

      safe_prcomp <- purrr::safely(function(mat) {
        prcomp(mat, center = TRUE, scale. = TRUE)
      })

      model <- safe_prcomp(numeric_subset)

      if (!is.null(model$error)) {
        return(list(
          model = NULL,
          data = plot_data,
          message = conditionMessage(model$error)
        ))
      }

      list(model = model$result, data = plot_data, message = NULL)
    }

    # Run PCA
    pca_result <- eventReactive(input$run_pca, {
      req(df())

      data <- df()
      validate(need(nrow(data) > 0, "No data available for PCA."))

      numeric_vars <- names(data)[vapply(data, is.numeric, logical(1))]
      selected_vars <- intersect(input$vars, numeric_vars)
      validate(need(length(selected_vars) > 1, "Select at least two numeric variables for PCA."))

      strat_details <- strat_info()
      stratify_var <- strat_details$var
      strata_levels <- strat_details$levels
      local_data <- data

      if (!is.null(stratify_var)) {
        if (is.null(strata_levels) || length(strata_levels) == 0) {
          values <- local_data[[stratify_var]]
          values <- values[!is.na(values)]
          strata_levels <- unique(as.character(values))
        }

        strata_levels <- strata_levels[nzchar(strata_levels)]

        if (length(strata_levels) == 0) {
          return(list(
            group_var = stratify_var,
            strata_levels = character(0),
            selected_vars = selected_vars,
            results = list()
          ))
        }

        keep_rows <- !is.na(local_data[[stratify_var]]) &
          as.character(local_data[[stratify_var]]) %in% strata_levels

        local_data <- local_data[keep_rows, , drop = FALSE]
        local_data[[stratify_var]] <- factor(
          as.character(local_data[[stratify_var]]),
          levels = strata_levels
        )
      }

      results <- list()

      if (is.null(stratify_var)) {
        results[["Overall"]] <- run_pca_on_subset(local_data, selected_vars)
      } else {
        for (level in strata_levels) {
          subset_data <- local_data[as.character(local_data[[stratify_var]]) == level, , drop = FALSE]
          results[[level]] <- run_pca_on_subset(subset_data, selected_vars)
        }
      }

      list(
        group_var = stratify_var,
        strata_levels = strata_levels,
        selected_vars = selected_vars,
        results = results,
        data_used = local_data
      )
    })

    # Verbatim output: summary + loadings
    output$summary <- renderPrint({
      results <- pca_result()
      validate(need(!is.null(results), "Run the PCA analysis to view results."))

      entries <- results$results
      if (is.null(entries) || length(entries) == 0) {
        cat("No PCA results available.")
        return(invisible())
      }

      multiple <- length(entries) > 1

      for (name in names(entries)) {
        entry <- entries[[name]]
        if (multiple) {
          cat(sprintf("===== Stratum: %s =====\n", name))
        }

        if (is.null(entry) || is.null(entry$model)) {
          message <- if (!is.null(entry$message) && nzchar(entry$message)) {
            entry$message
          } else {
            "Not enough data to compute PCA."
          }
          cat(message, "\n\n", sep = "")
          next
        }

        model <- entry$model
        cat("── PCA Summary ──\n")
        print(summary(model))
        cat("\n── PCA Loadings (rotation matrix) ──\n")
        print(round(model$rotation, 3))
        cat("\n── PCA Explained Variance (%) ──\n")
        var_exp <- 100 * model$sdev^2 / sum(model$sdev^2)
        print(round(var_exp, 2))
        cat("\n")
      }

      invisible()
    })

    # Download combined results
    output$download_all <- downloadHandler(
      filename = function() paste0("PCA_results_", Sys.Date(), ".txt"),
      content = function(file) {
        results <- pca_result()
        req(results)

        sink(file)
        on.exit(sink(), add = TRUE)

        entries <- results$results
        if (is.null(entries) || length(entries) == 0) {
          cat("No PCA results available.\n")
          return()
        }

        multiple <- length(entries) > 1

        for (name in names(entries)) {
          entry <- entries[[name]]
          if (multiple) {
            cat(sprintf("===== Stratum: %s =====\n", name))
          }

          if (is.null(entry) || is.null(entry$model)) {
            message <- if (!is.null(entry$message) && nzchar(entry$message)) {
              entry$message
            } else {
              "Not enough data to compute PCA."
            }
            cat(message, "\n\n", sep = "")
            next
          }

          model <- entry$model
          cat("── PCA Summary ──\n")
          print(summary(model))
          cat("\n── PCA Loadings (rotation matrix) ──\n")
          print(round(model$rotation, 3))
          cat("\n── PCA Explained Variance (%) ──\n")
          var_exp <- 100 * model$sdev^2 / sum(model$sdev^2)
          print(round(var_exp, 2))
          cat("\n")
        }
      }
    )

    # Return structured reactive for integration
    df_final <- reactive({
      details <- pca_result()
      if (is.null(details)) return(NULL)
      details$data_used
    })

    model_fit <- reactive({
      details <- pca_result()
      if (is.null(details)) return(NULL)
      details$results
    })

    compiled_tables <- reactive({
      details <- pca_result()
      if (is.null(details)) return(NULL)
      results <- details$results
      if (is.null(results) || length(results) == 0) return(NULL)

      loadings_list <- list()
      variance_list <- list()
      messages_list <- list()

      for (name in names(results)) {
        entry <- results[[name]]
        if (is.null(entry)) {
          loadings_list[[name]] <- NULL
          variance_list[[name]] <- NULL
          messages_list[[name]] <- NULL
          next
        }

        if (!is.null(entry$message)) {
          messages_list[[name]] <- entry$message
        }

        model <- entry$model
        if (is.null(model)) {
          loadings_list[[name]] <- NULL
          variance_list[[name]] <- NULL
          next
        }

        rotation_tbl <- as.data.frame(as.table(model$rotation), stringsAsFactors = FALSE)
        colnames(rotation_tbl) <- c("Variable", "Component", "Loading")
        loadings_list[[name]] <- rotation_tbl

        variance_vals <- 100 * model$sdev^2 / sum(model$sdev^2)
        variance_list[[name]] <- data.frame(
          Component = paste0("PC", seq_along(variance_vals)),
          Variance = variance_vals,
          stringsAsFactors = FALSE
        )
      }

      list(
        summary = loadings_list,
        effects = variance_list,
        messages = messages_list
      )
    })

    summary_table <- reactive({
      res <- compiled_tables()
      if (is.null(res)) return(NULL)
      res$summary
    })

    effect_table <- reactive({
      res <- compiled_tables()
      if (is.null(res)) return(NULL)
      res$effects
    })

    posthoc_results <- reactive(NULL)

    reactive({
      details <- pca_result()
      if (is.null(details)) {
        return(list(
          analysis_type = "PCA",
          data_used = df(),
          model = NULL,
          summary = NULL,
          posthoc = NULL,
          effects = NULL,
          stats = if (!is.null(df())) list(n = nrow(df()), vars = names(df())) else NULL,
          metadata = list(
            selected_vars = input$vars,
            group_var = NULL,
            strata_levels = NULL,
            messages = NULL
          ),
          type = "pca",
          data = df,
          vars = input$vars,
          selected_vars = input$vars,
          group_var = NULL,
          strata_levels = NULL
        ))
      }

      data_used <- df_final()

      compiled <- compiled_tables()
      messages <- if (!is.null(compiled)) compiled$messages else NULL

      list(
        analysis_type = "PCA",
        data_used = data_used,
        model = model_fit(),
        summary = summary_table(),
        posthoc = posthoc_results(),
        effects = effect_table(),
        stats = if (!is.null(data_used)) list(n = nrow(data_used), vars = names(data_used)) else NULL,
        metadata = list(
          selected_vars = details$selected_vars,
          group_var = details$group_var,
          strata_levels = details$strata_levels,
          complete_cases = lapply(details$results, `[[`, "data"),
          messages = messages
        ),
        type = "pca",
        data = df,
        vars = details$selected_vars,
        selected_vars = details$selected_vars,
        group_var = details$group_var,
        strata_levels = details$strata_levels
      )
    })
  })
}
# ===============================================================
# Visualization Module - PCA (Biplot)
# ===============================================================

# Helper to detect categorical columns ----------------------------------------
.is_categorical <- function(x) {
  is.factor(x) || is.character(x) || is.logical(x)
}

.pca_aesthetic_choices <- function(data) {
  if (missing(data) || is.null(data) || !is.data.frame(data) || ncol(data) == 0) {
    return(c("None" = "None"))
  }

  keep <- vapply(data, .is_categorical, logical(1))
  cat_cols <- names(data)[keep]

  if (length(cat_cols) == 0) {
    return(c("None" = "None"))
  }

  c("None" = "None", stats::setNames(cat_cols, cat_cols))
}

visualize_pca_ui <- function(id, filtered_data = NULL) {
  ns <- NS(id)
  choices <- .pca_aesthetic_choices(filtered_data)

  sidebarLayout(
    sidebarPanel(
      width = 4,
      h4("Step 4 — Visualize principal component analysis (PCA)"),
      p("Visualize multivariate structure using a PCA biplot."),
      hr(),
      selectInput(
        ns("plot_type"),
        label = "Select visualization type:",
        choices = c("PCA biplot" = "biplot"),
        selected = "biplot"
      ),
      hr(),
      uiOutput(ns("layout_controls")),
      hr(),
      selectInput(
        ns("pca_color"),
        label = "Color points by:",
        choices = choices,
        selected = "None"
      ),
      selectInput(
        ns("pca_shape"),
        label = "Shape points by:",
        choices = choices,
        selected = "None"
      ),
      selectInput(
        ns("pca_label"),
        label = "Label points by:",
        choices = choices,
        selected = "None"
      ),
      numericInput(
        ns("pca_label_size"),
        label = "Label size:",
        value = 2,
        min = 0.5,
        max = 6,
        step = 0.5
      ),
      checkboxInput(
        ns("show_loadings"),
        label = "Show loadings",
        value = FALSE
      ),
      numericInput(
        ns("loading_scale"),
        label = "Loading arrow scale",
        value = 1.2, min = 0.1, max = 5, step = 0.1
      ),
      hr(),
      uiOutput(ns("layout_controls")),
      fluidRow(
        column(
          width = 6,
          numericInput(
            ns("plot_width"),
            label = "Plot width (px)",
            value = 800,
            min = 200,
            max = 2000,
            step = 50
          )
        ),
        column(
          width = 6,
          numericInput(
            ns("plot_height"),
            label = "Plot height (px)",
            value = 600,
            min = 200,
            max = 2000,
            step = 50
          )
        )
      ),
      hr(),
      downloadButton(ns("download_plot"), "Download plot", style = "width: 100%;")
    ),
    mainPanel(
      width = 8,
      h4("Plots"),
      plotOutput(ns("plot"))
    )
  )
}

visualize_pca_server <- function(id, filtered_data, model_fit) {
  moduleServer(id, function(input, output, session) {
    layout_state <- initialize_layout_state(input, session)
    display_mode <- reactiveVal(NULL)
    # -- Reactives ------------------------------------------------------------
    model_info <- reactive({
      info <- model_fit()
      validate(need(!is.null(info) && identical(info$type, "pca"), "Run PCA first."))
      info
    })

    pca_entries <- reactive({
      info <- model_info()
      entries <- info$model
      validate(need(!is.null(entries) && length(entries) > 0, "PCA model missing."))
      entries
    })

    validate_choice <- function(value, pool) {
      if (is.null(value) || identical(value, "None") || !nzchar(value)) {
        return(NULL)
      }
      if (length(pool) == 0 || !(value %in% pool)) {
        return(NULL)
      }
      value
    }

    pick_reference_entry <- function(entries) {
      if (is.null(entries) || length(entries) == 0) {
        return(NULL)
      }

      valid <- entries[vapply(entries, function(x) !is.null(x) && !is.null(x$data) && nrow(x$data) > 0, logical(1))]
      if (length(valid) > 0) {
        return(valid[[1]])
      }

      entries[[1]]
    }

    available_choices <- reactive({
      entries <- pca_entries()
      entry <- pick_reference_entry(entries)
      data <- if (!is.null(entry)) entry$data else NULL
      .pca_aesthetic_choices(data)
    })

    observeEvent(available_choices(), {
      choices <- available_choices()

      select_valid <- function(current) {
        if (!is.null(current) && current %in% choices) {
          current
        } else {
          "None"
        }
      }

      updateSelectInput(session, "pca_color", choices = choices, selected = select_valid(input$pca_color))
      updateSelectInput(session, "pca_shape", choices = choices, selected = select_valid(input$pca_shape))
      updateSelectInput(session, "pca_label", choices = choices, selected = select_valid(input$pca_label))
    }, ignoreNULL = FALSE)

    output$layout_controls <- renderUI({
      entries <- pca_entries()
      if (length(entries) <= 1) {
        return(NULL)
      }

      ns <- session$ns
      tagList(
        h4("Layout controls"),
        fluidRow(
          column(
            width = 6,
            numericInput(
              ns("strata_rows"),
              "Grid rows",
              value = isolate(layout_state$default_ui_value(input$strata_rows)),
              min = 1,
              max = 10,
              step = 1
            )
          ),
          column(
            width = 6,
            numericInput(
              ns("strata_cols"),
              "Grid columns",
              value = isolate(layout_state$default_ui_value(input$strata_cols)),
              min = 1,
              max = 10,
              step = 1
            )
          )
        )
      )
    })

    observeEvent(model_fit(), {
      info <- model_fit()
      if (is.null(info) || !identical(info$type, "pca")) {
        prefix <- "Plot"
        updateNumericInput(
          session,
          "plot_width",
          label = sprintf("%s width (px)", prefix),
          value = 600
        )
        updateNumericInput(
          session,
          "plot_height",
          label = sprintf("%s height (px)", prefix),
          value = 800
        )
        display_mode(NULL)
        return()
      }

      entries <- info$model
      if (is.null(entries)) {
        entries <- list()
      }

      is_stratified <- !is.null(info$group_var) && length(entries) > 1
      mode_label <- if (is_stratified) "stratified" else "overall"
      prefix <- if (is_stratified) "Subplot" else "Plot"

      if (!identical(mode_label, display_mode())) {
        display_mode(mode_label)

        updateNumericInput(
          session,
          "plot_width",
          label = sprintf("%s width (px)", prefix),
          value = if (is_stratified) 400 else 600
        )
        updateNumericInput(
          session,
          "plot_height",
          label = sprintf("%s height (px)", prefix),
          value = if (is_stratified) 300 else 800
        )
      } else {
        updateNumericInput(
          session,
          "plot_width",
          label = sprintf("%s width (px)", prefix)
        )
        updateNumericInput(
          session,
          "plot_height",
          label = sprintf("%s height (px)", prefix)
        )
      }
    }, ignoreNULL = FALSE)

    build_message_panel <- function(title, message, show_title = TRUE) {
      base_plot <- ggplot() +
        theme_void() +
        annotate(
          "text",
          x = 0.5,
          y = 0.5,
          label = message,
          size = 4,
          hjust = 0.5,
          vjust = 0.5
        ) +
        coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), clip = "off")

      if (isTRUE(show_title) && !is.null(title) && nzchar(title)) {
        base_plot +
          labs(title = title) +
          theme(plot.title = element_text(size = 14, face = "bold", hjust = 0.5))
      } else {
        base_plot +
          theme(plot.title = element_blank())
      }
    }

    sanitize_suffix <- function(value) {
      value <- value[1]
      safe <- gsub("[^A-Za-z0-9]+", "_", value)
      safe <- gsub("_+", "_", safe)
      safe <- gsub("^_|_$", "", safe)
      if (!nzchar(safe)) {
        "stratum"
      } else {
        tolower(safe)
      }
    }

    plot_info <- reactive({
      req(input$plot_type)
      validate(need(input$plot_type == "biplot", "Unsupported plot type."))
      info_full <- model_info()
      entries <- pca_entries()
      validate(need(length(entries) > 0, "No PCA results available."))

      is_stratified <- !is.null(info_full$group_var) && length(entries) > 1

      choices <- available_choices()
      color_var <- validate_choice(input$pca_color, choices)
      shape_var <- validate_choice(input$pca_shape, choices)
      label_var <- validate_choice(input$pca_label, choices)
      label_size <- ifelse(is.null(input$pca_label_size) || is.na(input$pca_label_size), 2, input$pca_label_size)
      show_loadings <- isTRUE(input$show_loadings)
      loading_scale <- ifelse(is.null(input$loading_scale) || is.na(input$loading_scale), 1.2, input$loading_scale)

      plot_list <- list()
      strata_names <- names(entries)
      if (is.null(strata_names) || length(strata_names) == 0) {
        strata_names <- paste0("Stratum ", seq_along(entries))
      }

      for (i in seq_along(entries)) {
        entry <- entries[[i]]
        key <- strata_names[[i]]
        if (!nzchar(key)) {
          key <- paste0("Stratum ", i)
        }
        title <- if (is_stratified) key else NULL

        if (is.null(entry)) {
          plot_list[[key]] <- build_message_panel(title = title, message = "No PCA results available.", show_title = is_stratified)
          next
        }

        if (!is.null(entry$message) && nzchar(entry$message)) {
          plot_list[[key]] <- build_message_panel(title = title, message = entry$message, show_title = is_stratified)
          next
        }

        if (is.null(entry$model) || is.null(entry$model$x) || nrow(entry$model$x) < 2) {
          plot_list[[key]] <- build_message_panel(title = title, message = "PCA scores not available.", show_title = is_stratified)
          next
        }

        data <- entry$data
        local_color <- if (!is.null(color_var) && !is.null(data) && color_var %in% names(data)) color_var else NULL
        local_shape <- if (!is.null(shape_var) && !is.null(data) && shape_var %in% names(data)) shape_var else NULL
        local_label <- if (!is.null(label_var) && !is.null(data) && label_var %in% names(data)) label_var else NULL

        plot_obj <- build_pca_biplot(
          pca_obj = entry$model,
          data = data,
          color_var = local_color,
          shape_var = local_shape,
          label_var = local_label,
          label_size = label_size,
          show_loadings = show_loadings,
          loading_scale = loading_scale
        )

        if (is_stratified && !is.null(title) && nzchar(title)) {
          plot_obj <- plot_obj +
            ggtitle(title) +
            theme(plot.title = element_text(size = 14, face = "bold"))
        }

        plot_list[[key]] <- plot_obj
      }

      plot_list <- Filter(Negate(is.null), plot_list)
      validate(need(length(plot_list) > 0, "No PCA plots available."))

      layout <- resolve_grid_layout(
        n_items = length(plot_list),
        rows_input = layout_state$effective_input("strata_rows"),
        cols_input = layout_state$effective_input("strata_cols")
      )

      combined <- patchwork::wrap_plots(
        plotlist = plot_list,
        nrow = layout$nrow,
        ncol = layout$ncol
      ) +
        patchwork::plot_layout(guides = "collect")

      list(
        plot = combined,
        layout = layout,
        strata_names = names(plot_list)
      )
    })

    observe_layout_synchronization(plot_info, layout_state, session)

    plot_size <- reactive({
      width <- suppressWarnings(as.numeric(input$plot_width))
      height <- suppressWarnings(as.numeric(input$plot_height))
      info <- plot_info()
      layout <- info$layout

      subplot_w <- ifelse(is.na(width) || width <= 0, 400, width)
      subplot_h <- ifelse(is.na(height) || height <= 0, 300, height)

      list(
        w = subplot_w * max(1, layout$ncol),
        h = subplot_h * max(1, layout$nrow)
      )

      combined <- patchwork::wrap_plots(
        plotlist = plot_list,
        nrow = layout$nrow,
        ncol = layout$ncol
      ) +
        patchwork::plot_layout(guides = "collect")

      list(
        plot = combined,
        layout = layout,
        strata_names = names(plot_list)
      )
    })

    observe_layout_synchronization(plot_info, layout_state, session)

    plot_size <- reactive({
      width <- suppressWarnings(as.numeric(input$plot_width))
      height <- suppressWarnings(as.numeric(input$plot_height))
      info <- plot_info()
      layout <- info$layout

      subplot_w <- ifelse(is.na(width) || width <= 0, 400, width)
      subplot_h <- ifelse(is.na(height) || height <= 0, 300, height)

      list(
        w = subplot_w * max(1, layout$ncol),
        h = subplot_h * max(1, layout$nrow)
      )
    })

    plot_obj <- reactive({
      info <- plot_info()
      validate(need(!is.null(info$plot), "No PCA plots available."))
      info$plot
    })

    plot_obj <- reactive({
      info <- plot_info()
      validate(need(!is.null(info$plot), "No PCA plots available."))
      info$plot
    })

    output$plot <- renderPlot({
      req(plot_obj())
      plot_obj()
    },
    width = function() plot_size()$w,
    height = function() plot_size()$h,
    res = 96)

    output$download_plot <- downloadHandler(
      filename = function() {
        info <- plot_info()
        strata <- info$strata_names
        suffix <- if (length(strata) == 1) {
          paste0("_", sanitize_suffix(strata))
        } else {
          "_all_strata"
        }
        paste0("pca_biplot", suffix, "_", Sys.Date(), ".png")
      },
      content = function(file) {
        info <- plot_info()
        size <- plot_size()

        ggsave(
          filename = file,
          plot = info$plot,
          device = "png",
          dpi = 300,
          width = size$w / 96,
          height = size$h / 96,
          units = "in",
          limitsize = FALSE
        )
      }
    )
  })
}


build_pca_biplot <- function(pca_obj, data, color_var = NULL, shape_var = NULL,
                             label_var = NULL, label_size = 2,
                             show_loadings = FALSE, loading_scale = 1.2) {
  stopifnot(!is.null(pca_obj$x))
  
  scores <- as.data.frame(pca_obj$x[, 1:2])
  names(scores)[1:2] <- c("PC1", "PC2")
  
  var_exp <- 100 * (pca_obj$sdev^2 / sum(pca_obj$sdev^2))
  x_lab <- sprintf("PC1 (%.1f%%)", var_exp[1])
  y_lab <- sprintf("PC2 (%.1f%%)", var_exp[2])
  
  if (!is.null(data) && nrow(data) == nrow(scores)) {
    plot_data <- cbind(scores, data)
  } else {
    plot_data <- scores
  }
  
  if (!is.null(label_var) && !identical(label_var, "") && !is.null(plot_data[[label_var]])) {
    label_values <- as.character(plot_data[[label_var]])
    label_values[is.na(label_values) | trimws(label_values) == ""] <- NA_character_
    if (any(!is.na(label_values))) {
      plot_data$label_value <- label_values
    } else {
      label_var <- NULL
    }
  } else {
    label_var <- NULL
  }
  
  color_levels <- NULL
  if (!is.null(color_var) && !is.null(plot_data[[color_var]])) {
    color_levels <- if (is.factor(plot_data[[color_var]])) levels(plot_data[[color_var]]) else unique(as.character(plot_data[[color_var]]))
    color_levels <- color_levels[!is.na(color_levels)]
    plot_data[[color_var]] <- factor(as.character(plot_data[[color_var]]), levels = color_levels)
  }
  
  aes_mapping <- aes(x = PC1, y = PC2)
  if (!is.null(color_var)) aes_mapping <- modifyList(aes_mapping, aes(color = .data[[color_var]]))
  if (!is.null(shape_var)) aes_mapping <- modifyList(aes_mapping, aes(shape = .data[[shape_var]]))
  
  single_color <- resolve_single_color()
  g <- ggplot(plot_data, aes_mapping) +
    geom_point(
      size = 3,
      shape = if (is.null(shape_var)) 16 else NULL,
      color = if (is.null(color_var)) single_color else NULL
    ) +
    theme_minimal(base_size = 14) +
    labs(
      x = x_lab,
      y = y_lab,
      color = if (!is.null(color_var)) color_var else NULL,
      shape = if (!is.null(shape_var)) shape_var else NULL
    ) +
    theme(
      plot.title = element_text(size = 16, face = "bold"),
      legend.position = "right"
    )
  
  if (!is.null(color_var)) {
    palette <- resolve_palette_for_levels(color_levels)
    g <- g + scale_color_manual(values = palette)
  }
  
  if (!is.null(label_var)) {
    g <- g + ggrepel::geom_text_repel(
      aes(label = label_value),
      color = if (is.null(color_var)) single_color else NULL,
      size = label_size,
      max.overlaps = Inf,
      min.segment.length = 0,
      box.padding = 0.3,
      point.padding = 0.2,
      segment.size = 0.2,
      na.rm = TRUE
    )
  }
  
  # ---- Loadings as arrows (optional) ----
  if (isTRUE(show_loadings) && !is.null(pca_obj$rotation)) {
    R <- as.data.frame(pca_obj$rotation[, 1:2, drop = FALSE])
    R$variable <- rownames(pca_obj$rotation)
    
    # scale arrows to score space
    rx <- diff(range(scores$PC1, na.rm = TRUE))
    ry <- diff(range(scores$PC2, na.rm = TRUE))
    sx <- ifelse(is.finite(rx) && rx > 0, rx, 1)
    sy <- ifelse(is.finite(ry) && ry > 0, ry, 1)
    
    arrows_df <- transform(
      R,
      x = 0, y = 0,
      xend = PC1 * sx * loading_scale,
      yend = PC2 * sy * loading_scale
    )
    
    g <- g +
      geom_segment(
        data = arrows_df,
        aes(x = x, y = y, xend = xend, yend = yend),
        inherit.aes = FALSE,
        arrow = grid::arrow(length = grid::unit(0.02, "npc")),
        linewidth = 0.4,
        color = "grey30"
      ) +
      ggrepel::geom_text_repel(
        data = arrows_df,
        aes(x = xend, y = yend, label = variable),
        inherit.aes = FALSE,
        size = 3,
        color = "grey20",
        max.overlaps = Inf,
        segment.size = 0.2,
        box.padding = 0.2,
        point.padding = 0.2
      )
  }
  
  g
}
# ===============================================================
# 🧬 Common module for LM and LMM
# ===============================================================

regression_ui <- function(id, engine = c("lm", "lmm"), allow_multi_response = FALSE) {
  ns <- NS(id)
  engine <- match.arg(engine)
  allow_multi_response <- isTRUE(allow_multi_response)

  list(
    config = tagList(
      if (allow_multi_response) multi_response_ui(ns("response")) else uiOutput(ns("response_ui")),
      uiOutput(ns("fixed_selector")),
      uiOutput(ns("level_order")),
      uiOutput(ns("covar_selector")),
      if (engine == "lmm") uiOutput(ns("random_selector")),
      uiOutput(ns("interaction_select")),
      tags$details(
        tags$summary(strong("Advanced options")),
        br(),
        stratification_ui("strat", ns)
      ),
      hr(),
      uiOutput(ns("formula_preview")),
      br(),
      fluidRow(
        column(6, actionButton(ns("run"), "Show results", width = "100%")),
        column(6, downloadButton(ns("download_model"), "Download all results", style = "width: 100%;"))
      )
    ),
    results = tagList(
      uiOutput(ns("results_ui"))
    )
  )
}

regression_server <- function(id, data, engine = c("lm", "lmm"), allow_multi_response = FALSE) {
  engine <- match.arg(engine)
  allow_multi_response <- isTRUE(allow_multi_response)

  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    strat_info <- stratification_server("strat", data)

    if (allow_multi_response) {
      selected_responses <- multi_response_server("response", data)
    } else {
      output$response_ui <- renderUI({
        req(data())
        types <- reg_detect_types(data())
        selectInput(ns("dep"), "Response variable (numeric):", choices = types$num)
      })

      selected_responses <- reactive({
        req(input$dep)
        input$dep
      })
    }

    output$fixed_selector <- renderUI({
      req(data())
      types <- reg_detect_types(data())
      selectInput(
        ns("fixed"),
        "Categorical predictors:",
        choices = types$fac,
        multiple = TRUE
      )
    })

    output$level_order <- renderUI({
      req(data())
      req(input$fixed)

      df <- data()
      fac_vars <- input$fixed
      if (engine == "lmm" && !is.null(input$random) && nzchar(input$random)) {
        fac_vars <- unique(c(fac_vars, input$random))
      }

      if (length(fac_vars) == 0) return(NULL)

      tagList(
        lapply(fac_vars, function(var) {
          values <- df[[var]]
          if (is.factor(values)) lvls <- levels(values)
          else {
            values <- values[!is.na(values)]
            lvls <- unique(as.character(values))
          }
          selectInput(
            ns(paste0("order_", var)),
            paste("Order of levels (first = reference):", var),
            choices = lvls,
            selected = lvls,
            multiple = TRUE
          )
        })
      )
    })

    output$covar_selector <- renderUI({
      req(data())
      types <- reg_detect_types(data())
      selectInput(
        ns("covar"),
        "Numeric predictors:",
        choices = types$num,
        multiple = TRUE
      )
    })

    if (engine == "lmm") {
      output$random_selector <- renderUI({
        req(data())
        types <- reg_detect_types(data())
        selectInput(
          ns("random"),
          "Random effect (categorical):",
          choices = types$fac,
          selected = NULL
        )
      })
    }

    output$interaction_select <- renderUI({
      req(data())
      types <- reg_detect_types(data())
      reg_interactions_ui(ns, input$fixed, types$fac)
    })

    output$formula_preview <- renderUI({
      responses <- selected_responses()
      req(length(responses) > 0)
      rhs <- reg_compose_rhs(
        input$fixed,
        input$covar,
        input$interactions,
        if (engine == "lmm") input$random else NULL,
        engine = engine
      )
      reg_formula_preview_ui(ns, responses[1], rhs)
    })

    models <- eventReactive(input$run, {
      req(data())
      df <- data()
      responses <- selected_responses()
      req(length(responses) > 0)

      rhs <- reg_compose_rhs(
        input$fixed,
        input$covar,
        input$interactions,
        if (engine == "lmm") input$random else NULL,
        engine = engine
      )

      strat_details <- strat_info()
      safe_fit <- purrr::safely(reg_fit_model)

      fits <- list()
      success_resps <- character(0)
      error_resps <- character(0)
      success_models <- list()
      error_messages <- list()
      flat_models <- list()
      primary_model <- NULL
      primary_error <- NULL

      for (resp in responses) {
        if (is.null(strat_details$var)) {
          result <- safe_fit(resp, rhs, df, engine = engine)
          entry <- list(
            stratified = FALSE,
            strata = list(list(
              label = NULL,
              display = "Overall",
              model = if (is.null(result$error)) result$result else NULL,
              error = if (!is.null(result$error)) result$error$message else NULL
            ))
          )
          fits[[resp]] <- entry

          if (is.null(result$error)) {
            success_resps <- c(success_resps, resp)
            success_models[[resp]] <- list(Overall = result$result)
            flat_models[[length(flat_models) + 1]] <- list(
              response = resp,
              stratum = NULL,
              model = result$result
            )
            if (is.null(primary_model)) primary_model <- result$result
          } else {
            error_resps <- c(error_resps, resp)
            error_messages[[resp]] <- result$error$message
            if (is.null(primary_error)) primary_error <- result$error$message
          }
        } else {
          strata_entries <- list()
          successful_strata <- list()

          for (level in strat_details$levels) {
            subset_data <- df[df[[strat_details$var]] == level, , drop = FALSE]
            if (nrow(subset_data) == 0) {
              msg <- paste0("No observations available for stratum '", level, "'.")
              strata_entries[[length(strata_entries) + 1]] <- list(
                label = level,
                display = level,
                model = NULL,
                error = msg
              )
              next
            }

            result <- safe_fit(resp, rhs, subset_data, engine = engine)
            if (!is.null(result$error)) {
              strata_entries[[length(strata_entries) + 1]] <- list(
                label = level,
                display = level,
                model = NULL,
                error = result$error$message
              )
            } else {
              strata_entries[[length(strata_entries) + 1]] <- list(
                label = level,
                display = level,
                model = result$result,
                error = NULL
              )
              successful_strata[[level]] <- result$result
              flat_models[[length(flat_models) + 1]] <- list(
                response = resp,
                stratum = level,
                model = result$result
              )
              if (is.null(primary_model)) primary_model <- result$result
            }
          }

          fits[[resp]] <- list(
            stratified = TRUE,
            strata = strata_entries
          )

          if (length(successful_strata) > 0) {
            success_resps <- c(success_resps, resp)
            success_models[[resp]] <- successful_strata
          } else {
            error_resps <- c(error_resps, resp)
            errors_vec <- vapply(
              strata_entries,
              function(entry) {
                if (!is.null(entry$error)) {
                  paste0(entry$display, ": ", entry$error)
                } else {
                  NA_character_
                }
              },
              character(1)
            )
            errors_vec <- errors_vec[!is.na(errors_vec)]
            combined_error <- paste(errors_vec, collapse = "\n")
            if (!nzchar(combined_error)) combined_error <- "Model fitting failed."
            error_messages[[resp]] <- combined_error
            if (is.null(primary_error)) primary_error <- combined_error
          }
        }
      }

      list(
        responses = responses,
        success_responses = unique(success_resps),
        error_responses = unique(error_resps),
        fits = fits,
        models = success_models,
        flat_models = flat_models,
        model = primary_model,
        errors = error_messages,
        error = primary_error,
        rhs = rhs,
        allow_multi = allow_multi_response,
        stratification = strat_details
      )
    })

    build_panel_content <- function(idx, response, fit_entry) {
      strata <- fit_entry$strata

      if (!isTRUE(fit_entry$stratified)) {
        stratum <- strata[[1]]
        tagList(
          verbatimTextOutput(ns(paste0("summary_", idx))),
          br(),
          h5("Diagnostics"),
          fluidRow(
            column(6, plotOutput(ns(paste0("resid_", idx)))),
            column(6, plotOutput(ns(paste0("qq_", idx))))
          ),
          br(),
          downloadButton(ns(paste0("download_", idx)), "Download results", style = "width: 100%;")
        )
      } else {
          stratum_tabs <- lapply(seq_along(strata), function(j) {
            stratum <- strata[[j]]
            label <- if (!is.null(stratum$display)) stratum$display else paste("Stratum", j)

            content <- if (!is.null(stratum$model)) {
              tagList(
                verbatimTextOutput(ns(paste0("summary_", idx, "_", j))),
                br(),
              h5("Diagnostics"),
              fluidRow(
                column(6, plotOutput(ns(paste0("resid_", idx, "_", j)))),
                column(6, plotOutput(ns(paste0("qq_", idx, "_", j))))
              ),
              br(),
              downloadButton(ns(paste0("download_", idx, "_", j)), "Download results", style = "width: 100%;")
            )
          } else {
            div(
              class = "alert alert-warning",
              if (!is.null(stratum$error)) stratum$error else "Model fitting failed."
            )
          }

          tabPanel(title = label, content)
        })

        do.call(
          tabsetPanel,
          c(list(id = ns(paste0("strata_tabs_", idx))), stratum_tabs)
        )
      }
    }

    output$results_ui <- renderUI({
      mod <- models()
      if (is.null(mod)) return(NULL)

      success_resps <- mod$success_responses
      error_resps <- mod$error_responses
      fits <- mod$fits

      error_block <- NULL
      if (!is.null(error_resps) && length(error_resps) > 0) {
        error_items <- lapply(error_resps, function(resp) {
          err <- mod$errors[[resp]]
          tags$li(tags$strong(resp), ": ", if (!is.null(err)) err else "Model fitting failed.")
        })
        error_block <- div(
          class = "alert alert-warning",
          strong("Models with errors:"),
          tags$ul(error_items)
        )
      }

      if (is.null(success_resps) || length(success_resps) == 0) {
        if (!is.null(error_block)) return(tagList(error_block))
        return(NULL)
      }

      panels <- lapply(seq_along(success_resps), function(idx) {
        response <- success_resps[idx]
        fit_entry <- fits[[response]]
        content <- build_panel_content(idx, response, fit_entry)

        if (length(success_resps) > 1) {
          tabPanel(title = response, content)
        } else {
          content
        }
      })

      results_block <- if (length(success_resps) > 1) {
        do.call(tabsetPanel, c(list(id = ns("results_tabs")), panels))
      } else {
        panels[[1]]
      }

      tagList(
        if (!is.null(error_block)) error_block,
        results_block
      )
    })

    observeEvent(models(), {
      mod <- models()
      if (is.null(mod)) return()

      success_resps <- mod$success_responses
      fits <- mod$fits
      if (is.null(success_resps) || length(success_resps) == 0) return()

      for (idx in seq_along(success_resps)) {
        local({
          local_idx <- idx
          response <- success_resps[local_idx]
          fit_entry <- fits[[response]]

          if (!isTRUE(fit_entry$stratified)) {
            stratum <- fit_entry$strata[[1]]
            model_obj <- stratum$model

            output[[paste0("summary_", local_idx)]] <- renderPrint({
              if (engine == "lm") {
                reg_display_lm_summary(model_obj)
              } else {
                reg_display_lmm_summary(model_obj)
              }
            })

            output[[paste0("resid_", local_idx)]] <- renderPlot({
              plot(fitted(model_obj), resid(model_obj), xlab = "Fitted values", ylab = "Residuals")
              abline(h = 0, lty = 2)
            })

            output[[paste0("qq_", local_idx)]] <- renderPlot({
              qqnorm(resid(model_obj))
              qqline(resid(model_obj))
            })

            output[[paste0("download_", local_idx)]] <- downloadHandler(
              filename = function() {
                paste0(
                  engine,
                  "_results_",
                  response,
                  "_",
                  Sys.Date(),
                  ".docx"
                )
              },
              content = function(file) {
                write_lm_docx(model_obj, file)
              }
            )
          } else {
            strata <- fit_entry$strata
            for (j in seq_along(strata)) {
              local({
                local_j <- j
                stratum <- strata[[local_j]]
                if (is.null(stratum$model)) return()
                model_obj <- stratum$model

                output[[paste0("summary_", local_idx, "_", local_j)]] <- renderPrint({
                  if (engine == "lm") {
                    reg_display_lm_summary(model_obj)
                  } else {
                    reg_display_lmm_summary(model_obj)
                  }
                })

                output[[paste0("resid_", local_idx, "_", local_j)]] <- renderPlot({
                  plot(fitted(model_obj), resid(model_obj), xlab = "Fitted values", ylab = "Residuals")
                  abline(h = 0, lty = 2)
                })

                output[[paste0("qq_", local_idx, "_", local_j)]] <- renderPlot({
                  qqnorm(resid(model_obj))
                  qqline(resid(model_obj))
                })

                output[[paste0("download_", local_idx, "_", local_j)]] <- downloadHandler(
                  filename = function() {
                    paste0(
                      engine,
                      "_results_",
                      response,
                      "_",
                      stratum$display,
                      "_",
                      Sys.Date(),
                      ".docx"
                    )
                  },
                  content = function(file) {
                    write_lm_docx(model_obj, file)
                  }
                )
              })
            }
          }
        })
      }
    }, ignoreNULL = FALSE)

    output$download_model <- downloadHandler(
      filename = function() {
        mod <- models()
        if (is.null(mod) || length(mod$flat_models) == 0) {
          return(paste0(engine, "_results_", Sys.Date(), ".docx"))
        }

        if (length(mod$flat_models) == 1) {
          entry <- mod$flat_models[[1]]
          parts <- c(engine, "results", entry$response)
          if (!is.null(entry$stratum)) parts <- c(parts, entry$stratum)
          paste0(paste(parts, collapse = "_"), "_", Sys.Date(), ".docx")
        } else {
          paste0(engine, "_all_results_", Sys.Date(), ".docx")
        }
      },
      content = function(file) {
        mod <- models()
        if (is.null(mod)) stop("No models available. Please run the analysis first.")
        flat_models <- mod$flat_models
        if (length(flat_models) == 0) stop("No models available. Please run the analysis first.")

        if (length(flat_models) == 1) {
          write_lm_docx(flat_models[[1]]$model, file)
        } else {
          doc <- officer::read_docx()
          for (entry in flat_models) {
            tmp <- tempfile(fileext = ".docx")
            sublab <- if (!is.null(entry$stratum)) paste("Stratum:", entry$stratum) else NULL
            
            # pass subtitle so it appears RIGHT under the title
            write_lm_docx(entry$model, tmp, subtitle = sublab)
            
            doc <- officer::body_add_docx(doc, src = tmp)
            doc <- officer::body_add_par(doc, "", style = "Normal")
          }
          print(doc, target = file)
        }
      }
    )

    df_final <- reactive({
      data()
    })

    model_fit <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      mod$models
    })

    compiled_results <- reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)
      compile_regression_results(mod, engine)
    })

    summary_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$summary
    })

    effect_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$effects
    })

    error_table <- reactive({
      res <- compiled_results()
      if (is.null(res)) return(NULL)
      res$errors
    })

    reactive({
      mod <- models()
      if (is.null(mod)) return(NULL)

      data_used <- df_final()

      list(
        analysis_type = if (engine == "lm") "LM" else "LMM",
        data_used = data_used,
        model = model_fit(),
        summary = summary_table(),
        posthoc = NULL,
        effects = effect_table(),
        stats = if (!is.null(data_used)) list(n = nrow(data_used), vars = names(data_used)) else NULL,
        metadata = list(
          responses = mod$responses,
          success_responses = mod$success_responses,
          error_responses = mod$error_responses,
          errors = mod$errors,
          stratification = mod$stratification,
          rhs = mod$rhs,
          allow_multi = mod$allow_multi,
          compiled_errors = error_table(),
          flat_models = mod$flat_models,
          engine = engine
        ),
        type = if (engine == "lm") "lm" else "lmm",
        fits = mod$fits,
        flat_models = mod$flat_models,
        stratification = mod$stratification,
        responses = mod$responses,
        errors = mod$errors
      )
    })
  })
}
# ===============================================================
# 🔧 Shared helpers for LM/LMM (UI + server utilities)
# ===============================================================

# ---------------------------------------------------------------
# UI setup
# ---------------------------------------------------------------

reg_detect_types <- function(df) {
  num_vars <- names(df)[sapply(df, is.numeric)]
  fac_vars <- names(df)[sapply(df, function(x) is.factor(x) || is.character(x))]
  list(num = num_vars, fac = fac_vars)
}

reg_variable_selectors_ui <- function(ns, types, allow_random = FALSE) {
  out <- list(
    selectInput(ns("dep"), "Response variable (numeric):", choices = types$num),
    selectInput(ns("fixed"), "Categorical predictors:", choices = types$fac, multiple = TRUE),
    selectInput(ns("covar"), "Numeric predictors:", choices = types$num, multiple = TRUE)
  )
  if (allow_random) {
    out <- c(out, list(
      selectInput(ns("random"), "Random effect (categorical):", choices = types$fac, selected = NULL)
    ))
  }
  do.call(tagList, out)
}

reg_interactions_ui <- function(ns, fixed, fac_vars) {
  if (is.null(fixed) || length(fixed) < 2) return(NULL)
  cats_only <- intersect(fixed, fac_vars)
  if (length(cats_only) < 2) return(NULL)
  pairs <- combn(cats_only, 2, simplify = FALSE)
  pair_labels <- vapply(pairs, function(p) paste(p, collapse = " × "), character(1))
  pair_values <- vapply(pairs, function(p) paste(p, collapse = ":"), character(1))
  checkboxGroupInput(
    ns("interactions"),
    label = "Select 2-way interactions (optional):",
    choices = stats::setNames(pair_values, pair_labels)
  )
}

# ---------------------------------------------------------------
# Formula construction
# ---------------------------------------------------------------

reg_compose_rhs <- function(fixed, covar, interactions, random = NULL, engine = c("lm","lmm")) {
  engine <- match.arg(engine)
  rhs <- character(0)
  if (!is.null(fixed) && length(fixed) > 0) rhs <- c(rhs, fixed)
  if (!is.null(covar) && length(covar) > 0) rhs <- c(rhs, covar)
  if (!is.null(interactions) && length(interactions) > 0) rhs <- c(rhs, interactions)
  if (engine == "lmm" && !is.null(random) && nzchar(random)) {
    rhs <- c(rhs, paste0("(1|", random, ")"))
  }
  rhs
}

reg_formula_preview_ui <- function(ns, dep, rhs) {
  if (is.null(dep) || !nzchar(dep)) return(NULL)
  form_txt <- if (length(rhs) == 0) paste(dep, "~ 1") else paste(dep, "~", paste(rhs, collapse = " + "))
  wellPanel(
    strong("Model formula: "),
    code(form_txt)
  )
}

# ---------------------------------------------------------------
# Model computation
# ---------------------------------------------------------------

reg_fit_model <- function(dep, rhs, data, engine = c("lm","lmm")) {
  engine <- match.arg(engine)
  form <- as.formula(if (length(rhs) == 0) paste(dep, "~ 1") else paste(dep, "~", paste(rhs, collapse = " + ")))
  if (engine == "lm") {
    lm(form, data = data)
  } else {
    # LMM: lme4 + lmerTest for p-values
    lmerTest::lmer(form, data = data)
  }
}

# ---------------------------------------------------------------
# Output composition
# ---------------------------------------------------------------

reg_display_lm_summary <- function(m) {
  aout <- capture.output(car::Anova(m, type = 3))
  signif_idx <- grep("^Signif\\. codes", aout)
  if (length(signif_idx) > 0) {
    remove_idx <- c(signif_idx - 1, signif_idx)
    aout <- aout[-remove_idx]
  }
  cat(paste(aout, collapse = "\n"), "\n\n")
  
  sout <- capture.output(summary(m))
  start <- grep("^Residuals:", sout)[1]
  stop  <- grep("^Signif\\. codes", sout)[1]
  if (!is.na(start)) {
    if (!is.na(stop)) sout <- sout[start:(stop - 2)]
    else sout <- sout[start:length(sout)]
  }
  cat(paste(sout, collapse = "\n"))
}

reg_display_lmm_summary <- function(m) {
  aout <- capture.output(anova(m, type = 3))
  cat(paste(aout, collapse = "\n"), "\n\n")

  sout <- capture.output(summary(m))
  start <- grep("^Scaled residuals:", sout)[1]
  stop  <- grep("^Correlation of Fixed Effects:", sout)[1]
  if (!is.na(start)) {
    if (!is.na(stop)) sout <- sout[start:(stop - 1)]
    else sout <- sout[start:length(sout)]
  }
  
  icc_df <- compute_icc(m)
  if (!is.null(icc_df) && nrow(icc_df) > 0) {
    icc_line <- paste(paste0("ICC (", icc_df$Group, "): ", icc_df$ICC), collapse = "; ")
    random_idx <- grep("^Random effects:", sout)[1]
    if (!is.na(random_idx)) sout <- append(sout, paste0("\n", icc_line), after = random_idx + 4)
    else sout <- c(sout, icc_line)
  }
  cat(paste(sout, collapse = "\n"))
}

# ---------------------------------------------------------------
# Summaries for standardized regression outputs
# ---------------------------------------------------------------

clean_regression_coef_names <- function(nms) {
  vapply(nms, function(name) {
    name_trim <- trimws(name)
    if (identical(name_trim, "Estimate")) return("estimate")
    if (name_trim %in% c("Std. Error", "Std Error", "Std. error")) return("std_error")
    if (tolower(name_trim) %in% c("t value", "z value", "f value")) return("statistic")
    if (tolower(name_trim) %in% c("df", "dendf", "numdf")) return(tolower(name_trim))
    if (grepl("^Pr\\(>", name_trim)) return("p_value")
    cleaned <- tolower(name_trim)
    cleaned <- gsub("[^[:alnum:]]+", "_", cleaned)
    cleaned <- gsub("^_+|_+$", "", cleaned)
    cleaned <- gsub("_+", "_", cleaned)
    cleaned
  }, character(1), USE.NAMES = FALSE)
}

tidy_regression_model <- function(model, engine) {
  if (is.null(model)) {
    return(list(summary = NULL, effects = NULL))
  }

  coef_mat <- tryCatch(summary(model)$coefficients, error = function(e) NULL)
  coef_df <- NULL
  if (!is.null(coef_mat)) {
    coef_df <- data.frame(
      term = rownames(coef_mat),
      coef_mat,
      row.names = NULL,
      check.names = FALSE,
      stringsAsFactors = FALSE
    )
    original_names <- names(coef_df)
    names(coef_df) <- c("term", clean_regression_coef_names(original_names[-1]))
  }

  metrics <- NULL
  if (inherits(model, "lm")) {
    sm <- summary(model)
    metrics <- data.frame(
      metric = c("sigma", "r_squared", "adj_r_squared", "nobs"),
      value = c(sm$sigma, sm$r.squared, sm$adj.r.squared, stats::nobs(model)),
      stringsAsFactors = FALSE
    )
  } else {
    metrics <- data.frame(
      metric = c("sigma", "logLik", "AIC", "BIC", "nobs"),
      value = c(
        stats::sigma(model),
        as.numeric(stats::logLik(model)),
        stats::AIC(model),
        stats::BIC(model),
        stats::nobs(model)
      ),
      stringsAsFactors = FALSE
    )
  }

  anova_tbl <- tryCatch({
    if (engine == "lm") {
      car::Anova(model, type = 3)
    } else {
      anova(model, type = 3)
    }
  }, error = function(e) NULL)

  if (!is.null(anova_tbl)) {
    anova_tbl <- as.data.frame(anova_tbl)
    anova_tbl$Effect <- rownames(anova_tbl)
    rownames(anova_tbl) <- NULL
    anova_tbl <- anova_tbl[, c("Effect", setdiff(names(anova_tbl), "Effect"))]
  }

  effects <- list(metrics = metrics, anova = anova_tbl)
  if (all(vapply(effects, is.null, logical(1)))) effects <- NULL

  list(summary = coef_df, effects = effects)
}

compile_regression_results <- function(model_info, engine) {
  if (is.null(model_info) || is.null(model_info$fits)) return(NULL)

  summary_list <- list()
  effects_list <- list()
  errors_list <- list()

  for (resp in names(model_info$fits)) {
    fit_entry <- model_info$fits[[resp]]
    if (is.null(fit_entry)) next

    if (isTRUE(fit_entry$stratified)) {
      strata_entries <- fit_entry$strata
      for (stratum in strata_entries) {
        label <- if (!is.null(stratum$display)) stratum$display else stratum$label
        if (is.null(label) || !nzchar(label)) label <- "Stratum"
        tidy <- tidy_regression_model(stratum$model, engine)
        if (is.null(summary_list[[resp]])) summary_list[[resp]] <- list()
        if (is.null(effects_list[[resp]])) effects_list[[resp]] <- list()
        summary_list[[resp]][[label]] <- tidy$summary
        effects_list[[resp]][[label]] <- tidy$effects
        if (!is.null(stratum$error)) {
          if (is.null(errors_list[[resp]])) errors_list[[resp]] <- list()
          errors_list[[resp]][[label]] <- stratum$error
        }
      }
    } else {
      stratum <- fit_entry$strata[[1]]
      tidy <- tidy_regression_model(stratum$model, engine)
      summary_list[[resp]] <- tidy$summary
      effects_list[[resp]] <- tidy$effects
      if (!is.null(stratum$error)) {
        errors_list[[resp]] <- stratum$error
      }
    }
  }

  list(summary = summary_list, effects = effects_list, errors = errors_list)
}

# ===============================================================
# Results export
# ===============================================================

write_lm_docx <- function(model, file, subtitle = NULL) {
  
  # Determine model type
  is_lmm <- inherits(model, "merMod")
  dep_var <- all.vars(formula(model))[1]

  # Helper for consistent table formatting
  format_table <- function(df, bold_p = TRUE) {
    ft <- flextable(df)
    ft <- fontsize(ft, part = "all", size = 10)
    ft <- bold(ft, part = "header", bold = TRUE)
    ft <- color(ft, part = "header", color = "black")
    ft <- align(ft, align = "center", part = "all")
    ft <- border_remove(ft)
    black <- fp_border(color = "black", width = 1)
    ft <- border(ft, part = "header", border.top = black)
    ft <- border(ft, part = "header", border.bottom = black)
    if (nrow(df) > 0) {
      ft <- border(ft, i = nrow(df), part = "body", border.bottom = black)
    }

    # Bold significant p-values
    if (bold_p) {
      p_cols <- names(df)[grepl("Pr", names(df), fixed = TRUE)]
      for (pcol in p_cols) {
        if (is.numeric(df[[pcol]]) || all(grepl("^[0-9.<]+$", df[[pcol]]))) {
          sig_rows <- suppressWarnings(which(as.numeric(df[[pcol]]) < 0.05))
          if (length(sig_rows) == 0) {
            # handle formatted p-values like "<0.001"
            sig_rows <- grep("<0\\.0*1", df[[pcol]])
          }
          if (length(sig_rows) > 0 && pcol %in% ft$col_keys) {
            ft <- bold(ft, i = sig_rows, j = pcol, bold = TRUE)
          }
        }
      }
    }

    ft <- set_table_properties(ft, layout = "autofit", width = 0.9)
    ft <- padding(ft, padding.top = 2, padding.bottom = 2, padding.left = 2, padding.right = 2)
    ft
  }

  # Create new Word document
  doc <- read_docx()
  
  # ---- Title ----
  title_text <- sprintf(
    "%s Results — %s",
    if (is_lmm) "Linear Mixed Model" else "Linear Model",
    dep_var
  )
  doc <- body_add_fpar(
    doc,
    fpar(ftext(title_text, prop = fp_text(bold = TRUE, font.size = 12)))
  )
  
  # ---- Subtitle (Stratum, if any) ----
  if (!is.null(subtitle) && nzchar(subtitle)) {
    subtitle_text <- ftext(
      subtitle,
      prop = fp_text(bold = TRUE, font.size = 11)
    )
    doc <- body_add_fpar(doc, fpar(subtitle_text))
  }
  
  doc <- body_add_par(doc, "")
  
  # ==========================================================
  # 🔹 ANOVA (Type III)
  # ==========================================================
  doc <- body_add_fpar(doc, fpar(ftext("ANOVA (Type III)", prop = fp_text(bold = TRUE))))
  doc <- body_add_par(doc, "")

  if (is_lmm) {
    anova_tbl <- as.data.frame(anova(model, type = 3))
  } else {
    anova_tbl <- as.data.frame(car::Anova(model, type = 3))
  }
  anova_tbl <- tibble::rownames_to_column(anova_tbl, "Effect")

  # Round numeric columns and format p-values
  for (col in names(anova_tbl)) {
    if (is.numeric(anova_tbl[[col]])) anova_tbl[[col]] <- round(anova_tbl[[col]], 3)
  }
  p_col <- grep("^Pr", names(anova_tbl), value = TRUE)
  if (length(p_col) > 0) {
    colnames(anova_tbl)[colnames(anova_tbl) == p_col[1]] <- "Pr(>F)"
  }

  ft_anova <- format_table(anova_tbl)
  doc <- body_add_flextable(doc, ft_anova)
  doc <- body_add_par(doc, "")

  # ==========================================================
  # 🔹 Random Effects & ICC (LMM only)
  # ==========================================================
  if (is_lmm) {
    # ---- Random Effects ----
    doc <- body_add_fpar(doc, fpar(ftext("Random Effects", prop = fp_text(bold = TRUE))))
    doc <- body_add_par(doc, "")

    rand_df <- as.data.frame(lme4::VarCorr(model))
    if (nrow(rand_df) > 0) {
      rand_df <- rand_df[, c("grp", "var1", "var2", "vcov", "sdcor"), drop = FALSE]
      rand_df$var2 <- ifelse(is.na(rand_df$var2), "-", rand_df$var2)
      names(rand_df) <- c("Grouping", "Effect 1", "Effect 2", "Variance", "Std. Dev.")
      rand_df$Variance <- round(rand_df$Variance, 3)
      rand_df$`Std. Dev.` <- round(rand_df$`Std. Dev.`, 3)
      ft_rand <- format_table(rand_df, bold_p = FALSE)
      doc <- body_add_flextable(doc, ft_rand)
    } else {
      doc <- body_add_par(doc, "No random-effect variance components were estimated.", style = "Normal")
    }

    # ---- ICC ----
    if (exists("compute_icc") && is.function(compute_icc)) {
      icc_df <- compute_icc(model)
    } else {
      icc_df <- NULL
    }
    if (!is.null(icc_df) && nrow(icc_df) > 0) {
      doc <- body_add_par(doc, "")
      doc <- body_add_fpar(doc, fpar(ftext("Intraclass Correlation (ICC)", prop = fp_text(bold = TRUE))))
      doc <- body_add_par(doc, "")
      icc_df$ICC <- round(icc_df$ICC, 3)
      ft_icc <- format_table(icc_df, bold_p = FALSE)
      doc <- body_add_flextable(doc, ft_icc)
    }

    doc <- body_add_par(doc, "")
  }

  # ==========================================================
  # 🔹 Model Coefficients
  # ==========================================================
  doc <- body_add_fpar(doc, fpar(ftext("Model Coefficients", prop = fp_text(bold = TRUE))))
  doc <- body_add_par(doc, "")

  coef_tbl <- as.data.frame(summary(model)$coefficients)
  coef_tbl <- tibble::rownames_to_column(coef_tbl, "Term")
  names(coef_tbl)[1] <- "Term"
  names(coef_tbl) <- gsub("Pr\\(>\\|t\\|\\)", "Pr(>|t|)", names(coef_tbl))

  for (col in names(coef_tbl)) {
    if (is.numeric(coef_tbl[[col]])) coef_tbl[[col]] <- round(coef_tbl[[col]], 4)
  }

  ft_coef <- format_table(coef_tbl)
  doc <- body_add_flextable(doc, ft_coef)

  # ==========================================================
  # 🔹 Footer
  # ==========================================================
  doc <- body_add_par(doc, "")
  doc <- body_add_par(doc, "Significance level: p < 0.05 (bold values).", style = "Normal")
  doc <- body_add_par(doc, sprintf("Generated by Table Analyzer on %s", Sys.Date()))

  # Save file
  print(doc, target = file)
}

# ===============================================================
# 🧾 Helper: format regression table in journal style
# ===============================================================
format_regression_table <- function(df, bold_p = TRUE) {
  
  ft <- flextable(df)
  ft <- fontsize(ft, part = "all", size = 10)
  ft <- bold(ft, part = "header", bold = TRUE)
  ft <- color(ft, part = "header", color = "black")
  ft <- align(ft, align = "center", part = "all")
  ft <- border_remove(ft)
  
  black <- fp_border(color = "black", width = 1)
  ft <- border(ft, part = "header", border.top = black)
  ft <- border(ft, part = "header", border.bottom = black)
  if (nrow(df) > 0) {
    ft <- border(ft, i = nrow(df), part = "body", border.bottom = black)
  }

  if (bold_p && "Pr(>F)" %in% names(df)) {
    sig_rows <- which(df[["Pr(>F)"]] < 0.05)
    if (length(sig_rows) > 0) ft <- bold(ft, i = sig_rows, j = "Pr(>F)", bold = TRUE)
  }
  if (bold_p && "Pr(>|t|)" %in% names(df)) {
    sig_rows <- which(df[["Pr(>|t|)"]] < 0.05)
    if (length(sig_rows) > 0) ft <- bold(ft, i = sig_rows, j = "Pr(>|t|)", bold = TRUE)
  }

  ft <- set_table_properties(ft, layout = "autofit", width = 0.9)
  ft <- padding(ft, padding.top = 2, padding.bottom = 2, padding.left = 2, padding.right = 2)
  ft
}# ===============================================================
# 🔁 Multi-Response Selector Module
# ===============================================================

multi_response_ui <- function(id) {
  ns <- NS(id)
  tagList(
    checkboxInput(
      ns("multi_resp"),
      "Allow multiple response variables",
      value = FALSE
    ),
    uiOutput(ns("response_ui"))
  )
}

multi_response_server <- function(id, data) {
  moduleServer(id, function(input, output, session) {

    df <- reactive({
      if (is.function(data)) data() else data
    })

    # --- Render selectInput dynamically
    output$response_ui <- renderUI({
      d <- df()
      req(d)
      num_vars <- names(d)[sapply(d, is.numeric)]

      # fallback selection
      current_selection <- input$response
      if (is.null(current_selection) || !all(current_selection %in% num_vars)) {
        current_selection <- if (length(num_vars) > 0) num_vars[1] else NULL
      }

      selectInput(
        session$ns("response"),
        if (isTRUE(input$multi_resp))
          "Response variables (numeric):"
        else
          "Response variable (numeric):",
        choices = num_vars,
        selected = current_selection,
        multiple = isTRUE(input$multi_resp)
      )
    })

    # --- Return standardized reactive vector
    reactive({
      req(input$response)
      res <- input$response
      if (!isTRUE(input$multi_resp)) res <- res[1]
      unique(res)
    })
  })
}
# ===============================================================
# 🧭 Stratification helpers (shared across analysis modules)
# ===============================================================

STRAT_CHOOSE_LABEL <- "Stratify by:"
STRAT_NONE_LABEL <- "None"
STRAT_ORDER_LABEL <- "Order of levels (first = reference):"
MAX_STRATIFICATION_LEVELS <- 10

stratification_ui <- function(id, ns = NULL) {
  ns_fn <- if (is.null(ns)) {
    NS(id)
  } else if (is.function(ns)) {
    function(x) ns(paste(id, x, sep = "-"))
  } else {
    NS(id)
  }

  shiny::tagList(
    shiny::uiOutput(ns_fn("stratify_var_ui")),
    shiny::uiOutput(ns_fn("strata_order_ui"))
  )
}


stratification_server <- function(id, data) {
  moduleServer(id, function(input, output, session) {
    
    # ---- Resolve reactive or static data frame ----
    resolved_data <- reactive({
      if (is.function(data)) data() else data
    })
    
    # ---- UI for selecting stratification variable ----
    output$stratify_var_ui <- shiny::renderUI({
      df <- resolved_data()
      
      choices <- STRAT_NONE_LABEL
      if (is.data.frame(df) && ncol(df) > 0) {
        cat_cols <- names(df)[vapply(df, function(x) is.character(x) || is.factor(x), logical(1))]
        cat_cols <- setdiff(unique(cat_cols), STRAT_NONE_LABEL)
        if (length(cat_cols) > 0) {
          choices <- c(STRAT_NONE_LABEL, cat_cols)
        }
      }
      
      current <- isolate(input$stratify_var)
      if (is.null(current) || !(current %in% choices)) {
        current <- STRAT_NONE_LABEL
      }
      
      shiny::selectInput(
        session$ns("stratify_var"),
        STRAT_CHOOSE_LABEL,
        choices = choices,
        selected = current
      )
    })
    
    
    # ---- Reactive containing selected variable + levels ----
    strat_details <- reactive({
      df <- resolved_data()
      if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) {
        return(list(var = NULL, levels = NULL, available_levels = NULL))
      }
      
      strat_var <- input$stratify_var
      if (is.null(strat_var) || identical(strat_var, STRAT_NONE_LABEL) ||
          !nzchar(strat_var) || !(strat_var %in% names(df))) {
        return(list(var = NULL, levels = NULL, available_levels = NULL))
      }
      
      # ---- Inline guard_stratification_levels ----
      values <- df[[strat_var]]
      values <- values[!is.na(values)]
      n_levels <- length(unique(as.character(values)))
      
      if (n_levels > MAX_STRATIFICATION_LEVELS) {
        msg <- sprintf(
          "❌ Stratification variable '%s' has %d levels — please select one with at most %d.",
          strat_var, n_levels, MAX_STRATIFICATION_LEVELS
        )
        shiny::showNotification(msg, type = "error", duration = 8)
        shiny::updateSelectInput(session, "stratify_var", selected = STRAT_NONE_LABEL)
        return(list(var = NULL, levels = NULL, available_levels = NULL))
      }
      
      # ---- Extract available levels ----
      if (is.factor(values)) {
        available_levels <- levels(values)
      } else {
        available_levels <- unique(as.character(values))
      }
      
      available_levels <- available_levels[!is.na(available_levels)]
      
      if (length(available_levels) == 0) {
        return(list(var = strat_var, levels = character(0), available_levels = character(0)))
      }
      
      selected_levels <- input$strata_order
      if (!is.null(selected_levels) && length(selected_levels) > 0) {
        selected_levels <- selected_levels[selected_levels %in% available_levels]
      }
      
      if (is.null(selected_levels) || length(selected_levels) == 0) {
        selected_levels <- available_levels
      }
      
      list(
        var = strat_var,
        levels = selected_levels,
        available_levels = available_levels
      )
    })
    
    
    # ---- UI for level ordering ----
    output$strata_order_ui <- shiny::renderUI({
      details <- strat_details()
      strat_var <- details$var
      if (is.null(strat_var)) return(NULL)
      
      available_levels <- details$available_levels
      if (is.null(available_levels) || length(available_levels) == 0) return(NULL)
      
      selected_levels <- details$levels
      if (is.null(selected_levels) || length(selected_levels) == 0) {
        selected_levels <- available_levels
      }
      
      shiny::selectInput(
        session$ns("strata_order"),
        STRAT_ORDER_LABEL,
        choices = available_levels,
        selected = selected_levels,
        multiple = TRUE
      )
    })
    
    
    # ---- Output unified reactive for all modules ----
    reactive({
      details <- strat_details()
      list(var = details$var, levels = details$levels)
    })
  })
}
